from enum import unique
import logging
from turtle import color
import webbrowser
import csv
import base64
import io
import pickle
import re
import uuid
import pandas as pd
import dash
import gcubed.graphics.colors
from dash import Dash, dcc, html, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import threading

from gcubed.graphics.chart_pack.chart_pack import ChartPack

# Set the logging level to DEBUG to display all log messages
logging.basicConfig(level=logging.DEBUG)


def open_browser():
    webbrowser.open_new("http://127.0.0.1:8050/")


def parse_csv(contents: str, filename: str, filetype: str) -> pd.DataFrame:
    """
    ### Overview
    Parse the CSV file into a dataframe.

    ### Arguments
    `contents` : The contents of the CSV file.
    `filename` : The name of the CSV file.
    `filetype` : The type of the file - one of 'chartpack' or 'projections'.

    ### Returns
    A dataframe containing the contents of the CSV file.

    ### Exceptions

    Raises an exception if the content type is not "text/csv".

    Raises an exception if the CSV file data is not rectangular.

    """
    content_type, content_string = contents.split(",")

    assert (
        "text/csv" in content_type
    ), f"Invalid file type: {content_type}. {filename} must be a 'text/csv' file."

    # Decode the string representation of the CSV file content.
    content: str = base64.b64decode(content_string).decode("utf-8")

    # Read in the data one row at a time.
    csv_file = io.StringIO(content)
    csv_reader = csv.reader(csv_file)
    rows: list = []
    columns: list[str] = []
    for row in csv_reader:
        if columns:
            rows.append(row)
        else:
            columns = row
            max_columns = len(columns)

            # Check it is a chart pack
            match filetype:
                case "chartpack":
                    assert max_columns == len(
                        ChartPack.required_columns()
                    ), f"Invalid chartpack file: there should be {len(ChartPack.required_columns())} columns in the file."
                    for column in columns:
                        assert (
                            column in ChartPack.required_columns()
                        ), f"Invalid column name '{column}' in chartpack file."

                case "projections":
                    assert (
                        "units" in columns
                    ), f"Invalid projections file, {filename}. The file must contain a 'units' column."
                    regular_expression = re.compile("[1-9][0-9]{3}")
                    data_column_names = list(filter(regular_expression.match, columns))
                    assert (
                        data_column_names
                    ), f"The uploaded file has no identifiable data columns. Header labels for data columns must have YYYY format."

                case _:
                    assert (
                        False
                    ), f"Loading invalid file type {filetype}. The file type must be 'chartpack' or 'projections'."

    dataframe: pd.DataFrame = pd.DataFrame(rows, columns=columns)

    if filetype == "projections":
        dataframe.columns.values[0] = "variable"
        dataframe.index = dataframe.variable
        dataframe.drop("variable", axis=1, inplace=True)
        assert (
            dataframe.index.is_unique
        ), f"Invalid projections file: the variable names are not unique."

    return dataframe


app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.title = "G-Cubed Charts"

app.layout = dbc.Container(
    [
        dbc.Row(
            [
                html.H1(children="G-Cubed Charts"),
                dbc.Col(  # First upload component
                    [
                        html.Label(
                            "Chartpack file status:",
                            style={"font-weight": "bold"},
                        ),
                        html.Div(id="chartpack-file-status"),
                        dcc.Upload(
                            id="upload-chartpack",
                            children=html.Div(
                                ["Upload ", html.A("a chartpack CSV file")]
                            ),
                            style={
                                "width": "75%",
                                "height": "60px",
                                "lineHeight": "60px",
                                "borderWidth": "1px",
                                "borderStyle": "solid",
                                "borderRadius": "5px",
                                "textAlign": "center",
                                "margin": "10px",
                            },
                            multiple=False,
                        ),
                    ],
                    width=4,
                ),
                dbc.Col(  # Second upload component
                    [
                        html.Label(
                            "Projections file status:",
                            style={"font-weight": "bold"},
                        ),
                        html.Div(id="data-file-status"),
                        dcc.Upload(
                            id="upload-data",
                            children=html.Div(
                                ["Upload ", html.A("a projections CSV file")]
                            ),
                            style={
                                "width": "75%",
                                "height": "60px",
                                "lineHeight": "60px",
                                "borderWidth": "1px",
                                "borderStyle": "solid",
                                "borderRadius": "5px",
                                "textAlign": "center",
                                "margin": "10px",
                            },
                            multiple=False,
                        ),
                    ],
                    width=4,
                ),
                html.Div(id="warnings"),
            ],
            style={
                "padding-top": "0px",
                "position": "fixed",
                "width": "100%",
                "top": "0",
                "z-index": "1000",
                "background-color": "white",
            },
        ),
        dbc.Row(
            [dbc.Col([html.Div(id="chart-container")])],
            style={
                "padding-top": "190px"
            },  # Add top padding to ensure content starts below the fixed components
        ),
        dcc.Store(id="chartpack-details-store"),
        dcc.Store(id="projections-data-store"),
    ]
)


@app.callback(
    [
        Output("chartpack-file-status", "children"),
        Output("chartpack-details-store", "data"),
    ],
    [Input("upload-chartpack", "contents")],
    [State("upload-chartpack", "filename")],
)
def update_chartpack_file_status(contents, filename):
    """
    ### Overview

    Upload and parse the file to create a `ChartPack` object.

    ### Arguments

    `contents` : The contents of the CSV file.
    `filename` : The name of the CSV file.

    ### Returns

    A tuple containing the pickled chart pack and a message.

    # Exceptions

    Raises an exception if the file is not a valid chart pack CSV file.

    """
    if contents is None:
        return "No chartpack file uploaded.", None

    # Parse the chartpack file into a data frame
    try:
        chartpack_details: pd.DataFrame = parse_csv(
            contents=contents, filename=filename, filetype="chartpack"
        )
    except Exception as error:
        return f"'{filename}': " + str(error), None

    # Create a ChartPack object from the CSV file content
    try:
        chart_pack: ChartPack = ChartPack(details=chartpack_details)
    except Exception as error:
        return f"'{filename}': " + str(error), None

    return (
        f"Using the '{filename}' chartpack.",
        base64.b64encode(pickle.dumps(chart_pack)).decode("utf-8"),
    )


@app.callback(
    [Output("data-file-status", "children"), Output("projections-data-store", "data")],
    [Input("upload-data", "contents")],
    [State("upload-data", "filename")],
)
def update_data_file_status(contents, filename):
    """
    ### Overview
    Handle the upload of the projections CSV file.

    Parse the file to create a Pandas dataframe object.

    ### Arguments

    `contents` : The contents of the CSV file.
    `filename` : The name of the CSV file.

    ### Returns

    A tuple containing the pickled data object and a message.

    # Exceptions

    Raises an exception if the file is not a valid projections CSV file.

    """
    if contents is None:
        return "No projections file uploaded.", dash.no_update

    try:
        projections: pd.DataFrame = parse_csv(
            contents=contents, filename=filename, filetype="projections"
        )
    except Exception as error:
        return f"'{filename}': " + str(error), None

    if not "units" in projections.columns:
        return (
            f"File '{filename}': The projections file must contain a 'units' column.",
            None,
        )

    return (
        f"Projections in '{filename}' have been uploaded.",
        base64.b64encode(pickle.dumps(projections)).decode("utf-8"),
    )


def update_charts_initial_checks(projections_pickle, chartpack_pickle):
    if projections_pickle is None and chartpack_pickle is None:
        return (
            False,
            dash.no_update,
            ["Upload a chart pack and a set of projections."],
        )

    if projections_pickle is None:
        return (
            False,
            dash.no_update,
            ["Upload a set of projections."],
        )

    if chartpack_pickle is None:
        return (
            False,
            dash.no_update,
            ["Upload a chart pack."],
        )

    return True, None, None


def update_charts_load(projections_pickle, chartpack_pickle):
    # Load the chartpack from the store
    try:
        chart_pack: ChartPack = pickle.loads(base64.b64decode(chartpack_pickle))
    except Exception as error:
        return False, dash.no_update, [f"Error accessing the chart pack: {str(error)}"]

    # Load the projections data from the store.
    try:
        projections: pd.DataFrame = pickle.loads(base64.b64decode(projections_pickle))
    except Exception as error:
        return False, dash.no_update, [f"Error accessing the projections: {str(error)}"]

    # Run the variable data existence checks
    chartpack_variables = set(chart_pack.variables_in_pack)
    data_variables = set(projections.index)
    missing_variables = chartpack_variables - data_variables
    if missing_variables:
        return False, dash.no_update, [
            f"The following variables in the chartpack definition are not available in the projections file: {missing_variables}"
        ]

    return True, chart_pack, projections


def update_charts_add_units(chart_pack, projections):
    # Add units attributes to the charts in the chartpack, validating as you go.
    for chart in chart_pack.charts:
        chart.unit = None
        for variable in chart.variables_in_chart:
            new_unit: str = str(projections.loc[variable, "units"])
            if not new_unit:
                return False, dash.no_update, [
                    f"Variable '{variable}' does not have units information in the projection file."
                ]
            if chart.unit is None:
                chart.unit = new_unit
            elif new_unit != chart.unit:
                return (
                    False,
                    dash.no_update,
                    f"Chart {chart.label} has variables with different units: '{chart.unit}' and '{new_unit}'.",
                )

    return True, chart_pack, []


def update_charts_get_years(chart_pack, projections):
    # Get the first and last available years in the projections data
    regular_expression = re.compile("[1-9][0-9]{3}")
    data_column_names = list(filter(regular_expression.match, projections.columns))
    if not data_column_names:
        return (
            dash.no_update,
            f"The projections file must contain data with column labels for years in YYYY format.",
        )
    try:
        first_available_year: int = int(data_column_names[0])
    except Exception as error:
        return (
            dash.no_update,
            f"Error finding the first year in the projections file: found {data_column_names[0]} instead.",
        )
    try:
        last_available_year: int = int(data_column_names[-1])
    except Exception as error:
        return (
            dash.no_update,
            f"Error finding the last year in the projections file: found {data_column_names[-1]} instead.",
        )

    # Check that the available years of data are valid
    if first_available_year > last_available_year:
        return dash.no_update, [
            f"First available year {first_available_year} must be before the last available year {last_available_year}"
        ]

    default_first_year: int = (
        max(chart_pack.start_year, first_available_year)
        if chart_pack.start_year
        else first_available_year
    )
    default_last_year: int = (
        min(chart_pack.end_year, last_available_year)
        if chart_pack.end_year
        else last_available_year
    )

    return default_first_year, default_last_year, first_available_year, last_available_year


@app.callback(
    Output("chart-container", "children"),
    Output("warnings", "children"),
    [
        Input("projections-data-store", "data"),
        Input("chartpack-details-store", "data"),
    ],
)
def update_charts(projections_pickle, chartpack_pickle):
    """
    ### Overview

    Manage parsing of the chartpack and update of the chart system if data is available.

    ### Returns

    1. a list of graphs
    2. a list of warnings

    """
    should_continue, initial_check_response, info = update_charts_initial_checks(projections_pickle, chartpack_pickle)
    if not should_continue:
        return initial_check_response, info

    should_continue, chart_pack, projections = update_charts_load(projections_pickle, chartpack_pickle)
    if not should_continue:
        return chart_pack, projections

    should_continue, chart_pack, response = update_charts_add_units(chart_pack, projections)
    if not should_continue:
        return chart_pack, response

    default_first_year, default_last_year, first_available_year, last_available_year = update_charts_get_years(chart_pack, projections)

    warnings = chart_pack.warnings
    figures_list: list[go.Figure] = []
    for chart in chart_pack.charts:
        warnings.append(chart.warnings)
        figure: go.Figure = go.Figure()

        first_year: int = chart.start_year if chart.start_year else default_first_year
        if first_year < first_available_year:
            warnings.append(
                f"Chart '{chart.label}' has a first year {first_year} that is before the first available projection year {first_available_year}."
            )
            first_year = default_first_year

        last_year: int = chart.end_year if chart.end_year else default_last_year
        if last_year > last_available_year:
            warnings.append(
                f"Chart '{chart.label}' has a last year {last_year} that is after the last available projection year {last_available_year}."
            )
            first_year = default_first_year

        data_is_all_zeros: bool = True
        found_a_valid_series: bool = False
        # Initialize containers for common and unique descriptions
        common_dimensions: set[str] = None
        series_dimensions: dict[list[str]] = {}

        # Define the regular expression pattern used to split up the set member descriptions
        pattern = re.compile(r",(?=[a-zA-Z0-9_]+=)")

        # Process each series to find common and unique set member descriptions
        for series in chart.series:
            warnings.append(series.warnings)
            series_data: pd.DataFrame = projections.loc[
                [series.variable_name], str(first_year) : str(last_year)
            ]
            series_data = series_data.apply(pd.to_numeric, errors="coerce")
            if not len(series_data) == 1:
                warnings.append(
                    f"Chart {chart.label}: found {len(series_data)} rows of projections data for '{series.label}' - variable {series.variable_name}"
                )
                continue

            set_member_descriptions: str = projections.at[
                series.variable_name, "set_member_descriptions"
            ]

            variable_description: str = projections.at[
                series.variable_name, "description"
            ]

            prefix: str = projections.at[series.variable_name, "prefix"]

            found_a_valid_series: bool = True
            data_is_all_zeros: bool = (
                data_is_all_zeros and (series_data.abs() < 1e-12).all().all()
            )

            # Build common dimensions set using intersection across series
            dimensions: list[str] = [
                x.strip() for x in pattern.split(set_member_descriptions)
            ]
            dimensions.insert(0, f"variable={variable_description} ({prefix})")

            # Extract set member descriptions
            if set_member_descriptions:
                series_dimensions[series.variable_name] = dimensions

            if common_dimensions is None:
                common_dimensions: set[str] = set(dimensions)
            else:
                common_dimensions = common_dimensions & set(dimensions)

        # Process unique_descriptions, eliminating common dimensions.
        for variable_name in series_dimensions:
            dimensions = series_dimensions[variable_name]
            legend_dimensions: list[str] = []
            for dimension in dimensions:
                if dimension not in common_dimensions:
                    legend_dimensions.append(dimension)
            series_dimensions[variable_name] = legend_dimensions

        title_dimensions: list[str] = list(common_dimensions)
        title_dimensions = [x.split("=")[1] for x in title_dimensions]

        # Construct the title
        if chart.label:
            pass
        else:
            chart.label = f"{', '.join(title_dimensions)}"

        # Process each series to add to the figure
        series_colors = gcubed.graphics.colors.select_colors(
            number_of_colors_required=len(chart.series)
        )

        for series in chart.series:
            series_data = projections.loc[
                [series.variable_name], str(first_year) : str(last_year)
            ].apply(pd.to_numeric, errors="coerce")

            for index, row in series_data.iterrows():
                if series.variable_name in series_dimensions:
                    dimensions: list[str] = series_dimensions[series.variable_name]
                    if dimensions:
                        dimensions = [x.split("=")[1] for x in dimensions]
                        label = f"{', '.join(dimensions)}"
                    else:
                        label = f""

                color_value: str = series_colors.pop(0)

                figure.add_trace(
                    go.Scatter(
                        x=row.index,
                        y=row.values,
                        mode="lines",
                        name=f"{label}",
                        line=dict(color=color_value, dash=series.line_value),
                    )
                )

        if not found_a_valid_series:
            warnings.append(
                f"Chart {chart.label} has no valid series so it is not shown."
            )
            continue

        figure.update_layout(
            yaxis_title=chart.unit,
            yaxis_range=[-1, 1] if data_is_all_zeros else figure.layout.yaxis.range,
            title_text=f"{chart.label}",  # Set the figure title using the chart label
            title_x=0.05,  # Set the x-position of the title to center it
            title_y=0.85,  # Set the y-position of the title (adjust as needed)
            title_xanchor="left",  # Anchor the x-position at the left of the plot
            title_yanchor="top",  # Anchor the y-position at the top of the plot
            # legend=dict(
            #     x=0.5, y=-0.45, xanchor="center", yanchor="top", orientation="v"
            # ),
        )

        new_graph = dcc.Graph(id=f"graph-{chart.label}-{uuid.uuid4()}", figure=figure)

        # Append the new graph to the list
        figures_list.append(new_graph)

    if not figures_list:
        warnings.append("There are no valid charts to display.")
        return dash.no_update, warnings

    # Return the list of graphs.
    warnings_list = ['Info and warnings:', html.Br()]
    warnings.append(f"Number of charts:{len(figures_list)}")
    warnings_str = set([str(warning) for warning in warnings if warning])
    for warning in warnings_str:
        warnings_list.append(warning)
        warnings_list.append(html.Br())

    return (
        figures_list,
        warnings_list
    )


def run_server():
    threading.Timer(1, open_browser).start()
    app.run_server(debug=True, use_reloader=False)


if __name__ == "__main__":
    run_server()
