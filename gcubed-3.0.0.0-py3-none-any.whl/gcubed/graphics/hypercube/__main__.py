from .hypercube_app import run_server

run_server()
