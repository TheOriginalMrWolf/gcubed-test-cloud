# coding=gbk
# Time Created: 2023/6/28 21:41
# Author  : Lucid
# FileName: __main__.py
# Software: PyCharm
from .quick_check_app import run_server

run_server()
