"""
The colors available for charts in the `gcubed` package.

https://www.heavy.ai/blog/12-color-palettes-for-telling-better-stories-with-your-data

"""

from hmac import new
import math
import logging

from numpy import number

palette_lengths = 9
palette_count = 3

blue_to_red: list[str] = [
    "#1984c5",
    "#22a7f0",
    "#63bff0",
    "#a7d5ed",
    "#ebdc78",
    "#e1a692",
    "#de6e56",
    "#e14b31",
    "#c23728",
]

orange_to_purple: list[str] = [
    "#ffb400",
    "#d2980d",
    "#a57c1b",
    "#786028",
    "#363445",
    "#48446e",
    "#5e569b",
    "#776bcd",
    "#9080ff",
]

salmon_to_aqua: list[str] = [
    "#e27c7c",
    "#a86464",
    "#6d4b4b",
    "#503f3f",
    "#333333",
    "#3c4e4b",
    "#466964",
    "#599e94",
    "#6cd4c5",
]

all_palettes: list[list[str]] = [blue_to_red, orange_to_purple, salmon_to_aqua]


def maximally_spaced_colors(color_palette: list[str], number_of_colors_required: int):
    """

    ### Arguments

    `color_palette`: A list of colors in hex format.

    `number_of_colors_required`: The number of colors required from the palette.

    ### Returns

    A list of colors in the palette such that list is
    the right length (the number of colors required) and the colors are
    maximally spaced out in the palette.
    """

    if number_of_colors_required <= 0 or number_of_colors_required > len(color_palette):
        raise ValueError("Invalid value of X")

    if number_of_colors_required == 1:
        return [color_palette[0]]

    selected_indices: list[int] = []
    if number_of_colors_required <= math.ceil(palette_lengths / 2):
        step_size = math.floor(palette_lengths / (number_of_colors_required - 1))
        if step_size > 1:
            # Use list slicing with the calculated step size
            selected_indices = [x for x in range(0, 2 * palette_lengths, step_size)]
            selected_indices = selected_indices[:number_of_colors_required]
            selected_indices[-1] = palette_lengths - 1
    else:
        selected_indices = [x for x in (range(0, palette_lengths))]
        number_of_colors_to_delete: int = palette_lengths - number_of_colors_required
        segments = number_of_colors_to_delete + 1
        first_deletion_index = math.floor(palette_lengths / segments)
        deletion_indices = [
            ((x + 1) * first_deletion_index) for x in range(number_of_colors_to_delete)
        ]
        for index in deletion_indices:
            del selected_indices[index]

    return [color_palette[i] for i in selected_indices]


def select_colors(number_of_colors_required: int):
    """
    ### Arguments

    `number_of_colors_required`: The number of colors required from the palette.

    ### Returns

    A list of HTML valid color code strings.

    """
    if number_of_colors_required <= palette_lengths:
        return maximally_spaced_colors(
            color_palette=blue_to_red,
            number_of_colors_required=number_of_colors_required,
        )

    colors_from_each_palette: int = math.ceil(number_of_colors_required / palette_count)

    result: list[str] = []
    for palette in all_palettes:
        if len(result) + colors_from_each_palette > number_of_colors_required:
            colors_from_each_palette = number_of_colors_required - len(result)

        new_colors = maximally_spaced_colors(
            color_palette=palette, number_of_colors_required=colors_from_each_palette
        )

        result += new_colors

    return result
