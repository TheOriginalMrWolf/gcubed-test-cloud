"""
This module contains the `ChartPack` class, used to parse 
a Chart Pack definition CSV file.
"""
# DO NOT DELETE THIS IMPORT
# from typing import Optional  # DO NOT DELETE THIS IMPORT it manages circular references.
import pandas as pd
import regex as re
import logging
import webcolors


class ChartPackObject:
    """
    ### Overview
    The base object for all chart pack objects, the pack itself, charts and series in charts.
    """

    @classmethod
    def type_column(cls) -> str:
        """
        The name of the column containing the object type. The object type value
        in the column must be one of:

        - `pack`
        - `chart`
        - `series`

        """
        return "type"

    @classmethod
    def attributes_column(cls) -> str:
        """
        The name of the column containing the comma delimited attributes of the object.
        Each attribute is specified as a name=value pair. The name and the value must
        not contain commas.
        """
        return "attributes"

    @classmethod
    def variable_column(cls) -> str:
        """
        The name of the column containing the name of the variable associated with the
        object. This is only valid for series objects.
        """
        return "variable"

    @classmethod
    def label_column(cls) -> str:
        """
        The name of the column containing the label of the object.
        """
        return "label"

    @classmethod
    def required_columns(cls) -> list[str]:
        """
        The list of column labels that must be present in the chart pack details.
        """
        return [
            __class__.type_column(),
            __class__.attributes_column(),
            __class__.variable_column(),
            __class__.label_column(),
        ]

    @classmethod
    def color_name(cls) -> str:
        """
        The color attribute name.
        """
        return "color"

    @classmethod
    def line_name(cls) -> str:
        """
        The line style attribute name.
        """
        return "line"

    @classmethod
    def min_name(cls) -> str:
        """
        The Y-axis minimum attribute name.
        """
        return "min"

    @classmethod
    def max_name(cls) -> str:
        """
        The Y-axis maximum attribute name.
        """
        return "max"

    @classmethod
    def start_name(cls) -> str:
        """
        The start year attribute name.
        """
        return "start_year"

    @classmethod
    def end_name(cls) -> str:
        """
        The end year attribute name.
        """
        return "end_year"

    def __init__(self) -> None:
        """

        ### Constructor

        Base object constructor

        """
        self._attributes: dict[str, any] = dict()
        self._warnings: list[str] = []

    def __str__(self) -> str:
        """
        ### Overview

        Returns a string representation of the object.

        ### Returns

        A string representation of the object.

        """
        result: str = f"Chart pack {self.label}"
        for chart in self.charts:
            result += f"\n{str(chart)}"
        return result

    @property
    def pack_type(self) -> str:
        """
        The pack object name
        """
        return "pack"

    @property
    def chart_type(self) -> str:
        """
        The chart object name
        """
        return "chart"

    @property
    def series_type(self) -> str:
        """
        The series object name
        """
        return "series"

    @property
    def allowed_types(self) -> list[str]:
        """
        The list of allowed object types.

        Currently allowed types are `pack`, `chart` or `series`.
        """
        return [
            self.pack_type,
            self.chart_type,
            self.series_type,
        ]

    @property
    def warnings(self) -> list[str]:
        """
        The list of warnings associated with the object.
        """
        return self._warnings

    def add_warning(self, warning: str):
        """
        ### Overview
        Add a warning to the object.

        ### Arguments
        warning: The warning to add.
        """
        if not hasattr(self, "_warnings"):
            self._warnings = []
        if not warning:
            return
        self._warnings.append(warning)

    @property
    def charts(self) -> list["Chart"]:
        """
        The list of charts in the chart pack.
        """
        if not hasattr(self, "_charts"):
            return []
        return self._charts

    @property
    def label(self) -> str:
        """
        The object label.
        """
        if not hasattr(self, "_label"):
            return "No label supplied."
        return self._label

    @label.setter
    def label(self, value: str):
        """
        ### Arguments
        value: The new label.
        """
        assert value is not None, "Label must not be None."
        assert isinstance(value, str), "Label must be a string."
        self._label = value

    def attribute(self, name: str) -> any:
        """
        ### Overview

        Accessor for attributes.

        ### Arguments

        `name`: The name of the attribute to return.

        ### Returns

        The value of the attribute or `None` if the attribute is not available.

        """
        if not name in self._attributes:
            return None
        return self._attributes[name]

    def has_attribute(self, name: str) -> any:
        """
        ### Overview

        Test if object has attribute.

        ### Arguments

        `name`: The name of the attribute to test for.

        ### Returns

        `True` if the object has the attribute or `False` otherwise.

        """
        return name in self._attributes

    def populate_attributes(self, data: str):
        """
        ### Overview
        Populate the dictionary of attributes by parsing the name=value pairs
        in the attributes string associated with this chart object.

        ### Arguments
        data: The string of name value pairs that define the attributes.
        The pairs are comma separated. The name and value are separated by an `=` sign.
        The name and the value must not contain commas.

        ### Exceptions

        Raises an exception if the attributes string is not provided.

        Raises an exception if the attributes string cannot be parsed.
        """

        assert data is not None, "Data parameter must be provided."
        assert isinstance(data, str), "Data parameter must be a string."
        if len(data) == 0:
            return
        for pair in data.split("|"):
            name, value = pair.split("=")
            self._attributes[name] = value

    @property
    def start_year(self) -> int:
        """
        The X-axis start year, read in as an attribute and converted to an integer.
        This attribute is applicable to packs and charts.
        """
        value = self.attribute(__class__.start_name())
        if value is None:
            return None
        if not value:
            return None
        try:
            return int(self.attribute(__class__.start_name()))
        except Exception:
            return None

    @property
    def end_year(self) -> int:
        """
        The X-axis end year, read in as an attribute and converted to an integer.
        This attribute is applicable to packs and charts.
        """
        value = self.attribute(__class__.end_name())
        if value is None:
            return None
        if not value:
            return None
        try:
            return int(self.attribute(__class__.end_name()))
        except Exception:
            return None


class Series(ChartPackObject):
    def __init__(self, series_details: pd.Series) -> None:
        """

        ### Constructor

        Creates a chart definition from the chart details and the series details.

        ### Arguments

        series_details: The Series with all definitional information about the series.

        ### Exceptions

        Raises an exception if the series details are not provided.

        Raises an exception if the series details do not contain the required columns.

        Raises an exception if the series details do not have a variable name.

        """

        super().__init__()

        assert series_details is not None, "Series details must be provided."
        assert isinstance(
            series_details, pd.Series
        ), "Series details must be a pd.Series."

        for column in __class__.required_columns():
            if not column in series_details.index:
                raise Exception(f"Series details must contain a value for {column}.")

        assert (
            series_details[__class__.variable_column()] is not None
        ), "Series must have a variable name."
        self._variable_name = str(series_details[__class__.variable_column()])

        self.label = str(series_details[__class__.label_column()])

        attributes_data: any = series_details[__class__.attributes_column()]
        if attributes_data is not None and isinstance(attributes_data, str):
            self.populate_attributes(data=str(attributes_data))

        assert self.color_is_valid(
            self.color_value
        ), f"Series color, {self.color_value}, is not a valid HTML color."

        if self.start_year or self.end_year:
            self.add_warning(
                f"{self.label} series specifies a date range but that is only used for the 'pack' or a 'chart'"
            )

    def __str__(self) -> str:
        """
        ### Overview

        Returns a string representation of the object.

        ### Returns

        A string representation of the object.

        """
        return f"Series {self.label} ({self.variable_name}) [{self.color_value}]"

    @property
    def variable_name(self) -> str:
        """
        The variable name for the series
        """
        return self._variable_name

    @property
    def color_value(self) -> str:
        """
        The color value for the series.

        This attribute is only applicable to series.

        It defaults to black.
        """
        if not __class__.color_name() in self._attributes:
            return None
        return str(self.attribute(__class__.color_name()))

    def color_is_valid(self, color: str) -> bool:
        """
        ### Overview

        Test if the color is valid.

        ### Arguments
        color: The color to test.

        ### Returns
        `True` if the color is valid or `False` otherwise.
        """

        # Use a color = None to use a default color.
        if color is None:
            return True

        html_color_pattern_hex = re.compile(r"^#(?:[0-9a-fA-F]{3}){1,2}$")
        html_color_pattern_rgb = re.compile(r"^rgb\((\d{1,3}),(\d{1,3}),(\d{1,3})\)$")
        html_color_pattern_rgba = re.compile(
            r"^rgba\((\d{1,3}),(\d{1,3}),(\d{1,3}),(0(\.\d+)?|1(\.0+)?)\)$"
        )
        html_color_names = list(webcolors.CSS3_NAMES_TO_HEX.keys())

        if not (
            html_color_pattern_hex.match(color)
            or html_color_pattern_rgb.match(color)
            or html_color_pattern_rgba.match(color)
            or color in html_color_names
        ):
            return False

        return True

    @property
    def line_value(self) -> str:
        """
        The line style for the series.
        """
        if not __class__.line_name() in self._attributes:
            return "solid"  # default value
        return str(self.attribute(__class__.line_name()))

    def line_is_valid(self, line: str) -> bool:
        """
        Test if the line style is valid.

        line: The line style to test.

        `True` if the line style is valid or `False` otherwise.
        """
        valid_line_styles = [
            "solid",
            "dot",
            "dash",
            "longdash",
            "dashdot",
            "longdashdot",
        ]
        return line in valid_line_styles


class Chart(ChartPackObject):
    def __init__(self, chart_details: pd.Series) -> None:
        """

        ### Constructor

        Creates a chart definition from the chart details and the series details.

        ### Arguments

        chart_details: The Series with all definitional information about the chart.

        ### Exceptions

        Raises an exception if the chart details are not provided.

        Raises an exception if the chart details are not a pd.Series

        Raises an exception if the chart details do not contain the required columns.

        """

        super().__init__()

        assert chart_details is not None, "Chart details must be provided."
        assert isinstance(chart_details, pd.Series), "Chart details must be a Series."

        for column in __class__.required_columns():
            if not column in chart_details.index:
                raise Exception(f"Chart details must contain a value for {column}.")

        self.label = str(chart_details[__class__.label_column()])

        attributes_data: any = chart_details[__class__.attributes_column()]
        if attributes_data is not None and isinstance(attributes_data, str):
            self.populate_attributes(data=str(attributes_data))

        assert not self.has_attribute(
            __class__.color_name
        ), f"Charts cannot have a color attribute. Use color attributes on series instead."

        # validate the date range if provided.
        if self.start_year is not None and self.end_year is not None:
            assert (
                self.start_year <= self.end_year
            ), f"The chart {self.label} start year {self.start_year} must be before the end year, {self.end_year}."

    def __str__(self) -> str:
        """
        ### Overview

        Returns a string representation of the object.

        ### Returns

        A string representation of the object.

        """
        result: str = f"Chart {self.label}"
        for series in self.series:
            result += f"\n{str(series)}"
        return result

    @property
    def series(self) -> list["Series"]:
        """
        The list of series in the chart.
        """
        if not hasattr(self, "_series"):
            return []
        return self._series

    @property
    def max_value(self) -> float:
        """
        The Y-axis maximum
        """
        try:
            return float(self.attribute(__class__.max_name()))
        except Exception:
            return None

    @property
    def min_value(self) -> float:
        """
        The Y-axis minimum
        """
        try:
            return float(self.attribute(__class__.min_name()))
        except Exception:
            return None

    @property
    def unit(self) -> str:
        """
        Units must be set on the chart by referencing the available projections data.
        Units are not specified as part of the chart pack.
        The units for the chart.
        """
        if not hasattr(self, "_units"):
            return None
        return self._units

    @unit.setter
    def unit(self, value: str):
        """
        Sets the units for the chart.

        Units must be set on the chart by referencing the available projections data.

        Note that units are not specified as part of the chart pack. This attribute
        can be instead set when the projections data is loaded.

        ### Arguments
        value: The new units.
        """
        if value is None:
            self._units = None
            return
        assert isinstance(value, str), "Units must be a string."
        self._units = value

    def add_series(self, series: Series):
        """
        ### Overview

        Add the next series to the chart.

        ### Arguments

        series: The series to add to the chart.

        ### Exceptions

        Limits the number of series in a chart to a maximum of 27.

        """
        if not hasattr(self, "_series"):
            self._series = []
        assert series is not None, "Series must not be None."
        assert isinstance(
            series, Series
        ), f"Object must be a series to be added to a chart but it was a {type(series)}."
        self._series.append(series)
        assert (
            len(self._series) <= 27
        ), f"Chart {self.label} has too many series. A maximum of 27 series are allowed."

    @property
    def variables_in_chart(self) -> list[str]:
        """
        ### Returns
        The list of all variable names in the chart.
        """
        variable_names = []
        for series in self.series:
            variable_names.append(series.variable_name)
        return variable_names


class ChartPack(ChartPackObject):
    """

    ### Overview

    Defines a chart-pack for G-Cubed graphing. The chart pack
    is a list of charts. Each chart is a line chart with a specified
    set of series and a specified set of properties.

    """

    _default_start_year = None
    _default_end_year = None

    def __init__(self, details: pd.DataFrame) -> None:
        """

        ### Constructor

        Initialises the chartpack details from a chart pack definition CSV file.

        See the information at
        [G-Cubed documentation website ](https://documentation.gcubed.com/)
        for details of the format of the CSV file used
        to define the chart pack.

        ### Arguments
        details: the dataframe containing the chart pack details.

        ### Exceptions

        Raises an exception if the chart pack details are not provided.

        Raises an exception if the chart pack details are not a dataframe.

        Raises an exception if one of the mandatory columns is missing.

        Raises an exception if the values in the id column are not unique.

        Raises an exception if the chart pack details contains objects that are not
        of type `pack`, `chart` or `series`.

        """

        super().__init__()

        assert details is not None, "Chart pack details must be provided."
        assert isinstance(
            details, pd.DataFrame
        ), "Chart pack details must be provided in a dataframe."

        for column in __class__.required_columns():
            assert (
                column in details.columns
            ), f"Chart pack details must contain a column named {column}."

        # Make sure that the type column only contains valid values.
        assert (
            details[__class__.type_column()].isin(self.allowed_types).all()
        ), f"The chart pack has row with invalid type {details[__class__.type_column()]}. Type must be one of {self.allowed_types}."

        if "Error" in details.columns:
            assert (
                False
            ), f"Error while parsing the chart pack definition. {details['Error'][0]}"

        # Load the charts and their series into the data pack.
        current_chart: Chart = None
        current_series: Series = None
        for index, row in details.iterrows():
            match row[__class__.type_column()]:
                case self.pack_type:
                    assert (
                        current_chart is None
                    ), "The chart pack details must be defined in the first row."
                    assert (
                        current_series is None
                    ), "The chart pack details must be defined in the first row."
                    self.set_pack_details(row)
                    continue

                case self.chart_type:
                    if current_chart is not None:
                        assert (
                            current_series is not None
                        ), f"Chart {current_chart.label} must have at least one series."
                        self.add_chart(chart=current_chart)
                    current_chart = Chart(chart_details=row)
                    current_series = None
                    continue

                case self.series_type:
                    current_series: Series = Series(series_details=row)
                    current_chart.add_series(series=current_series)
                    continue

                case _:
                    assert (
                        False
                    ), f"Found an unrecognised chart pack row: {row[__class__.type_column()]}. Rows should define a pack, chart or series"
        assert (
            current_chart is not None
        ), "The chart pack must contain at least one chart."

        if current_chart is not None:
            self.add_chart(chart=current_chart)

    def set_pack_details(self, pack_details: pd.Series):
        """
        ### Overview
        Set the details for the chart pack.

        ### Arguments
        pack_details: The series containing the chart pack label and attributes.

        """
        assert pack_details is not None, "Chart pack details must be provided."
        assert isinstance(
            pack_details, pd.Series
        ), "Chart pack details must be provided in a series."

        for column in __class__.required_columns():
            if not column in pack_details.index:
                raise Exception(f"Pack details must contain a value for {column}.")

        if not pack_details[__class__.label_column()]:
            raise Exception("The pack must have a label.")

        self.label: str = str(pack_details[__class__.label_column()])

        attributes_data: any = pack_details[__class__.attributes_column()]
        if attributes_data is not None and isinstance(attributes_data, str):
            self.populate_attributes(data=str(attributes_data))

        assert not self.has_attribute(
            __class__.color_name
        ), f"Data packs cannot have a color attribute. Use color attributes on series instead."

        # validate the date range if provided.
        if self.start_year is not None and self.end_year is not None:
            assert (
                self.start_year <= self.end_year
            ), f"The chart {self.label} start year {self.start_year} must be before the end year, {self.end_year}."

    def add_chart(self, chart: Chart):
        """
        ### Overview
        Add the next chart to the chart pack.

        ### Arguments
        chart: The chart to add to the chart pack.

        """
        if not hasattr(self, "_charts"):
            self._charts = []
        assert chart is not None, "Chart must not be None."
        assert isinstance(
            chart, Chart
        ), f"Object must be a chart to be added to a pack but it was a {type(chart)}."
        self._charts.append(chart)

    @property
    def variables_in_pack(self) -> list[str]:
        """
        The list of all variable names in the chart pack.
        """
        variable_names = []
        for chart in self.charts:
            for series in chart.series:
                variable_names.append(series.variable_name)
        return variable_names
