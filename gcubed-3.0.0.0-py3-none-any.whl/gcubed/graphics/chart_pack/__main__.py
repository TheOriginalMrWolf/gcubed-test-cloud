from gcubed.graphics.charts.chart_pack_app import run_server

run_server()
