from .chart_pack_app import run_server

run_server()
