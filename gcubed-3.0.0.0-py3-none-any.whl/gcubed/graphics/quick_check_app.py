# coding=gbk
# Time Created: 2023/6/28 21:24
# Author  : Lucid
# FileName: quick_check_app.py
# Software: PyCharm
import pandas as pd
import webbrowser
import base64
import io
import dash
from dash import Dash, dcc, html, Input, Output, State
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
import threading


def open_browser():
    webbrowser.open_new("http://127.0.0.1:8050/")


def parse_contents(contents, filename):
    content_type, content_string = contents.split(",")
    decoded = base64.b64decode(content_string)
    if "csv" in filename:
        # Convert to DataFrame
        df = pd.read_csv(io.StringIO(decoded.decode("utf-8")))

        # Determine the index of the first column that can be converted to integer (representing the year)
        start_index = 0
        for i, col in enumerate(df.columns):
            try:
                int(col)
                start_index = i
                break
            except ValueError:
                continue
        return pd.read_csv(
            io.StringIO(decoded.decode("utf-8")), index_col=list(range(start_index))
        )
    else:
        return None


app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.title = "G-Cubed Chart"
app.layout = dbc.Container(
    [
        html.H1(children="G-Cubed Chart"),
        dbc.Row(
            [
                dbc.Col(
                    [
                        dcc.Upload(
                            id="upload-data",
                            children=html.Div(
                                ["Upload ", html.A("a projections CSV file")]
                            ),
                            style={
                                "width": "100%",
                                "height": "60px",
                                "lineHeight": "60px",
                                "borderWidth": "1px",
                                "borderStyle": "dashed",
                                "borderRadius": "5px",
                                "textAlign": "center",
                                "margin": "10px",
                            },
                            multiple=False,
                        ),
                        html.Label(
                            "File status: ",
                            style={"font-size": "20px", "font-weight": "bold"},
                        ),
                        html.Div(id="file-name"),
                        html.Label(
                            "Variable Selection:",
                            style={"font-size": "20px", "font-weight": "bold"},
                        ),
                        html.Label(
                            "format: variable name (description) (unit) (vector type) (region)",
                        ),
                        dcc.Dropdown(id="dropdown", placeholder="Type or select..."),
                        dcc.Checklist(
                            id="limit-vector-checkbox",
                            options=[
                                {
                                    "label": "Limit search by variable type (vector)",
                                    "value": "use_vectors",
                                    "disabled": True,
                                }
                            ],
                            labelStyle={"display": "inline-block"},
                        ),
                        dcc.Checklist(
                            id="limit-region-checkbox",
                            options=[
                                {
                                    "label": "Limit search by region",
                                    "value": "use_regions",
                                }
                            ],
                            labelStyle={"display": "inline-block"},
                        ),
                        dcc.Checklist(
                            id="limit-unit-checkbox",
                            options=[
                                {"label": "Limit search by units", "value": "use_units"}
                            ],
                            labelStyle={"display": "inline-block"},
                        ),
                        html.Label("Vector", id="vector-label"),
                        dcc.Dropdown(id="vector-dropdown", style={"display": "none"}),
                        html.Label("Region", id="region-label"),
                        dcc.Dropdown(id="region-dropdown", style={"display": "none"}),
                        html.Label("Unit", id="unit-label"),
                        dcc.Dropdown(id="unit-dropdown", style={"display": "none"}),
                        html.Label(
                            "Second Variable Selection:",
                            style={"font-size": "20px", "font-weight": "bold"},
                        ),
                        html.Label(id="second-variable-unit-note"),
                        dcc.Dropdown(id="dropdown-2"),
                        html.Label(
                            "Graphing options:",
                            style={"font-size": "20px", "font-weight": "bold"},
                        ),
                        html.Br(),
                        html.Label("Start year"),
                        dcc.Input(
                            id="start-year",
                            type="number",
                            value=2018,
                            style={"margin-right": "10px"},
                        ),
                        html.Label("End year"),
                        dcc.Input(id="end-year", type="number", value=2050),
                        html.Br(),
                        html.Label(
                            "Set Years:",
                            style={"margin-right": "10px", "margin-top": "10px"},
                        ),
                        dbc.Button(
                            "Default (2018-2050)",
                            id="default-button",
                            n_clicks=0,
                            style={"margin-right": "10px"},
                        ),
                        dbc.Button(
                            "Full Range",
                            id="full-range-button",
                            n_clicks=0,
                            disabled=True,
                        ),
                    ]
                )
            ]
        ),
        dbc.Row([dbc.Col([dcc.Graph(id="graph")])]),
        dcc.Store(id="start-year-store"),
        dcc.Store(id="end-year-store"),
        dcc.Store(id="projections-data-store"),
    ]
)


@app.callback(
    Output("projections-data-store", "data"),
    [Input("upload-data", "contents")],
    State("upload-data", "filename"),
)
def store_parsed_data(contents, filename):
    if contents is None:
        return dash.no_update
    df = parse_contents(contents, filename)
    if df is None:
        return dash.no_update
    return df.to_json(orient="table")


@app.callback(
    Output("graph", "figure"),
    [
        Input("dropdown", "value"),
        Input("dropdown-2", "value"),
        Input("start-year-store", "data"),
        Input("end-year-store", "data"),
        Input("projections-data-store", "data"),
    ],
)
def update_graph(variable_1, variable_2, start_year, end_year, contents):
    if contents is None or variable_1 is None:
        return go.Figure()
    df = pd.read_json(contents, orient="table")
    if df is None:
        return go.Figure()

    # Split the selected value into variable and unit
    variable, unit = variable_1.split(":")
    unit = df.index.get_level_values("units")[df.index.get_level_values(0) == variable][
        0
    ]

    if variable not in df.index:
        return go.Figure()

    # Convert start_year and end_year to str and check if they exist in df's columns
    start_year = str(start_year) if str(start_year) in df.columns else df.columns[0]
    end_year = str(end_year) if str(end_year) in df.columns else df.columns[-1]

    df_var_1 = df.loc[variable, start_year:end_year]
    fig = go.Figure()
    for idx, row in df_var_1.iterrows():
        fig.add_trace(
            go.Scatter(
                x=row.index, y=row.values, mode="lines", name=f"{idx[0]} ({idx[1]})"
            )
        )

    # Check if all values in the dataframe are less than 1e-12 in absolute value
    if (df_var_1.abs() < 1e-12).all().all():
        fig.update_layout(
            yaxis_title=unit,
            yaxis_range=[-1, 1],
            title=f"Chart for {variable}",
            title_x=0.5,
        )
    else:
        fig.update_layout(yaxis_title=unit, title=f"Chart for {variable}", title_x=0.5)

    if variable_2:
        variable_2_name, unit_2 = variable_2.split(":")
        df_var_2 = df.loc[variable_2_name, start_year:end_year]
        for idx, row in df_var_2.iterrows():
            fig.add_trace(
                go.Scatter(
                    x=row.index,
                    y=row.values,
                    mode="lines",
                    name=f"{idx[0]} ({idx[1]}) - Var 2",
                )
            )
        if (df_var_2.abs() < 1e-12).all().all():
            fig.update_layout(
                yaxis_title=unit,
                yaxis_range=[-1, 1],
                title=f"Chart for {variable} and {variable_2_name}",
                title_x=0.5,
            )
        else:
            fig.update_layout(
                yaxis_title=unit,
                title=f"Chart for {variable} and {variable_2_name}",
                title_x=0.5,
            )

    return fig


@app.callback(
    Output("file-name", "children"),
    Output("dropdown", "options"),
    Output("unit-dropdown", "options"),
    Output("vector-dropdown", "options"),
    Output("region-dropdown", "options"),
    Output("limit-vector-checkbox", "options"),
    Output("dropdown-2", "options"),
    Output("second-variable-unit-note", "children"),
    [
        Input("projections-data-store", "data"),
        Input("unit-dropdown", "value"),
        Input("limit-unit-checkbox", "value"),
        Input("vector-dropdown", "value"),
        Input("limit-vector-checkbox", "value"),
        Input("region-dropdown", "value"),
        Input("limit-region-checkbox", "value"),
        Input("dropdown", "value"),
    ],
    State("upload-data", "filename"),
)
def update_dropdown(
    data,
    selected_unit,
    use_units,
    selected_vector,
    use_vectors,
    selected_region,
    use_regions,
    selected_variable,
    filename,
):
    if not data:
        return (
            "No file selected. Please upload a CSV projections file (levels or deviations).",
            [],
            [],
            [],
            [],
            [
                {
                    "label": "Limit search by variable type (vector)",
                    "value": "use_vectors",
                    "disabled": True,
                }
            ],
            [],
            [],
        )
    df = pd.read_json(data, orient="table")
    if df is None:
        return (
            f"Invalid file: {filename}. Please select a CSV file.",
            [],
            [],
            [],
            [],
            [
                {
                    "label": "Limit search by variable type (vector)",
                    "value": "use_vectors",
                    "disabled": True,
                }
            ],
            [],
            [],
        )

    # find the position of 'units' in the index
    units_pos = list(df.index.names).index("units")

    # try finding the position of 'vector' in the index
    try:
        vector_pos = list(df.index.names).index("vector")
        vector_disabled = False
    except ValueError:
        vector_pos = None
        vector_disabled = True

    # try finding the position of 'region' in the index
    try:
        region_pos = list(df.index.names).index("region")
    except ValueError:
        region_pos = None

    options = []
    for idx in df.index.unique():
        variable_info = idx  # variable_info is now the tuple index

        label_parts = []
        for part in variable_info[1:]:
            label_parts.append(f" ({part})")
        label = f"{variable_info[0]}" + "".join(label_parts)

        unit = variable_info[units_pos]
        if region_pos is not None:
            region = variable_info[region_pos]
            if use_regions and selected_region and region != selected_region:
                continue

        if not vector_disabled:
            vector = variable_info[vector_pos]
            if use_units and selected_unit and unit != selected_unit:
                continue
            if use_vectors and selected_vector and vector != selected_vector:
                continue
            value = f"{variable_info[0]}:{unit}"

            options.append({"label": label, "value": value})
        else:
            if use_units and selected_unit and unit != selected_unit:
                continue
            value = f"{variable_info[0]}:{unit}"

            options.append({"label": label, "value": value})

    units = df.index.get_level_values(units_pos).unique().tolist()
    unit_options = [{"label": unit, "value": unit} for unit in units]
    regions = df.index.get_level_values(region_pos).unique().tolist()
    region_options = [{"label": region, "value": region} for region in regions]

    if not vector_disabled:
        limit_vector_label = "Limit search by variable type (vector)"
        vectors = df.index.get_level_values(vector_pos).unique().tolist()
        vector_options = [{"label": vector, "value": vector} for vector in vectors]
    else:
        limit_vector_label = "Limit search by variable type (vector) is disabled because not provided in csv."
        vector_options = []

    limit_vector_options = [
        {
            "label": limit_vector_label,
            "value": "use_vectors",
            "disabled": vector_disabled,
        }
    ]

    # Getting the unit for the second dropdown based on the first dropdown's selection
    if selected_variable:
        selected_unit = selected_variable.split(":")[1]
        unit_note = f"Limited to the unit: {selected_unit} (same as first variable)"
    else:
        selected_unit = None
        unit_note = ""

    # Filtering options for the second dropdown based on the selected unit
    options_2 = [opt for opt in options if opt["value"].split(":")[1] == selected_unit]

    return (
        f"Selected projections file: {filename}",
        options,
        unit_options,
        vector_options,
        region_options,
        limit_vector_options,
        options_2,
        unit_note,
    )


@app.callback(
    [Output("unit-dropdown", "style"), Output("unit-label", "style")],
    [Input("limit-unit-checkbox", "value")],
)
def toggle_unit_dropdown(use_units):
    if use_units:
        return {"display": "block"}, {"display": "block"}
    else:
        return {"display": "none"}, {"display": "none"}


@app.callback(
    [Output("vector-dropdown", "style"), Output("vector-label", "style")],
    [Input("limit-vector-checkbox", "value")],
)
def toggle_vector_dropdown(use_vectors):
    if use_vectors:
        return {"display": "block"}, {"display": "block"}
    else:
        return {"display": "none"}, {"display": "none"}


@app.callback(
    [Output("region-dropdown", "style"), Output("region-label", "style")],
    [Input("limit-region-checkbox", "value")],
)
def toggle_region_dropdown(use_regions):
    if use_regions:
        return {"display": "block"}, {"display": "block"}
    else:
        return {"display": "none"}, {"display": "none"}


@app.callback(
    Output("full-range-button", "disabled"), [Input("upload-data", "contents")]
)
def toggle_full_range_button(contents):
    if contents is None:
        return True
    else:
        return False


@app.callback(
    Output("start-year-store", "data"),
    Output("end-year-store", "data"),
    [Input("start-year", "value"), Input("end-year", "value")],
)
def update_year_stores(start_year, end_year):
    return start_year, end_year


@app.callback(
    [Output("start-year", "value"), Output("end-year", "value")],
    [
        Input("default-button", "n_clicks"),
        Input("full-range-button", "n_clicks"),
        Input("upload-data", "contents"),
    ],
    [
        State("upload-data", "filename"),
        State("start-year", "value"),
        State("end-year", "value"),
    ],
)
def update_years(
    default_clicks, full_range_clicks, contents, filename, start_year, end_year
):
    ctx = dash.callback_context
    button_id = ctx.triggered[0]["prop_id"].split(".")[0]

    if button_id == "default-button":
        return 2018, 2050
    elif button_id == "full-range-button":
        if contents is not None:
            df = parse_contents(contents, filename)
            if df is not None:
                return int(df.columns[0]), int(df.columns[-1])
        return dash.no_update, dash.no_update
    elif button_id == "upload-data":
        if contents is not None:
            df = parse_contents(contents, filename)
            if df is not None:
                new_start_year = int(df.columns[0])
                new_end_year = int(df.columns[-1])

                if (
                    new_start_year <= start_year <= new_end_year
                    and new_start_year <= end_year <= new_end_year
                ):
                    return start_year, end_year

                return new_start_year, new_end_year
        return dash.no_update, dash.no_update
    else:
        return dash.no_update, dash.no_update


def run_server():
    threading.Timer(1, open_browser).start()
    app.run_server(debug=False)


if __name__ == "__main__":
    run_server()
