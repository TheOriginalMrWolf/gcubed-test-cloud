"""
This module contains the ` BaselineRunner` class - used to get baseline 
projections from a G-Cubed model and to save various intermediate outputs
into the model's data directory.
"""

import os
import logging
from gcubed.runners.simple_runner import SimpleRunner


class BaselineRunner(SimpleRunner):
    """
    ### Overview

    This is a simple runner that saves intermediate model information
    into the model's data directory.

    Note that no experiments are run.

    """

    def __init__(self, working_directory: str, configuration_file: str):
        """
        ### Constructor

        When the constructor is called, the runner loads the configuration
        and the model, ready for running. Call the run method
        when you are ready to create the baseline projections.

        ### Arguments

        `working_directory`: The directory where the results
        and logs are to be stored.

        `configuration_file`: The location of the configuration
        file, as an absolute path or relative to the
        specified working directory.


        ### Exceptions

        Raises exceptions if the working directory is not specified correctly.

        Raises exceptions if the configuration file is not specified correctly.

        """
        super().__init__(
            working_directory=working_directory,
            configuration_file=configuration_file,
        )

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing
        the experiment.

        Call this method after setting up the runner.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """
        super().run()
