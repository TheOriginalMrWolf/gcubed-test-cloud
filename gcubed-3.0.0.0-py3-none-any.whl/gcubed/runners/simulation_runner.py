"""
This module contains the `SimulationRunner` class - used to run 
simulation experiments that build on an existing baseline projection.

It supports the types of experiments that could be done using the 
Ox implementation of G-Cubed.
"""

import os
import logging
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer import SimulationLayer
from gcubed.runners.advanced_runner import AdvancedRunner


class SimulationRunner(AdvancedRunner):
    """
    ### Overview

    Runs a simulation experiment, building simulation layers on top of
    a single set of baseline projections.

    1. The baseline projections are loaded. This means that the one set of
    baseline projections can be res-used across multiple simulation runners.
    2. The experiment design is loaded, setting out each of the events being
    simulated as a separate simulation layer.
    3. The simulation layers are loaded and applied to the model to generate
    projection updates.

    Projections based on any of the simulation layers can be compared to projections
    from the baseline or from other simulation layers associated with the experiment.

    Note that the model has already been solved in the baseline projections.
    There is no scope to do any adjustments to linearisations etc.

    You can run new simulation experiments with this simulation runner after it has
    been created, by simply updating the experiment_design_file. That resets the runner
    to its initial state, ready for a new run.

    """

    def __init__(
        self,
        baseline_projections: BaselineProjections,
        experiment_design_file: str = None,
    ):
        """
        ### Constructor

        When the constructor is called, the runner loads the configuration
        and the model, ready for running. Call the run method
        when you are ready to start model linearisation etc. after having set
        properties for the runner to determine its behaviour, for example, how
        linearisation is done in relation to the neutral real interest rate.

        The relinearisation of the model is done for each event year associated with
        a simulation layer and for each year nominated for relinearisation.

        ### Arguments

        `baseline_projections`: The baseline projections to be used as the basis for the simulation.

        `experiment_design_file`: The location of the
        experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations directory
        within the model directory (the model directory contains
        the configuration file).


        ### Exceptions

        Raises exceptions if the baseline projections are not specified correctly.

        Raises exceptions if the experiment design file is not specified correctly.
        """

        self._save_results = False
        self.start_projections_from_the_neutral_real_interest_rate = True
        self.linearise_around_the_neutral_real_interest_rate = True
        self.relinearise_around_the_neutral_real_interest_rate = True
        self.relinearise_in_event_years = False
        self._completed_successfully: bool = False

        assert (
            baseline_projections is not None
        ), "You must specify baseline projections."

        assert isinstance(
            baseline_projections, BaselineProjections
        ), "The baseline projections must be a BaselineProjections object."

        self._original_baseline_projections = baseline_projections

        # Set the model property
        self._model = self.original_baseline_projections.model

        # # Set up the model directory and check it still exists.
        # self._model_directory: str = self.model.configuration.model_directory

        # # Store the baseline projections
        # self._all_projections: list[Projections] = []

        # assert os.path.exists(
        #     self._model_directory
        # ), f"Model directory '{self.model_directory}' does not exist on your computer."

        # assert os.path.isdir(
        #     self.model_directory
        # ), f"'{self.model_directory}' exists but it is not a valid directory."

        # absolute_working_directory: str = os.path.abspath(working_directory)

        # assert os.path.exists(
        #     absolute_working_directory
        # ), f"Working directory '{absolute_working_directory}' does not exist on your computer."

        # assert os.path.isdir(
        #     absolute_working_directory
        # ), f"'{absolute_working_directory}' exists but it is not a valid directory."

        # if not os.access(absolute_working_directory, os.W_OK):
        #     raise Exception(
        #         f"You need write access to {absolute_working_directory} but that permission has not been granted to you."
        #     )

        # Validate and save the list of relinearisation years.
        self._relinearisation_years = []

        # Save the experiment design file for later use.
        self.experiment_design_file = experiment_design_file

    @property
    def original_baseline_projections(self) -> BaselineProjections:
        """
        Returns the original baseline projections that the simulation layer build on.
        """
        return self._original_baseline_projections

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing
        the experiment.

        Call this method after setting up the runner.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """

        self._all_projections = [self.original_baseline_projections]

        # Load the simulation layer definitions from the experiment design file.
        self._simulation_layer_definitions = SimulationLayerDefinitions(
            sym_data=self.model.sym_data
        )
        if self.experiment_design_file is not None:
            self.simulation_layer_definitions.load_from_csv_file(
                design_file=self.experiment_design_file
            )

        # Get the event years associated with the simulation layers.
        self._event_years = (
            self.simulation_layer_definitions.all_event_years_in_ascending_order
        )

        # Step forward through the projection years and for each step:
        # check if we need to do a relinearisation. Then do any simulations
        # for that year that have that year as their event year.
        for year in self.event_years:
            for (
                simulation_layer_definition
            ) in self.simulation_layer_definitions.get_simulation_layer_definitions(
                event_year=year
            ):
                self.all_projections.append(
                    SimulationLayer(
                        simulation_layer_definition=simulation_layer_definition,
                        previous_projections=self.most_recently_generated_projections,
                    )
                )
                logging.info(
                    f"Added {simulation_layer_definition.name} simulation layer to projections from {self.most_recently_generated_projections.first_projection_year}."
                )

        self._completed_successfully = True

        logging.info(f"The run has completed.")
