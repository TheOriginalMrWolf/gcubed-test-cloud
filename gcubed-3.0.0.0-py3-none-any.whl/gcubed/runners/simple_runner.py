"""
This module contains the `SimpleRunner` class - used to run 
standard G-Cubed experiments.

It supports the types of experiments that could be done using the 
Ox implementation of G-Cubed.
"""

import os
import logging
from gcubed.linearisation.solved_model import SolvedModel
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer import SimulationLayer
from gcubed.runners.advanced_runner import AdvancedRunner


class SimpleRunner(AdvancedRunner):
    """
    ### Overview

    Runs a simplified simulation experiment.

    1. The model is loaded and used to generate baseline projections.
    2. The experiment design is loaded, setting out each of the events being
    simulated as a separate simulation layer.
    3. The simulation layers are loaded and applied to the model to generate
    projection updates.

    Projections based on any of the simulation layers can be compared to projections
    from the baseline or from other simulation layers associated with the experiment.

    This simple runner has the following limitations compared to the advanced runner:

    1. No relinearisations of the model in years after the first projection year.
    2. Linearisation is done around initial database values instead of a "strict model solution".
    3. Interest rates are adjusted to their long-run inflation-neutral values before doing linearisation.
    4. Interest rates are set to their long-run inflation-neutral values at the start of projections
    and this adjustment to interest rates is eliminated using constant adjustments to interest rates,
    once the full set of baseline projections have been generated.

    These limitations are imposed when the run is triggered. Warnings are issued if users try to
    override these limitations.

    """

    def __init__(
        self,
        working_directory: str,
        configuration_file: str,
        experiment_design_file: str = None,
    ):
        """
        ### Constructor

        When the constructor is called, the runner loads the configuration
        and the model, ready for running. Call the run method
        when you are ready to start model linearisation etc. after having set
        properties for the runner to determine its behaviour, for example, how
        linearisation is done in relation to the neutral real interest rate.

        ### Arguments

        `working_directory`: The directory where the results
        and logs are to be stored.

        `configuration_file`: The location of the configuration
        file, as an absolute path or relative to the
        specified working directory.

        `experiment_design_file`: The optional location of the
        experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations directory
        within the model directory (the model directory contains
        the configuration file).

        ### Exceptions

        Raises exceptions if the working directory is not specified correctly.

        Raises exceptions if the configuration file is not specified correctly.

        Raises exceptions if the experiment design file is not specified correctly.
        """

        super().__init__(
            working_directory=working_directory,
            configuration_file=configuration_file,
            experiment_design_file=experiment_design_file,
        )

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing
        the experiment.

        Call this method after setting up the runner.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """

        # Lock down interest rate adjustments (make the advanced runner do a simplified run.)
        if self.linearise_around_strict_model_solution:
            logging.warning(
                "This runner does not support linearisation around the strict model solution."
            )
        self.model.configuration.linearise_around_strict_model_solution = False

        if not self.linearise_around_the_neutral_real_interest_rate:
            logging.warning(
                "This runner requires the baseline projections to linearisation around neutral interest rates."
            )

        if not self.start_projections_from_the_neutral_real_interest_rate:
            logging.warning(
                "This runner requires the baseline projections to start from neutral interest rates."
            )

        # Load the simulation layer definitions from the experiment design file.
        self._simulation_layer_definitions = SimulationLayerDefinitions(
            sym_data=self.model.sym_data
        )
        if self.experiment_design_file is not None:
            self.simulation_layer_definitions.load_from_csv_file(
                design_file=self.experiment_design_file
            )

        # Do a first baseline projection if required
        self._all_projections = [
            BaselineProjections(
                solved_model=SolvedModel(
                    model=self.model,
                    linearise_around_the_neutral_real_interest_rate=True,
                ),
                start_from_neutral_real_interest_rate=True,
            )
        ]
        logging.info(
            f"Generated original baseline projections from {self.baseline_projections.first_projection_year}."
        )

        # Get the event years associated with the simulation layers.
        self._event_years = (
            self.simulation_layer_definitions.all_event_years_in_ascending_order
        )

        # Step forward through the projection years and for each step:
        # check if we need to do a relinearisation. Then do any simulations
        # for that year that have that year as their event year.
        for year in self.event_years:
            for (
                simulation_layer_definition
            ) in self.simulation_layer_definitions.get_simulation_layer_definitions(
                event_year=year
            ):
                self.all_projections.append(
                    SimulationLayer(
                        simulation_layer_definition=simulation_layer_definition,
                        previous_projections=self.most_recently_generated_projections,
                    )
                )
                logging.info(
                    f"Added {simulation_layer_definition.name} simulation layer to projections from {self.most_recently_generated_projections.first_projection_year}."
                )

        self._completed_successfully = True

        logging.info(f"The run has completed.")
