"""
This module contains the `AdvancedRunner` class, for running
experiments using G-Cubed.
"""

import os
import logging
import gcubed
from gcubed.base import Base
from gcubed.linearisation.solved_model import SolvedModel
from gcubed.model_configuration import ModelConfiguration
from gcubed.model import Model
import gcubed
import gcubed.projections
from gcubed.projections.projections import Projections
from gcubed.projections.model_updater import ModelUpdater
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions
from gcubed.projections.simulation_layer import SimulationLayer


class AdvancedRunner(Base):
    """

    ### Overview

    ** This runner is still experimental. **

    The AdvancedRunner class runs a simulation experiment
    with G-Cubed that incorporates relinearisation in chosen years while
    allowing for strict or non-strict choice of points to linearise around
    and supporting simulation experiments using or not using relinearisation
    in their event years.

    1. The model is loaded and used to generate baseline projections.
    2. The experiment design is loaded, setting out each of the events being
    simulated as a separate simulation layer.
    3. The simulation layers are loaded and applied to the model to generate
    projection updates.

    Projections based on any of the simulation layers can be compared to projections
    from the baseline or from other simulation layers associated with the experiment.

    #### Note: Determine behaviour with regard to neutral real interest rates
    by setting the `AdvancedRunner.linearise_around_the_neutral_real_interest_rate` and
    the `AdvancedRunner.start_projections_from_the_neutral_real_interest_rate` and the
    `AdvancedRunner.relinearise_around_the_neutral_real_interest_rate` properties
    before triggering the model run by calling `AdvancedRunner.run`. The default
    behaviour is to:

    * use neutral real interest rates for linearisation
    * start the projections from the neutral real interest rate and
    * relinearise around the neutral real interest rate.

    """

    def __init__(
        self,
        working_directory: str,
        configuration_file: str,
        relinearisation_years: list[int] = [],
        experiment_design_file: str = None,
    ):
        """
        ### Overview

        When the constructor is called, the runner loads the configuration
        and the model, ready for running. Call the run method
        when you are ready to start model linearisation etc. after having set
        properties for the runner to determine its behaviour, for example, how
        linearisation is done in relation to the neutral real interest rate.

        The relinearisation of the model is done for each event year associated with
        a simulation layer and for each year nominated for relinearisation.

        ### Arguments

        `working_directory`: The directory where the results
        and logs are to be stored.

        `configuration_file`: The location of the configuration
        file, as an absolute path or a path that is relative to the
        working directory. The configuration file is the CSV file that
        contains the model configuration. It must be in the model directory,
        which is the root directory of the model folder structure.

        `relinearisation_years`: The list of years where a
        relinearisation is required. This list can be empty
        in which case the model is not relinearised. To generate a
        list of years, from 2018 to say, 2030, you can supply the
        following as as this parameter value:
        `list(range(2018, 2031))`. (Note that the upper bound is not
        included in the range.) Defaults to the empty list.

        `experiment_design_file`: The optional location of the
        experiment design CSV file. This must be a relative path directory
        to the experiment design file from the simulations directory
        within the model directory (the model directory contains
        the configuration file). Defaults to `None`.

        ### Exceptions

        Raises exceptions if the working directory is not specified correctly.

        Raises exceptions if the configuration file is not specified correctly.

        Raises exceptions if the relinearisation years are not specified correctly.

        Raises exceptions if the experiment design file is not specified correctly.

        """

        self._all_projections: list[Projections] = []

        self.start_projections_from_the_neutral_real_interest_rate = True
        self.linearise_around_the_neutral_real_interest_rate = True
        self.relinearise_around_the_neutral_real_interest_rate = True

        self.relinearise_in_event_years = False

        self._completed_successfully: bool = False

        self._working_directory: str = os.path.abspath(working_directory)

        assert os.path.exists(
            self.working_directory
        ), f"Working directory '{self.working_directory}' does not exist on your computer. Your current working directory is {os.getcwd()}"

        assert os.path.isdir(
            self.working_directory
        ), f"'{self.working_directory}' exists but it is not a valid directory. Your current working directory is {os.getcwd()}"

        assert os.access(
            self.working_directory, os.W_OK
        ), f"You need write access to {self.working_directory} but that permission has not been granted to you."

        # Get the absolute path to the model configuration file.
        if os.path.isabs(configuration_file):
            self._configuration_file: str = configuration_file
        else:
            self._configuration_file: str = os.path.join(
                self.working_directory, configuration_file
            )
        assert os.path.isfile(
            self._configuration_file
        ), f"There is no model configuration file at {self.configuration_file}."

        assert self.configuration_file.endswith(
            ".csv"
        ), f"The model configuration must be a CSV file."

        assert os.access(
            self.configuration_file, os.R_OK
        ), f"You need read access to {self.configuration_file} but that permission has not been granted to you."

        # Set the model directory as the directory that contains the model configuration file.
        self._model_directory: str = os.path.dirname(
            os.path.abspath(self.configuration_file)
        )

        # Load the model
        model_configuration: ModelConfiguration = ModelConfiguration(
            configuration_file=self.configuration_file
        )
        self._model: Model = Model(model_configuration)

        # Validate and save the list of relinearisation years.
        assert isinstance(
            relinearisation_years, list
        ), f"You must specify a list of years in which the model is to be relinearised."

        if len(relinearisation_years) > 0:
            for year in relinearisation_years:
                assert isinstance(
                    year, int
                ), f"The list of relinearisation years must contain YYYY formatted integers, but it contains {year}."

            assert len(relinearisation_years) == len(
                set(relinearisation_years)
            ), "There must not be duplicate relinearisation years."

            assert relinearisation_years == sorted(
                relinearisation_years
            ), "The list of relinearisation years must be in ascending order."

            assert (
                relinearisation_years[0] > model_configuration.first_projection_year
            ), "The relinearisation years must be after the first projection year."

            assert (
                relinearisation_years[-1] < model_configuration.last_projection_year
            ), "The relinearisation years must be before the last projection year."

        self._relinearisation_years = relinearisation_years

        # Set the experiment design file, if provided, for later use.
        self.experiment_design_file = experiment_design_file

    @property
    def working_directory(self) -> str:
        """
        The working directory.

        Defaults to the Python's current directory.
        """
        if not hasattr(self, "_working_directory"):
            self._working_directory = os.path.abspath(os.getcwd())
        return self._working_directory

    @property
    def model_directory(self) -> str:
        """
        The directory that contains the model configuration file.
        """
        return self._model_directory

    @property
    def configuration_file(self) -> str:
        """
        The configuration file.
        """
        return self._configuration_file

    @property
    def experiment_design_file(self) -> str:
        """
        The experiment design file name or `None` if no experiment is to be
        run.
        """
        if not hasattr(self, "_experiment_design_file"):
            return None
        return self._experiment_design_file

    @experiment_design_file.setter
    def experiment_design_file(self, value: str) -> None:
        """
        Set the location of the experiment design file.

        Using this function to update the experiment design file resets the runner
        to its initial state, ready for a new run.
        """

        # Clear all the projections - they will need to be rerun.
        self._completed_successfully = False
        self._all_projections = []

        if value is None:
            self._experiment_design_file = None
            return

        assert isinstance(value, str), "The experiment design file must be a string."
        assert not os.path.isabs(
            value
        ), f"The experiment design file must be a relative path from the {self.model.configuration.simulations_directory} directory."

        absolute_file_location: str = os.path.join(
            self.model.configuration.simulations_directory, value
        )
        assert os.path.exists(
            absolute_file_location
        ), f"The experiment design file '{absolute_file_location}' does not exist."

        assert os.path.isfile(
            absolute_file_location
        ), f"'{absolute_file_location}' is not a file. It should be the experiment design file."

        self._experiment_design_file: str = absolute_file_location

    @property
    def model(self) -> Model:
        """
        The model being run.
        """
        return self._model

    @property
    def relinearisation_years(self) -> list[int]:
        """
        The (possibly empty) list of relinearisation years (all in YYYY format).
        """
        return self._relinearisation_years

    @relinearisation_years.setter
    def relinearisation_years(self, value: list[int]) -> bool:
        """
        ### Overview

        Set the value of the relinearisation years list to a list of integers in YYYY format.

        Note that the list of integers can be supplied using the `range()` function. For example,
        `list(range(2020,2025+1))` produces a list of integers from 2020 to 2025 inclusive.
        """
        assert value is not None, "The relinearisation years must be specified."
        assert isinstance(
            value, list
        ), f"The relinearisation years must be a list of year integers in YYYY format, not {value}"
        for year in value:
            assert isinstance(
                year, int
            ), f"The relinearisation years must be YYYY format integers, not {year}"
            assert (
                year >= 1000 and year < 10000
            ), f"The relinearisation years must be in YYYY format, not {year}"
        self._relinearisation_years = value

    @property
    def event_years(self) -> list[int]:
        """
        The (possibly empty) list of event years (all in YYYY format).
        """
        return self._event_years

    @property
    def all_projections(self) -> list[Projections]:
        """
        A list of all projections generated by the
        runner or an empty list if no projections
        have been generated by the runner when this
        property is requested. The first projections are the baseline projections
        and then the following projections are the projections generated due
        to simulation layers or relinearisations etc. added to the list as they
        are generated.

        This method will return the empty list if the runner has
        not started. If the runner is partway through the run,
        then the projections that have been produced will be available.
        """
        if not hasattr(self, "_all_projections"):
            raise Exception(
                "The list of all projections does not exist but it should. There is a bug in this runner."
            )
        return self._all_projections

    @property
    def baseline_projections(self) -> BaselineProjections:
        """
        The first baseline projections that are produced.

        Note that some runners
        will create multiple baselines:
        one per linearisation of the model.
        """
        if not self._all_projections:
            raise Exception(
                "The baseline projections are not yet available. Make sure you run the model before accessing them."
            )
        return self.all_projections[0]

    @property
    def most_recently_generated_projections(self) -> Projections:
        """
        The projections most recently generated in the run.
        """
        if not self._all_projections:
            raise Exception(
                "Projections are not yet available. Make sure you run the model before accessing them."
            )
        return self.all_projections[-1]

    @property
    def final_projections(self) -> Projections:
        """
        The final projections which can be the baseline
        projections if there was no simulation experiment to do.
        """
        if not self.completed_successfully:
            raise Exception(
                "The run has not yet completed so the final projections are not yet available."
            )
        if not self._all_projections:
            raise Exception(
                "The final projections are not yet available. Make sure you run the model before accessing them."
            )
        return self.all_projections[-1]

    @property
    def simulation_layer_definitions(self) -> SimulationLayerDefinitions:
        """
        The simulation layer definitions documented in the experiment design.
        """
        if not hasattr(self, "_simulation_layer_definitions"):
            raise Exception(
                "The simulation layer definitions have not been loaded yet."
            )
        return self._simulation_layer_definitions

    @property
    def linearise_around_strict_model_solution(self) -> bool:
        """
        `True` if the model linearisation is done around a strict model
        solution and `False` if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection.

        Set this to `False` for standard linearisation
        as has been done for G-Cubed for decades.

        Set this to `True` if the
        actual data values are to be adjusted to find similar values that exactly
        solve all of the equations in the model before then linearising around
        those similar values.

        This property defaults to to the value specified in the supplied
        model configuration file but it can be overridden. The default value
        for configurations is `False`, resulting in the standard approach to linearisation.
        """
        if not hasattr(self, "_linearise_around_strict_model_solution"):
            return self.model.configuration.linearise_around_strict_model_solution
        return self._linearise_around_strict_model_solution

    @linearise_around_strict_model_solution.setter
    def linearise_around_strict_model_solution(self, value):
        """
        ### Overview

        Set the value to True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection.

        This property defaults to to the value specified in the supplied
        model configuration file but it can be overridden.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_strict_model_solution = value

    @property
    def linearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        return self._linearise_around_the_neutral_real_interest_rate

    @linearise_around_the_neutral_real_interest_rate.setter
    def linearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_the_neutral_real_interest_rate = value

    @property
    def relinearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if  relinearisations are around the neutral real interest rate
        and `False` if they are around previous projection values
        in the relinearisation year.
        """
        return self._relinearise_around_the_neutral_real_interest_rate

    @relinearise_around_the_neutral_real_interest_rate.setter
    def relinearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the relinearisations are around the neutral real interest rate
        and `False`  if they are around previous projection values
        in the relinearisation year.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_around_the_neutral_real_interest_rate = value

    @property
    def start_projections_from_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around neutral real interest rates
        and `False` if they are around database values.

        Defaults to `True`.
        """
        if not hasattr(self, "_start_projections_from_the_neutral_real_interest_rate"):
            self.start_projections_from_the_neutral_real_interest_rate = True
        return self._start_projections_from_the_neutral_real_interest_rate

    @start_projections_from_the_neutral_real_interest_rate.setter
    def start_projections_from_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline projections start with neutral real interest rate
        and `False` if they start with database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_projections_from_the_neutral_real_interest_rate = value

    @property
    def start_relinearisation_projections_from_the_neutral_real_interest_rate(
        self,
    ) -> bool:
        """
        `True` if the relinearisation starts with neutral real interest rates
        and `False` otherwise.

        Defaults to `False`.
        """
        if not hasattr(
            self,
            "_start_relinearisation_projections_from_the_neutral_real_interest_rate",
        ):
            self.start_relinearisation_projections_from_the_neutral_real_interest_rate = (
                False
            )
        return (
            self._start_relinearisation_projections_from_the_neutral_real_interest_rate
        )

    @start_relinearisation_projections_from_the_neutral_real_interest_rate.setter
    def start_relinearisation_projections_from_the_neutral_real_interest_rate(
        self, value: bool
    ):
        """
        Set to `True` if the relinearisation starts with neutral real interest rates
        and `False` otherwise.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_relinearisation_projections_from_the_neutral_real_interest_rate = (
            value
        )

    @property
    def relinearise_in_event_years(self) -> bool:
        """
        `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.

        Defaults to `False`.

        If necessary, modify this setting once the running is instantiated but
        before the experiment is run.
        """
        return self._relinearise_in_event_years

    @relinearise_in_event_years.setter
    def relinearise_in_event_years(self, value: bool) -> bool:
        """
        ### Overview

        Set the value to `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_in_event_years = value

    @property
    def completed_successfully(self) -> bool:
        """
        `True` if the runner has completed all projections successfully and `False` otherwise.
        """
        return self._completed_successfully

    def reset(self) -> None:
        """
        ### Overview

        Reset the runner so that it has no generated projections.

        The successful completion flag is reset to `False`
        and the list of projections generated by the runner is set
        to an empty list.

        Once reset, the runner can be rerun. This is useful if you want to
        run the same runner but with alternative experiments.
        """
        self._completed_successfully = False
        self._all_projections: list[Projections] = []

    def run(self):
        """
        ### Overview

        Do the actual work of running the model and performing
        the experiment.

        Call this method after creating a Runner instance.

        Once the experiment has run, you can retrieve projections from
        the simulation layer(s) of interest and the baseline for comparison and
        analysis purposes.
        """

        # Tailor how linearisation is done - strict solution or not.
        # This affects the original baseline and all relinearisations.
        self.model.configuration.linearise_around_strict_model_solution = (
            self.linearise_around_strict_model_solution
        )

        # Load the simulation layer definitions from the experiment design file.
        self._simulation_layer_definitions = SimulationLayerDefinitions(
            sym_data=self.model.sym_data
        )
        if self.experiment_design_file is not None:
            self.simulation_layer_definitions.load_from_csv_file(
                design_file=self.experiment_design_file
            )

        # Get the event years associated with the simulation layers.
        self._event_years = (
            self.simulation_layer_definitions.all_event_years_in_ascending_order
        )

        if self.relinearise_in_event_years and self.experiment_design_file is not None:
            # augment the relinearisation years with the event years if appropriate.
            self.relinearisation_years = sorted(
                set(self.relinearisation_years).union(set(self.event_years))
            )

        # Step forward through the projection years and for each step:
        # check if we need to do a relinearisation. Then do any simulations
        # for that year that have that year as their event year.
        for year in range(
            self.model.configuration.first_projection_year,
            self.model.configuration.last_projection_year,
        ):
            # Do a first baseline projection if needed.
            if year == self.model.configuration.first_projection_year:
                solved_model: SolvedModel = SolvedModel(
                    model=self.model,
                    linearise_around_the_neutral_real_interest_rate=self.linearise_around_the_neutral_real_interest_rate,
                )
                self.all_projections.append(
                    BaselineProjections(
                        solved_model=solved_model,
                        start_from_neutral_real_interest_rate=self.start_projections_from_the_neutral_real_interest_rate,
                    )
                )
                logging.info(f"Generated original baseline projections from {year}.")

            else:
                # Do a new baseline for the relinearisation if required
                if year in self.relinearisation_years:
                    current_model: Model = ModelUpdater.get_updated_model(
                        projections=self.most_recently_generated_projections,
                        new_first_projection_year=year,
                    )
                    solved_model: SolvedModel = SolvedModel(
                        model=current_model,
                        linearise_around_the_neutral_real_interest_rate=self.relinearise_around_the_neutral_real_interest_rate,
                    )
                    self.all_projections.append(
                        BaselineProjections(
                            solved_model=solved_model,
                            start_from_neutral_real_interest_rate=self.start_relinearisation_projections_from_the_neutral_real_interest_rate,
                        )
                    )
                    logging.info(
                        f"Generated relinearised baseline projections from {year}."
                    )

            # Do simulation layers for the year
            if year in self.event_years:
                for (
                    simulation_layer_definition
                ) in self.simulation_layer_definitions.get_simulation_layer_definitions(
                    event_year=year
                ):
                    self.all_projections.append(
                        SimulationLayer(
                            simulation_layer_definition=simulation_layer_definition,
                            previous_projections=self.most_recently_generated_projections,
                        )
                    )
                    logging.info(
                        f"Added {simulation_layer_definition.name} simulation layer to projections from {self.most_recently_generated_projections.first_projection_year}."
                    )
                continue

        self._completed_successfully = True

        logging.info(f"The run has completed.")

    def save_projections(
        self,
        results_directory: str,
        publishable_projections: bool = True,
        database_projections: bool = False,
    ):
        """
        ### Overview

        Save the projections to the specified directory.

        ### Arguments

        `results_directory`: The directory where the projections are to be saved.
        `publishable_projections`: `True` if the publishable projections are to be saved. Defaults to `True`.
        `database_projections`: `True` if the database projections are to be saved. Defaults to `False`.
        """

        if not (publishable_projections or database_projections):
            logging.warning(
                f"Neither publishable nor database projections are to be saved to {results_directory}."
            )
            return

        directory: str = os.path.abspath(results_directory)
        if not os.path.exists(directory):
            try:
                os.mkdir(directory)
            except Exception as e:
                logging.warning(
                    f"Could not save runner projections in {directory}.\nCause of the problem: {e}"
                )
                return

        # Generate CSV reports
        baseline_projections: BaselineProjections = self.baseline_projections
        previous_projections: Projections = None
        counter: int = 1
        for this_projections in self.all_projections:
            if publishable_projections:
                this_projections.annotated_publishable_projections.to_csv(
                    os.path.join(
                        directory,
                        f"{counter} levels for {this_projections.name}.csv",
                    )
                )
            if database_projections:
                this_projections.annotated_database_projections.to_csv(
                    os.path.join(
                        directory,
                        f"database {counter} levels for {this_projections.name}.csv",
                    )
                )
            if previous_projections is not None:
                gcubed.projections.deviations(
                    new_projections=this_projections,
                    original_projections=previous_projections,
                ).to_csv(
                    os.path.join(
                        directory,
                        f"{counter}-{counter-1} deviations for {this_projections.name}.csv",
                    )
                )
                if previous_projections is not baseline_projections:
                    gcubed.projections.deviations(
                        new_projections=this_projections,
                        original_projections=baseline_projections,
                    ).to_csv(
                        os.path.join(
                            directory,
                            f"{counter}-1 deviations for {this_projections.name}.csv",
                        )
                    )
            previous_projections: Projections = this_projections
            counter += 1
