"""
This module contains the `CarbonCoefficients` class.
"""

import logging
import os
import os.path
from typing import final
import pandas as pd
import numpy as np
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData
from scipy.optimize import least_squares


class CarbonCoefficients(Base):
    """
    This class loads and provides access to
    carbon coefficients by sector for each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """

        ### Constructor

        ### Arguments
        sym_data: The information about the SYM model definition.

        The model configuration is accessible via this argument, thus
        enabling discovery of the location of the CSV file that contains the data.

        ### CSV file format

        TODO: Specify the CSV file format.

        ### Exceptions

        Raises an exception if the model is not suitable for carbon coefficients.

        """
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._sym_data: SymData = sym_data

        assert (
            self.sym_data.electricity_distribution_sectors_count != 0
        ), "There must be an electricity distribution sector in the model if these carbon coefficients are to be used."

        assert (
            self.sym_data.sectors_count > 12
        ), "There must be more than 12 sectors in the model if these carbon coefficients are to be used."

        self.__load_data()

        self.__validate()

    def __validate(self):
        """
        Ensure carbon coefficients meet expectations.
        """
        pass

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    def __load_data(self):
        """

        ### Overview

        Parse the CSV file to load a dictionary of dataframes, one per region.

        The dataframe rows are indexed by goods.

        The dataframe columns are indexed by sector.

        There is one column per standard sector.

        Any sectors without a column are inferred to have zero coefficients.

        Any goods without a row are inferred to have zero coefficients.

        """

        # Load the data into a dataframe
        self._filename: str = self.configuration.carbon_coefficients_file
        assert os.path.isfile(
            self._filename
        ), f"Carbon coefficients file {self._filename} does not exist."
        data: pd.DataFrame = pd.read_csv(self._filename, header=None)

        header_indices: list[int] = (
            data.where(data[0].isin(self.sym_data.regions_members)).dropna().index
        )

        # Split the dataframe into frames by region
        self._sector_coefficients: dict[str, pd.DataFrame] = {}
        self._final_demand_coefficients: dict[str, pd.DataFrame] = {}

        previous_index: int = header_indices[0]
        for index in header_indices[1:]:
            region_data: pd.DataFrame = data.loc[previous_index : (index - 1), :]
            self.populate_dictionaries(data=region_data)
            previous_index = index

        last_index: int = data.index[-1]
        region_data: pd.DataFrame = data.loc[previous_index:last_index, :]
        self.populate_dictionaries(data=region_data)

    def populate_dictionaries(self, data: pd.DataFrame):
        """
        Populate the dictionaries with data from the dataframe,
        splitting apart the sector and consumption coefficients
        and making sure that any omitted rows for energy goods
        imply zero coefficients.
        """
        region: str = data.iloc[0, 0]
        data.iat[0, 0] = None
        data.index = list(data[0])
        data.columns = list(data.iloc[0, :])
        data = data.iloc[1:, 1:]

        # If the input CSV file contains data for energy distribution sector
        # remove that data
        for sector in self.sym_data.electricity_distribution_sectors_members:
            if sector in data.columns:
                data.drop(columns=[sector], inplace=True)

        # Set up the sector coefficients
        sector_coefficients: pd.DataFrame = pd.DataFrame(
            0.0,
            index=self.sym_data.energy_goods_members,
            columns=self.sym_data.non_electricity_distribution_sectors_members,
        )

        sector_coefficients.loc[data.index, data.columns[:-1]] = data.iloc[
            :, 0:-1
        ].astype(float)
        self._sector_coefficients[region] = sector_coefficients

        # Set up the final demand coefficients
        final_demand_coefficients: pd.DataFrame = pd.DataFrame(
            0.0,
            index=self.sym_data.energy_goods_members,
            columns=["C"],
        )
        final_demand_coefficients.loc[data.index, data.columns[-1]] = np.array(
            data.iloc[:, -1].astype(float)
        )
        self._final_demand_coefficients[region] = final_demand_coefficients

    def sector_coefficients(self, region: str) -> pd.DataFrame:
        assert (
            region in self._sector_coefficients
        ), f"Sector carbon coefficients not found for region {region}."
        return self._sector_coefficients[region]

    def final_demand_coefficients(self, region: str) -> pd.DataFrame:
        assert (
            region in self._final_demand_coefficients
        ), f"Consumption carbon coefficients not found for region {region}."
        return self._final_demand_coefficients[region]

    @property
    def original_dataframe(self) -> pd.DataFrame:
        """
        Return the original data as a dataframe.
        """
        result: pd.DataFrame = None
        for region in self._sector_coefficients:
            region_data: pd.DataFrame = self.sector_coefficients(region=region)
            goods_index: list = list(region_data.index)
            goods_index.insert(0, "labels")
            region_data["C"] = self.final_demand_coefficients(region=region)
            new_row: pd.DataFrame = pd.DataFrame(
                [region_data.columns], columns=region_data.columns
            )
            region_data = pd.concat([new_row, region_data], ignore_index=True)
            region_data.insert(0, "goods", goods_index)
            region_data.reset_index(drop=True, inplace=True)
            region_data.iat[0, 0] = region
            if result is None:
                result = region_data
            else:
                result = pd.concat([result, region_data], ignore_index=True)

        return result

    def save_as_csv(self, filename: str) -> None:
        """
        Save the carbon coefficients as a CSV file in their original format.

        ### Arguments

        filename: The path and name of the CSV file to save the data to.
        """
        self.original_dataframe.to_csv(
            os.path.join(filename),
            index=False,
            header=False,
        )
