"""
Model version 20J parameter subclasses.
"""
