"""
This module contains the `EmissionsCoefficients` class.
"""

import logging
import os
import os.path
import pandas as pd
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class EmissionsCoefficients(Base):
    """
    This class loads and provides access to
    emissions coefficients by sector for each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """

        ### Constructor

        ### Arguments
        sym_data: The information about the SYM model definition.

        The model configuration is accessible via this argument, thus
        enabling discovery of the location of the CSV file that contains the data.

        ### CSV file format

        The CSV file is expected to have the following format:

        The first row contains the column labels, which are the regions codes.

        The first column contains the gas codes.

        The second column contains the good codes identifying the good associated with release of emissions.

        The third column contains the use code, identifying the sector or final consumer (C for household and G for government).

        The data is loaded into a dataframe with a multi-index for the rows, based on gas, good and use.

        ### Exceptions

        Raises an exception if the model is not suitable for emissions coefficients.

        """
        assert sym_data is not None
        assert sym_data.configuration is not None
        self._sym_data: SymData = sym_data

        assert (
            self.sym_data.electricity_distribution_sectors_count != 0
        ), "There must be an electricity distribution sector in the model if these emissions coefficients are to be used."

        assert (
            self.sym_data.sectors_count > 12
        ), "There must be more than 12 sectors in the model if these emissions coefficients are to be used."

        self.__load_data()

    @property
    def sym_data(self) -> SymData:
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        return self.sym_data.configuration

    @property
    def sectors(self) -> list[str]:
        """
        The SYM model sectors that have gas emissions.
        """
        return self.sym_data.non_electricity_generation_sectors_members

    @property
    def goods(self) -> list[str]:
        """
        The SYM model goods that cause gas emissions.
        """
        return self.sym_data.ordinary_nondurable_goods_members

    @property
    def regions(self) -> list[str]:
        """
        The SYM model regions
        """
        return self.sym_data.regions_members

    @property
    def gases(self) -> list[str]:
        """
        The SYM model gases
        """
        return self.sym_data.gases_members

    def __load_data(self):
        """

        ### Overview

        Parse the CSV files to load the data.

        """

        self._sector_input_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.sector_input_emission_intensity_file,
            header=0,
            index_col=[0, 1, 2],  # gas good sector
        )
        self._sector_labor_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.sector_labor_emission_intensity_file,
            header=0,
            index_col=[0, 1],  # gas sector
        )
        self._sector_capital_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.sector_capital_emission_intensity_file,
            header=0,
            index_col=[0, 1],  # gas sector
        )

        self._sector_output_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.sector_output_emission_intensity_file,
            header=0,
            index_col=[0, 1],  # gas sector
        )

        self._household_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.household_emission_intensity_file,
            header=0,
            index_col=[0, 1],  # gas good
        )

        self._government_emission_intensity_parameters: pd.DataFrame = pd.read_csv(
            self.configuration.government_emission_intensity_file,
            header=0,
            index_col=[0, 1],  # gas good
        )

    @property
    def data(self) -> pd.DataFrame:
        """
        Return the original data as a dataframe.
        """
        return self._sector_input_emission_intensity_parameters

    @property
    def sector_input_emission_intensity_parameters(self):
        """
        ### Returns

        The input good emission intensity parameters.
        """

        # Select all rows
        return self._sector_input_emission_intensity_parameters

    @property
    def sector_labor_emission_intensity_parameters(self):
        """
        ### Returns

        The labor emission intensity parameters.
        """

        # Select all rows
        return self._sector_labor_emission_intensity_parameters

    @property
    def sector_capital_emission_intensity_parameters(self):
        """
        ### Returns

        The capital emission intensity parameters.
        """

        # Select all rows
        return self._sector_capital_emission_intensity_parameters

    @property
    def sector_output_emission_intensity_parameters(self):
        """
        ### Returns

        The output emission intensity parameters.
        """

        # Select all rows
        return self._sector_output_emission_intensity_parameters

    @property
    def household_coefficients(self) -> pd.DataFrame:
        """
        ### Returns

        The full set of household emission intensity parameters.
        """
        return self._household_emission_intensity_parameters

    @property
    def government_coefficients(self) -> pd.DataFrame:
        """
        ### Returns

        The full set of government emission intensity parameters.
        """
        return self._government_emission_intensity_parameters
