import importlib
import logging
import sys
import numpy as np
import pandas as pd
import gcubed
from gcubed.model_configuration import ModelConfiguration
from gcubed.model_parameters.parameters import Parameters
from gcubed.sym_data import SymData
from gcubed.data.linearisation_database import LinearisationDatabase
from gcubed.data.equation_map import EquationMap


class ModelEquations:

    def __init__(self):
        """
        Dependency injection - no argument instantiation.
        """
        pass

    @property
    def is_fully_configured(self) -> bool:
        """
        ### Returns

        `True` if the required properties have been configured and `False` otherwise.

        The required properties are:

        - `sym_data` The summary of the SYM model.

        """
        return hasattr(self, "_sym_data")

    @property
    def sym_data(self) -> SymData:
        """
        ### Returns

        The SymData object
        """
        assert hasattr(
            self, "_sym_data"
        ), "Sym data not set for the model equations. Fully configure the equations before using them."
        return self._sym_data

    @sym_data.setter
    def sym_data(self, value: SymData):
        """
        ### Arguments

        - `value`: The sym data object
        """
        assert value is not None, "The value cannot be None."
        assert isinstance(value, SymData), "The value must be a SymData object."
        self._sym_data = value

        if self.is_fully_configured:
            self.__setup()

    @property
    def model_configuration(self) -> ModelConfiguration:
        """
        ### Returns

        The model configuration object
        """
        return self.sym_data.configuration

    def __setup(self):
        """
        Set up the model equations
        """

        # Set up the arrays for model variables and parameters.
        self.__setup_model_vectors()

        # Import the model equations class that used to execute the model equations.
        self.__setup_model_equations()

        # Load the map between RHS and LHS variables in the model.
        equation_map = EquationMap()
        equation_map.sym_data = self.sym_data
        self._equation_map = equation_map

    @property
    def equation_map(self) -> EquationMap:
        """
        ### Returns

        The equation map object
        """
        assert hasattr(
            self, "_equation_map"
        ), "Equation map not yet set for the model equations. Has the configuration of the model equations been completed?"
        return self._equation_map

    def __setup_model_vectors(self):
        """
        ### Overview

        Initialises numpy column vectors for the LHS variable types,
        for the RHS variable types and for
        the model parameters.

        These are the storage locations that must be used when evaluating model equations.
        The functions that implement the model equations look for RHS values in these
        vectors and write the results to the LHS vectors.

        The vector values are initialised to NaNs.
        """

        # LHS vectors
        for vector_name in self.sym_data.lhs_vector_names:
            setattr(
                self,
                f"_{vector_name}",
                np.full(
                    shape=(self.sym_data.vector_length(vector_name=vector_name), 1),
                    fill_value=np.nan,
                ),
            )

        # RHS vectors
        for vector_name in self.sym_data.rhs_vector_names:
            setattr(
                self,
                f"_{vector_name}",
                np.full(
                    shape=(self.sym_data.vector_length(vector_name=vector_name), 1),
                    fill_value=np.nan,
                ),
            )

        # Parameters
        self._par = np.full(
            shape=(self.sym_data.parameter_count, 1),
            fill_value=np.nan,
        )

    @property
    def x1l(self) -> np.ndarray:
        """
        ### Returns

        The LHS vector for the state variables in the left-hand side of the model equations.
        """
        assert hasattr(self, "_x1l"), "LHS state vector not set."
        return self._x1l

    @property
    def j1l(self) -> np.ndarray:
        """
        ### Returns

        The LHS vector for the costate variables in the left-hand side of the model equations.
        """
        assert hasattr(self, "_j1l"), "LHS costate vector not set."
        return self._j1l

    @property
    def zel(self) -> np.ndarray:
        """
        ### Returns

        The LHS vector for the expected endogenous variables in the left-hand side of the model equations.
        """
        assert hasattr(self, "_zel"), "LHS expected endogenous vector not set."
        return self._zel

    @property
    def z1l(self) -> np.ndarray:
        """
        ### Returns

        The LHS vector for the endogenous variables in the left-hand side of the model equations.
        """
        assert hasattr(self, "_z1l"), "LHS endogenous vector not set."
        return self._z1l

    @property
    def x1r(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the state variables in the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_x1r"), "RHS state vector not set."
        return self._x1r

    @property
    def j1r(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the costate variables in the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_j1r"), "RHS costate vector not set."
        return self._j1r

    @property
    def zer(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the expectedendogenous variables in the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_zer"), "RHS expected endogenous vector not set."
        return self._zer

    @property
    def z1r(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the endogenous variables on the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_z1r"), "RHS endogenous vector not set."
        return self._z1r

    @property
    def yjr(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the lagged costate variables on the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_yjr"), "RHS exogenous vector not set."
        return self._yjr

    @property
    def yxr(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the lagged state variables in the RHS-hand side of the model equations.

        """
        assert hasattr(self, "_yxr"), "RHS exogenous vector not set."
        return self._yxr

    @property
    def exo(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the exogenous variables in the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_exo"), "RHS exogenous vector not set."
        return self._exo

    @property
    def exz(self) -> np.ndarray:
        """
        ### Returns

        The RHS vector for the lagged expected exogenous variables on the RHS-hand side of the model equations.
        """
        assert hasattr(self, "_exz"), "RHS exogenous vector not set."
        return self._exz

    @property
    def par(self) -> np.ndarray:
        """
        ### Returns

        The vector for the model parameters.
        """
        assert hasattr(self, "_par"), "Model parameters vector not set."
        return self._par

    def __setup_model_equations(self):
        """

        ### Objective

        Instantiate the model equations so that we can evaluate them.

        """

        logging.debug("About to set up the model equation python functions")
        # Import the model equations.
        sys.path.append(self.model_configuration.sym_directory)
        equations_module = importlib.import_module(
            self.model_configuration.sym_output_filename_prefix
        )
        equations_class = getattr(equations_module, "Equations")

        # Modify equations for variables that are to be set to zero always.
        for index, row in self.sym_data.zero_variables_summary.iterrows():
            function_name: str = f"{row['vector']}_{row['sequence']}"
            setattr(equations_class, function_name, lambda self: 0)

        self._equations = equations_class(
            x1l=self.x1l,
            j1l=self.j1l,
            zel=self.zel,
            z1l=self.z1l,
            x1r=self.x1r,
            j1r=self.j1r,
            z1r=self.z1r,
            zer=self.zer,
            yjr=self.yjr,
            yxr=self.yxr,
            exo=self.exo,
            exz=self.exz,
            par=self.par,
        )
        logging.debug("Done setting up the Python equation functions")

    @property
    def equations(self):
        """
        ### Returns

        The model equation functions object
        """
        assert hasattr(
            self, "_equations"
        ), "Model equations not set. Has the configuration of the model equations been completed?"
        return self._equations

    def set_vector_value(self, vector: str, sequence: int, value: float):
        """

        ### Objective

        Set the value of an element to the specified value

        ### Arguments

        - `vector_name`: The name of the vector to update
        - `sequence_number`: The index of the element to update
        - `value`: The value to set the element to
        """
        assert value is not None, "Value cannot be None."
        assert isinstance(value, (int, float)), "Value must be a floating-point number."
        assert hasattr(self, vector), f"{vector} not a valid model vector name."
        vector: np.ndarray = getattr(self, vector)
        assert isinstance(vector, np.ndarray), "Vector must be a numpy array."
        assert (vector.shape[0] > sequence) and (
            sequence >= 0
        ), f"Sequence number {sequence} is not a valid index for vector {vector}."
        vector[sequence] = float(value)

    def get_vector_value(self, vector_name: str, sequence_number: int) -> float:
        """

        ### Objective

        Get the value of an element in the specified vector.

        ### Arguments

        - `vector_name`: The name of the vector to retrieve the value from
        - `sequence_number`: The index of the element to retrieve

        ### Returns

        The value of the element in the specified vector
        """
        assert hasattr(
            self, vector_name
        ), f"{vector_name} not a valid model vector name."
        vector: np.ndarray = getattr(self, vector_name)
        assert isinstance(vector, np.ndarray), "Vector must be a numpy array."
        assert (vector.shape[0] > sequence_number) and (
            sequence_number >= 0
        ), f"Sequence number {sequence_number} is not a valid index for vector {vector_name}."
        return float(vector[sequence_number])

    def populate_parameters_to_evaluate_equations(self, parameters: Parameters):
        """

        ### Objective

        Populate the model parameters for the equations to be evaluated.

        ### Arguments

        - `parameters`: The model parameters object.

        """
        assert len(self.par) == len(parameters.parameter_values_vector), (
            f"Model parameters vector length {len(self.par)} does not match "
            f"the length of the parameter values vector {len(parameters.parameter_values_vector)}."
        )

        self.par[:] = parameters.parameter_values_vector.reshape(-1, 1)

    def populate_vectors_to_evaluate_equation(
        self, lhs_variable_name: str, lhs_year: int, database: LinearisationDatabase
    ):
        """

        ### Objective

        Populate the vectors required to evaluate the equation for the specified variable.

        ### Arguments

        - `lhs_variable_name`: The full name of the variable on the lefthand side of the equation.

        - `lhs_year`: The year determining which the variable values are to be populated. This is the
        year associated with the left-hand side variable.

        - `database`: The linearisation database used to source variable values from.

        """

        # Get the list of RHS variables that are used to compute the LHS variable.
        rhs_variables: pd.DataFrame = self._equation_map.rhs_variables(
            lhs_variable_name=lhs_variable_name
        )

        for index, rhs_variable_details in rhs_variables.iterrows():

            # Get the right year to retrieve the RHS variable value for, given the
            # year for which we are trying to calculate a value for the LHS variable.
            rhs_year: int = lhs_year + self.rhs_year_adjustment(
                rhs_vector=rhs_variable_details["rhs_vector"],
                rhs_prefix=rhs_variable_details["rhs_prefix"],
            )

            # Get the value for the RHS variable from the database.
            rhs_value: float = database.value(
                variable_name=rhs_variable_details["rhs_name"], year=rhs_year
            )

            # logging.debug(f"Setting {rhs_variable_details['rhs_name']} to {rhs_value}")

            # Set the value of the RHS variable in the RHS vector.
            self.set_vector_value(
                vector=rhs_variable_details["rhs_vector"],
                sequence=rhs_variable_details["rhs_sequence"],
                value=rhs_value,
            )

    def rhs_year_adjustment(self, rhs_prefix: str, rhs_vector: str) -> int:
        """

         ### Overview

        Determines the year offset of the RHS variable relative to the year
        for the LHS variable.

        ### Arguments

        - `rhs_vector`: The RHS variable vector.

        - `rhs_prefix`: The RHS variable prefix.

        ### Returns

        The RHS variable year in as a YYYY format integer.

        """

        match rhs_vector:

            case "exo" | "yjr" | "zer" | "z1r":
                return 0

            case "x1r":
                if rhs_prefix in gcubed.CONSTANTS.STATE_LEAD_VARIABLES:
                    return 0
                else:
                    return 1

            case "yxr":
                if rhs_prefix in gcubed.CONSTANTS.STATE_LEAD_VARIABLES:
                    return -1
                else:
                    return 0

            case "j1r" | "exz":
                return 1

        assert False, f"Invalid RHS vector {rhs_vector} for {rhs_prefix}."

    def evaluate_equation(self, lhs_variable_name: str) -> float:
        """

        ### Objective

        Evaluate the equation for the specified variable, returning its value.

        ### Arguments

        - `lhs_variable_name`: The full name of the variable.

        ### Returns

        The value of the variable after evaluating the equation.

        """

        # Get the details of the LHS variable.
        lhs_variable_details: pd.Series = self._equation_map.lhs_variable(
            lhs_variable_name=lhs_variable_name
        )

        # logging.debug(
        #     f"Evaluating equation for {lhs_variable_name} using function {lhs_variable_details['lhs_vector']}_{lhs_variable_details['lhs_sequence']}"
        # )

        # Evaluate the equation for the LHS variable.
        getattr(
            self.equations,
            f"{lhs_variable_details['lhs_vector']}_{lhs_variable_details['lhs_sequence']}",
        )()

        # Retrieve the value of the LHS variable from the vector.
        return self.get_vector_value(
            vector_name=lhs_variable_details["lhs_vector"],
            sequence_number=lhs_variable_details["lhs_sequence"],
        )
