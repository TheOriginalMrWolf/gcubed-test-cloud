"""
The data package includes the Database class and various subclasses
of the database class.

The database provides access to historical data for all variables. 
"""
