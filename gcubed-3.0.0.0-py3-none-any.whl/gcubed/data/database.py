"""
This module contains the `Database` class. It can be rebased to
different years and it provides access to the variables values
for historical years.
"""

import logging
import csv
import os
import pandas as pd
import numpy as np
import gcubed
from gcubed.base import Base
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class Database(Base):
    def __init__(self, sym_data: SymData) -> None:
        """
        ### Overview

        The database class is used directly but it is also
        subclassed to support specific data usage scenarios.

        It encapsulates all of the information about the database
        of values for all variables across a range of years.

        ### Arguments

        `sym_data`: The data about the model, created by the SYM processor. This also
        provides access to the model configuration.

        """
        assert sym_data is not None
        assert isinstance(sym_data, SymData)
        self._sym_data = sym_data
        logging.info(
            f"Loading the model's database and assuming a base year of {self.configuration.base_year}"
        )
        self._base_year = self.configuration.base_year
        self.__load_data()
        self.set_up_yratr()
        self.__validate()

    @property
    def sym_data(self) -> SymData:
        """
        The SYM processor output
        """
        return self._sym_data

    @property
    def configuration(self) -> ModelConfiguration:
        """
        The model configuration
        """
        return self.sym_data.configuration

    @property
    def variables(self) -> pd.DataFrame:
        """
        Metadata about the variables, contained in a dataframe
        with columns for each type of metadata and with the rows indexed by variable.

        The metadata includes the following columns:

        * `order` - the order of the variable in the database
        * `name` - the full name of the variable
        * `description` - the general description of the variable
        * `units` - the units used in the database
        * `region` - the region that the variable describes.
        """
        return self._variables

    @property
    def data(self) -> pd.DataFrame:
        """
        The data itself, contained in a dataframe with columns
        indexed by 4 digit (YYYY) year strings and with the rows indexed by variable
        names.
        """
        return self._data

    @property
    def variables_count(self) -> int:
        """
        The number of variables in the database.
        """
        return len(self.variables.index)

    @property
    def years_count(self) -> int:
        """
        The number of years in the database.
        """
        return len(self.data.columns)

    @property
    def years_column_names(self) -> pd.Index:
        """
        The year column names for the data.
        """
        return self.data.columns

    @property
    def base_year(self) -> int:
        """
        The (YYYY) format base year for the data. All indexes in the database
        are based in the specified year.  Databases (but not database subclasses)
        can be rebased to different years.
        """
        return self._base_year

    @property
    def first_available_year(self) -> int:
        """
        The first year of data in the database.
        """
        return self._first_available_year

    @property
    def last_available_year(self) -> int:
        """
        The last year of data in the database.
        """
        return self._last_available_year

    def __load_data(self):
        """

        ### Overview

        Import the data from the database CSV file, splitting it into
        the variable metadata and the data itself.

        ### Exceptions

        Raises an exception if the file is not a valid G-Cubed database.

        """
        assert os.path.isfile(
            self.configuration.database_file
        ), f"{self.configuration.database_file} does not exist or is not a file."

        # Load the dataframe from the database CSV file.
        data: pd.DataFrame = pd.read_csv(
            self.configuration.database_file, index_col=None, header=0
        )

        year_labels: list[str] = self.get_year_labels(
            [str(column_label) for column_label in data.columns]
        )

        self._first_available_year = int(year_labels[0])
        self._last_available_year = int(year_labels[-1])

        # Extract the data columns from the original dataframe
        self._data: pd.DataFrame = data.loc[:, year_labels].copy().astype(float)
        self._data.columns.name = "years"

        # Drop any columns that are data - leaving the variables information
        data.drop(columns=year_labels, inplace=True)

        # Drop any columns that are all NaN values.
        data.dropna(axis="columns", how="all", inplace=True)

        assert (
            len(data.columns) == 5
        ), f"Expected 5 non-data columns that describe the database variables in {self.configuration.database_file}"
        self._variables: pd.DataFrame = data
        self._variables.columns = ["order", "name", "description", "units", "region"]
        self._variables.columns.name = None
        self._variables.order.astype("int")
        self._variables.name.astype("str")
        self._variables.description.astype("str")
        self._variables.units.astype("str")
        self._variables.region.astype("str")

        # Set up the indices for the data and variables properties of the database.
        self._data.index = data.name
        self._data.index.name = "variable_name"
        self._variables.index = self._data.index

    def __validate(self):
        """
        Raise an exception if the database is invalid.
        """
        assert len(self._variables.columns) == 5
        assert self.data is not None
        assert self.variables is not None
        assert self.years_count > 0
        assert self.variables_count > 0

        assert (
            self.configuration.original_first_projection_year
            <= self.last_available_year
        )
        assert self.configuration.base_year >= self.first_available_year
        assert self.configuration.calibration_year >= self.first_available_year
        assert (
            self.configuration.calibration_of_carbon_coefficients_year
            >= self.first_available_year
        )
        assert self.configuration.linearisation_year >= self.first_available_year

        # Make sure that the data is ordered properly from the first year to the last year.
        i = 0
        for year in range(self.first_available_year, self._last_available_year + 1):
            assert str(year) == self.data.columns[i]
            i += 1

        extra_variables_in_sym = list(
            self.sym_data.variable_summary.loc[:, "units"].index.difference(
                self.variables.loc[:, "units"].index
            )
        )
        extra_variables_in_database = list(
            self.variables.loc[:, "units"].index.difference(
                self.sym_data.variable_summary.loc[:, "units"].index
            )
        )
        if extra_variables_in_sym:
            logging.error(
                f"Variables in the SYM definition but not in the database:\n{extra_variables_in_sym}"
            )
        if extra_variables_in_database:
            logging.error(
                f"Variables in database but not in the SYM definition:\n{extra_variables_in_database}"
            )
        assert (
            not extra_variables_in_sym
        ), "There are variables in the SYM model that are not in the database"
        assert (
            not extra_variables_in_database
        ), "There are variables in the database that are not in the SYM model"

        # Debug code to help with debugging ordering mismatches between sym and the database.
        pd.DataFrame(
            {"SYM": self.sym_data.variable_summary.index, "DATA": self.variables.index}
        ).to_csv(
            os.path.join(
                self.configuration.diagnostics_directory, "SYM vs DATA variables.csv"
            )
        )

        mismatched_indexes = self.sym_data.variable_summary.loc[
            self.sym_data.variable_summary["units"] != self.variables["units"],
            "units",
        ].index

        assert (
            len(mismatched_indexes) == 0
        ), f"The following variables do not have matching units in the SYM and data files:\n{list(mismatched_indexes)}"

        if not (
            self.sym_data.variable_summary.loc[:, "units"]
            == self.variables.loc[:, "units"]
        ).all():
            raise Exception(
                "The variable units in the database do not match those in the SYM model definition."
            )

        self.__validate_base_year()
        logging.info(
            f"Loaded the model's database from {gcubed.file_summary(file_path=self.configuration.database_file)}"
        )

    def __validate_base_year(self):
        """
        Make sure that the price indices are equal to 100 for all regions, in the base year.
        """

        # Only do the validation if the PRID data is not missing
        if (
            self.data.loc[
                self.data.index.str.contains(gcubed.CONSTANTS.PRID_PREFIX),
                str(self.base_year),
            ]
            .isna()
            .all()
        ):
            logging.warning(
                f"The PRID price index is missing in the base year (self.base_year) in the database. This is 'bad' if you are using the database to run model."
            )
            return

        assert (
            self.data.loc[
                self.data.index.str.contains(gcubed.CONSTANTS.PRID_PREFIX),
                str(self.base_year),
            ]
            == 100
        ).all(), f"The PRID price index should have base year {self.base_year} in the database but it does not."

    def export_to_csv(self, filename: str):
        """
        Export the database to a CSV file, making sure that the file extension is '.csv'.
        """
        if filename.endswith(".csv"):
            self.data.to_csv(filename)
            # np.savetxt(filename, self.data, delimiter=",")
        else:
            self.data.to_csv(f"{filename}.csv")
            # np.savetxt(f"{filename}.csv", self.data, delimiter=",")

    def rebase(self, new_base_year: int):
        """
         Rebase a database so indices have a new base year.
         This can be used to convert the database used for calibration
         to a database with the base year equal to the start year
         for projections (eg. 2011 to 2018).

         Note that this script draws on the approach in the G-Cubed utilities/rebasedata.ox script.

        ### Arguments
             new_base_year (int): a YYYY formatted new base year for the database.

        ### Exceptions

        Exception is thrown if the database does not contain data for the new base year.

        Exception is thrown if the database does not contain data for the year after
        the new base year if the model has lagged index variables.

        """

        if self.last_available_year < new_base_year:
            raise Exception(f"The database does not contain data for {new_base_year}.")

        # Rebase variables that are indices but not lagged
        selector: pd.Series = (
            self.sym_data.variable_summary.idx & ~self.sym_data.variable_summary.lagged
        )
        if selector.any():
            self.data.loc[selector, :] = 100 * self.data.loc[selector, :].div(
                self.data.loc[selector, str(new_base_year)], axis=0
            )

        # Rebase variables that are indices and lagged
        selector: pd.Series = (
            self.sym_data.variable_summary.idx & self.sym_data.variable_summary.lagged
        )
        if selector.any() and self.last_available_year == new_base_year:
            raise Exception(
                f"The database does not contain data for {new_base_year+1}."
            )
        if selector.any():
            self.data.loc[selector, :] = 100 * self.data.loc[selector, :].div(
                self.data.loc[selector, str(new_base_year + 1)], axis=0
            )

        # Adjust real GDP for the change in the base year.
        self.__rebase_real_gdp(new_base_year=new_base_year)

        # Store the current base year for this database after the rebasing.
        self._base_year = new_base_year

        # Update the YRATR scaling factor for the new base year.
        self.set_up_yratr()

        # Check that the rebasing operation worked.
        self.__validate_base_year()

    def __rebase_real_gdp(self, new_base_year: int):
        """

        Rebases the LGDPR and YRATR variables to the new base year.

        The steps are:

        1. Get real GDP data (LGDPR)
        2. Get nominal GDP data (LGDPN)
        3. Calculate the ratio of nominal GDP to real GDP in the new base year.
        4. Multiply the real GDP data by the ratio to get rebased real GDP that is
        equal to to the nominal GDP in the base year.

        ### Arguments
             `new_base_year` : the new year to be applied in the output file,
             in YYYY integer format
        """

        # Get LGDPR data
        real_gdp: pd.DataFrame = self.data.loc[
            self.data.index.str.startswith(f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}("), :
        ].copy()

        # Get LGDPN data
        nominal_gdp: pd.DataFrame = self.data.loc[
            self.data.index.str.startswith(f"{gcubed.CONSTANTS.NOMINAL_GDP_PREFIX}("), :
        ].copy()

        # Rebase real GDP so real GDP is equal to nominal GDP in the chosen year.
        scale_factor: pd.DataFrame = pd.DataFrame(
            index=real_gdp.index, columns=[str(new_base_year)]
        ).astype(float)
        scale_factor.loc[:, :] = (
            nominal_gdp.loc[:, [str(new_base_year)]].to_numpy()
            / real_gdp.loc[:, [str(new_base_year)]].to_numpy()
        )

        # Update the data with the rebased real GDP data.

        self.data.loc[
            self.data.index.str.startswith(f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}("), :
        ] = (real_gdp * scale_factor.values)

        # Rebase YRATR
        self.data.loc[
            self.data.index.str.startswith(
                f"{gcubed.CONSTANTS.US_REAL_GDP_RATIO_PREFIX}("
            ),
            :,
        ] = (
            100
            * self.data.loc[
                self.data.index.str.startswith(f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}("),
                :,
            ].to_numpy()
            / self.data.loc[
                self.data.index.str.startswith(
                    f"{gcubed.CONSTANTS.REAL_GDP_PREFIX}({self.sym_data.us_region})"
                ),
                :,
            ].to_numpy()
        )

    def rhs_vector_value(
        self, vector_name: str, year: int, use_neutral_real_interest_rate=False
    ) -> np.ndarray:
        """

         ### Overview

         Retrieves data from the database for all of the variables in a specific RHS vector in the model.
         The data is retrieved for the specified year.

         Note that some state variables have their data retrieved
         for the following year.

         Note also that interest rate values can be overridden by the globally defined neutral real interest rate
         that is set in the model configuration file.

         The implementation steps are:

         1. get the rows for the variables of the given type in varmap.
         2. get the names of the variables in those rows from varmap.
         3. use those names to select the data from the calibration year database.
         4. set the values for those variables in the appropriate places in the vector to that data for that year
         using the indices specified in the varmap data.


        ### Arguments

         `vector_name`: The name of the vector to get the values for. This must be a RHS vector listed in
         the model's RHS vector names by the SymData class.

         `year`: The YYYY format year to get data for when populating the RHS vectors.
         e.g. 2011 implies linearise model equations around the values
         of the model variables in 2011 (or in adjacent years for leads/lags).

         `use_neutral_real_interest_rate`: True if interest rates are to be overridden with the
         model configuration neutral real interest rate and False otherwise.

        ### Returns

         A column vector with the requested values for the RHS vector or
         `None` if the vector has zero length.

        """

        if not vector_name in self.sym_data.rhs_vector_names:
            raise Exception(
                f"{vector_name} is not a RHS vector in the model. It should be one of {self.sym_data.rhs_vector_names}"
            )

        vector_value: np.ndarray = np.zeros(
            shape=(self.sym_data.vector_length(vector_name=vector_name), 1), dtype=float
        )
        match vector_name:
            case "exo":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=year
                )
                vector_value[indices] = data

            case "x1r":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=(year + 1)
                )
                vector_value[indices] = data
                for variable_prefix in gcubed.CONSTANTS.STATE_LEAD_VARIABLES:
                    (
                        sequence,
                        data,
                    ) = self.get_data_and_varmap_indices_for_matching_variables(
                        variable_prefix=variable_prefix,
                        vector_name=vector_name,
                        year=year,
                    )
                    vector_value[sequence] = data

            case "yxr":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=year
                )
                vector_value[indices] = data
                for variable_prefix in gcubed.CONSTANTS.STATE_LEAD_VARIABLES:
                    (
                        sequence,
                        data,
                    ) = self.get_data_and_varmap_indices_for_matching_variables(
                        variable_prefix=variable_prefix,
                        vector_name=vector_name,
                        year=(year - 1),
                    )
                    vector_value[sequence] = data

            case "j1r":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=(year + 1)
                )
                vector_value[indices] = data

            case "yjr":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=year
                )
                vector_value[indices] = data

            case "zer":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=year
                )
                vector_value[indices] = data

            case "exz":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=(year + 1)
                )
                vector_value[indices] = data

            case "z1r":
                (data, indices) = self.get_data_and_varmap_indices(
                    vector_name=vector_name, year=year
                )
                vector_value[indices] = data

            case "_":
                raise Exception(f"Invalid RHS vector name {vector_name}.")

        # Replace interest rates with the neutral interest rate (real or nominal if required)
        if use_neutral_real_interest_rate:
            neutral_real_interest_rate: float = (
                self.configuration.neutral_real_interest_rate
            )
            var_type = self.sym_data.varmap_variable_type(vector_name)

            # If setting gap between real and neutral interest rates to the target inflation rate...
            # inflation_rate_adjustments: np.ndarray = self.get_data(
            #     name_regular_expression=rf"{gcubed.CONSTANTS.INFX_PREFIX}\(", years=[year]
            # ).to_numpy()

            # If setting the gap between real and neutral interest rates to the actual next-period inflation rate...
            inflation_rate_adjustments: np.ndarray = self.get_data(
                name_regular_expression=rf"{gcubed.CONSTANTS.INFP_PREFIX}\(",
                years=[year + 1],
            ).to_numpy()

            lagged_inflation_rate_adjustments: np.ndarray = self.get_data(
                name_regular_expression=rf"{gcubed.CONSTANTS.INFP_PREFIX}\(",
                years=[year],
            ).to_numpy()

            # logging.info(
            #     f"The neutral real interest rate is {neutral_real_interest_rate * 100}"
            # )
            # logging.info(
            #     f"The inflation rate adjustment to the neutral real interest rate used to start projections is \n{inflation_rate_adjustments * 100} "
            # )
            # logging.info(
            #     f"The lagged inflation rate adjustment to the neutral real interest rate used to start projections is \n{lagged_inflation_rate_adjustments * 100} "
            # )

            # Replace all real interest rate values with r0 parameter value.
            for prefix in gcubed.CONSTANTS.ALL_REAL_INTEREST_RATE_PREFIXES:
                vector_rows_in_map = self.sym_data.var_map.var_type == var_type
                variable_rows_in_map = self.sym_data.var_map.name.str.startswith(
                    f"{prefix}("
                )
                rows_in_map = vector_rows_in_map & variable_rows_in_map
                sequences: pd.DataFrame = (
                    self.sym_data.var_map.loc[rows_in_map, ["sequence"]]
                    .to_numpy()
                    .flatten()
                )
                if len(sequences) != 0:
                    vector_value[sequences] = neutral_real_interest_rate

            # Replace all nominal interest rate values with (r0 parameter value + target inflation rate).
            var_type = self.sym_data.varmap_variable_type(vector_name)

            for prefix in gcubed.CONSTANTS.ALL_NOMINAL_INTEREST_RATE_PREFIXES:
                vector_rows_in_map = self.sym_data.var_map.var_type == var_type
                variable_rows_in_map = self.sym_data.var_map.name.str.startswith(
                    f"{prefix}("
                )
                rows_in_map = vector_rows_in_map & variable_rows_in_map
                sequences: pd.DataFrame = (
                    self.sym_data.var_map.loc[rows_in_map, ["sequence"]]
                    .to_numpy()
                    .flatten()
                )
                if len(sequences) != 0:
                    vector_value[sequences] = (
                        neutral_real_interest_rate + inflation_rate_adjustments
                    )

            for prefix in gcubed.CONSTANTS.ALL_LAGGED_NOMINAL_INTEREST_RATE_PREFIXES:
                vector_rows_in_map = self.sym_data.var_map.var_type == var_type
                variable_rows_in_map = self.sym_data.var_map.name.str.startswith(
                    f"{prefix}("
                )
                rows_in_map = vector_rows_in_map & variable_rows_in_map
                sequences: pd.DataFrame = (
                    self.sym_data.var_map.loc[rows_in_map, ["sequence"]]
                    .to_numpy()
                    .flatten()
                )
                if len(sequences) != 0:
                    vector_value[sequences] = (
                        neutral_real_interest_rate + lagged_inflation_rate_adjustments
                    )

        return vector_value

    def get_data_and_varmap_indices(self, vector_name: str, year: int) -> tuple:
        """
        ### Arguments

        `vector_name`: The three character name of the vector that is to be populated
        with data.

        `year`: the 4 digit integer specifying the year in the database that will be used
        to source the data that will be inserted into the named vector.

        This method uses the varmap file created by the SYM processor,
        finding those rows in the varmap that have a value in the var_type column
        that match the given vector_name, e.g. 'x1r'.
        The matching rows contain the variable names and their indices within the
        vector that has been named as an input to the function.

        The variable names are used to determine the rows of the database where the
        data will be sourced.

        The year determines the column in the database where the data will be sourced.

        ### Returns

        A tuple is returned. That tuple contains a numpy vector of the data that has been
        extracted from the database and a vector of indices indicating where, in the specified
        vector, that data should be inserted.

        """
        variable_type: str = self.sym_data.varmap_variable_type(vector_name=vector_name)
        map = self.sym_data.var_map[self.sym_data.var_map.var_type == variable_type]

        names = map.name
        indices = map.sequence
        result: np.ndarray = self.data.loc[names, str(year)].to_numpy()
        return (result.reshape((len(result), 1)), indices)

    def get_data_and_varmap_indices_for_matching_variables(
        self, variable_prefix: str, vector_name: str, year: int
    ):
        """
         Gets matching data for the given variable prefix for a given vector.

        ### Arguments

         `variable_prefix`: The prefix for the variable name

         `vector_name`: the name of the vector to be populated.

         ### Returns

         A tuple containing the indices in the vector to be populated (as a list of integers)
         and the values to use to do the populating as a numpy column vector.
        """
        map: pd.DataFrame = self.sym_data.var_map[
            self.sym_data.var_map["name"].str.contains(variable_prefix)
        ]

        variable_type: str = self.sym_data.varmap_variable_type(vector_name=vector_name)
        map = map[map.var_type.str.match(variable_type)]

        result: np.ndarray = self.data.loc[map.name, str(year)].to_numpy()

        return (map.sequence.to_list(), result.reshape((len(result), 1)))

    def get_data(self, name_regular_expression: str, years: list) -> pd.DataFrame:
        """

        Gets data for the set of variables with variable names that match the given regular
        expression.

        ### Arguments

        `name_regular_expression`: The variable selection criteria. It can be any
        regular expression that works with the Python `regex` package.

        `years`: the list of years for which the data is to be retrieved. Note that
        this can be a list of integer values or a list of strings.

        ### Returns

         A copy of the data for the specified year for
         all variables with names matching the given regular expression
         where the names are matched against the row index (labels) in
         the database.

        """
        selected_rows = self.data.index.str.contains(name_regular_expression)
        if not years:
            return self.data.loc[selected_rows, :].copy()
        if isinstance(years, int):
            return self.data.loc[selected_rows, [str(years)]].copy()
        if isinstance(years, str):
            return self.data.loc[selected_rows, [years]].copy()
        if isinstance(years, list):
            # works with list of integers or strings
            selected_columns = [str(x) for x in years]
            return self.data.loc[selected_rows, selected_columns].copy()
        raise Exception(
            f"There is no data available matching {name_regular_expression} in {years}"
        )

    def get_non_negative_data(
        self, variable_name_prefix: str, years: list
    ) -> pd.DataFrame:
        """

        ### Overview

        **Experimental functionality supporting log models**

        Gets data for the set of variables with variable names that match the given regular
        expression.

        ### Arguments

        `variable_name_prefix`: The variable name prefix.

        `years`: the list of years for which the data is to be retrieved. Note that
        this can be a list of integer values or a list of strings.

        ### Returns

        If the prefix matches one or more variables in the database, then
        a copy of the data for the specified year for
        all matching variables is returned.

        If the prefix fails to match any variables in the database, then
        the prefix is adjusted to start with `ln` followed by the supplied prefix.
        This constitutes an attempt to find a the natural log of the specified variable.
        If this succeeds, then the returned data is calculated by taking the exponential
        value of the matching log variable and then multiplying the result by YRATR for
        the corresponding regions.

        ### Exceptions

        If the prefix and the ln + prefix both fail to match any variables in the database,
        then an exception is raised.

        """
        selected_rows: pd.DataFrame = self.data.loc[
            self.data.index.str.startswith(variable_name_prefix), :
        ].copy()
        if len(selected_rows.index) == 0:
            selected_rows: pd.DataFrame = self.data.loc[
                self.data.index.str.startswith(f"ln{variable_name_prefix}"), :
            ].copy()
            assert (
                len(selected_rows.index) > 0
            ), f"The database has no level or natural log variables matching the name prefix {variable_name_prefix}"
            regions: pd.DataFrame = self.sym_data.variable_summary.loc[
                selected_rows.index, ["region"]
            ]
            # Get YRATR by region
            yratr: pd.DataFrame = self.data.index.str.startswith(
                f"{gcubed.CONSTANTS.US_REAL_GDP_RATIO_PREFIX}("
            ).copy()
            yratr.index = self.sym_data.regions_members
            for index in selected_rows.index:
                region: str = regions.loc[index, "region"].values[0]
                selected_rows.loc[index, :] = (
                    np.exp(selected_rows.loc[index, :].to_numpy())
                    * yratr.loc[region, :].to_numpy()
                )

        if not years:
            return selected_rows
        if isinstance(years, int):
            return selected_rows.loc[:, [str(years)]]
        if isinstance(years, str):
            return selected_rows.loc[:, [years]]
        if isinstance(years, list):
            # works with list of integers or strings
            return selected_rows.loc[:, [str(x) for x in years]]

    def update_data(self, new_data: pd.DataFrame):
        """
         Replace the existing data property with a new dataframe. All of the data is replaced.

         This is useful if you need to do projections and then treat those projections as actual data
         in a subsequent step in your analysis pipeline.

        ### Arguments

         `new_data` (pd.DataFrame)`: The new dataframe to use.
        """
        if not self._data.index.equals(new_data.index):
            raise Exception(
                "The new database does not describe the same set of variables as the old database."
            )
        self._data = new_data
        self._last_available_year = int(self.data.columns[-1])

        # Update the YRATR scaling factor based on the new data.
        self.set_up_yratr()

    def has_data(self, year: int) -> bool:
        """
         Used to check if there is a column of data in the database for the specified year.

         Arguments:

         `year`: The 4 digit integer value of the year (YYYY).

        ### Returns

        `True` if the database has data for the specified year and `False` otherwise
        """
        return str(year) in self.data.columns

    @property
    def has_data_for_all_projection_years(self) -> bool:
        """
        This property is used when determining whether the database has been populated
        with projections, in which case those projections provide values, now stored
        as data, out to the end year of the projections.

        ### Returns

        `True` if the database has data for the last projection year and `False` otherwise.
        """
        return self.has_data(year=self.configuration.last_projection_year)

    def set_up_yratr(self):
        """
        ### Overview

        Sets up the YRATR scaling factor for variables that are not logged and that
        have units that end in a gdp suffix (except for those with units of usgdp).

        These values can then be used to do variable scaling as we convert between
        database values and values used in the model equations.
        """

        # The year that the GDP scale factor is to be sourced from
        year = str(self.configuration.original_first_projection_year)

        # Set up the vector to contain the scale factors.
        # Default to 1 for all variables and then change for those that need scaling.
        # The dataframe is indexed by variable names and has a column for each year in the database.
        self._yratr: pd.DataFrame = pd.DataFrame(
            index=self.data.index,
            columns=self.data.columns,
            data=1.0,
        )

        # Get the YRATR value for each region in the base year, dividing by 100
        # so that the values are the ratio of local GDP to US GDP for each region.
        # The value for the USA should be 1.0
        yratr_values: pd.DataFrame = (
            self.data.loc[
                self.variables.name.str.startswith(
                    f"{gcubed.CONSTANTS.US_REAL_GDP_RATIO_PREFIX}("
                ),
                :,
            ].copy()
            / 100.0
        )

        # Index using region names
        yratr_values.index = self.sym_data.regions_members

        # Determine the variables to scale using the scale factor
        variables_to_scale = self.sym_data.variable_summary.units.str.endswith(
            "gdp"
        ) & (self.sym_data.variable_summary.logged == False)

        # Set the scale factor for each variable that should be scaled, based on its region.
        for region in self.sym_data.regions_members:
            regions_to_scale = self.variables.loc[:, "region"] == region
            rows_to_scale = variables_to_scale & regions_to_scale
            self._yratr.loc[rows_to_scale, :] *= yratr_values.loc[region, :].to_numpy()

    def yratr_scaling_factor(self, year: int) -> pd.DataFrame:
        """
        ### Overview

        Retrieves a column vector of YRATR values for all variables in the database. The values
        are 1 for variables that do not need to be scaled by YRATR for use in the model and are equal
        to the YRATR values in the chosen year for the region associated with the variable, otherwise.

        ### Arguments

        `year`: The year for which the yratr scaling factors for all variables are being retrieved.

        Return the dataframe with a single column, for the base year of the database
        that contains the YRATR values for all variables that need to be scaled by YRATR
        when converting between database values and the values that are used in the model.
        """
        assert hasattr(
            self, "_yratr"
        ), "YRATR scaling factors have not been set up in the database."
        return self._yratr.loc[:, [str(year)]]

    def yratr_scaling_factor_for_variable(
        self, variable_name: str, year: any
    ) -> pd.DataFrame:
        """
        ### Overview

        Get the YRATR scaling factor for the specified variable in the specified year.

        ### Arguments

        `variable_name`: The full name of the variable.

        `year`: The year for which the YRATR scaling factor is being retrieved. It can be a string or an integer.
        It is converted to a string when used.

        ### Returns

        A floating value that is the scaling factor that, when multiplied by the database value, converts
        it from a percentage of local GDP to a percentage of US GDP.

        """
        return self._yratr.at[variable_name, str(year)]

    def value(self, variable_name: str, year: any) -> float:
        """
        ### Overview

        Retrieves the value of a variable in the database for a specific year.

        ### Arguments

        - `variable_name`: The full name of the variable.

        - `year`: The year for which the value is to be retrieved. It can be a string or an integer.
        It is converted to a string when used.

        ### Returns

        The value of the variable for the specified year if the year
        is between the first and the last available years in the database, inclusive.

        """
        if year < self.first_available_year:
            return np.nan
        if year > self.last_available_year:
            return np.nan
        return self.data.at[variable_name, str(year)]

    def set_value(self, variable_name: str, year: any, value: float):
        """

        ### Overview

        Set the value of a variable in the database for a specific year.

        ### Arguments

        - `variable_name`: The full name of the variable.

        - `year`: The year for which the value is to be set. It can be a string or an integer.

        - `value`: The value to set for the variable in the specified year.

        """
        self.data.at[variable_name, str(year)] = value

    # --------------------------------------------------------------------------------------------
    # Save the database as a CSV file in the format used by G-Cubed models.
    # --------------------------------------------------------------------------------------------

    def save(self, filename: str):
        """

        ### Overview

        Save the database to a CSV file.

        ### Arguments

        - `filename`: The filename to save the database to

        ### Exceptions

        - `AssertionError`: If the filename is not an absolute path

        """

        # Assert that the filename is an absolute path
        assert os.path.isabs(
            filename
        ), f"The filename {filename} must be an absolute path."

        # If the folder containing the named file does not exist, create it.
        folder: str = os.path.dirname(filename)
        if not os.path.exists(folder):
            os.makedirs(folder)
            logging.info(
                f"Created folder {folder} for the saved database file {filename}"
            )

        data: pd.DataFrame = self.data.copy()
        data.insert(0, "region", self.variables.region)
        data.insert(0, "units", self.variables.units)
        data.insert(0, "description", self.variables.description)
        data.insert(0, "name", self.variables.name)
        data.insert(0, "order", self.variables.order)

        data.to_csv(
            filename,
            index=False,
            float_format="%.18f",
        )
