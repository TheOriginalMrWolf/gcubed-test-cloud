import logging
import pandas as pd
from gcubed.model_configuration import ModelConfiguration
from gcubed.sym_data import SymData


class EquationMap:

    def __init__(self):
        """
        Dependency injection - no argument instantiation.
        """
        pass

    @property
    def is_fully_configured(self) -> bool:
        """
        ### Returns

        `True` if the required properties have been configured and `False` otherwise.

        The required properties are:

        - `sym_data`

        """
        return hasattr(self, "_sym_data")

    @property
    def sym_data(self) -> SymData:
        """
        ### Returns

        The SymData object
        """
        assert hasattr(
            self, "_sym_data"
        ), "Sym data not set for the model equation map."
        return self._sym_data

    @sym_data.setter
    def sym_data(self, value: SymData):
        """
        ### Arguments

        - `value`: The sym data object
        """
        assert value is not None, "The value cannot be None."
        assert isinstance(value, SymData), "The value must be a SymData object."
        self._sym_data = value

        if self.is_fully_configured:
            self.__setup()

    @property
    def model_configuration(self) -> ModelConfiguration:
        """
        ### Returns

        The model configuration object
        """
        return self.sym_data.configuration

    def __setup(self):
        """
        Set up the equation map.
        """

        # Load the map between RHS and LHS variables in the model.
        self.__load_equation_map()

    def __load_equation_map(self):
        """
        ### Overview

        Uses the Equation map CSV file from the sym processor
        to create a dataframe mapping from each
        LHS variable to the RHS variables in its equation.

        Each LHS variable is represented by:
        - `lhs_name`: The full name of the variable
        - `lhs_prefix`: The prefix of the variable name
        - `lhs_vector`: The vector name of the variable
        - `lhs_sequence`: The sequence number of the variable (its index in the vector)

        Each RHS variable is represented by:
        - `rhs_name`: The full name of the variable
        - `rhs_prefix`: The prefix of the variable name
        - `rhs_vector`: The vector name of the variable
        - `rhs_sequence`: The sequence number of the variable (its index in the vector)

        There is a row for each RHS variable in each equation.

        The map is stored in the `_equations_map` attribute.
        """
        logging.debug("Setting up the equation map.")

        # Load the mapping data.
        data: pd.DataFrame = pd.read_csv(
            self.model_configuration.eqnmap_file, header=None, index_col=None
        )
        data.columns = ["name", "number"]

        # Eliminate parameters
        data: pd.DataFrame = data.loc[data["name"] != "par", :]

        # Sort out LHS variables
        lhs_variables = data["name"].str.endswith("l")
        data.loc[lhs_variables, "vector"] = data.loc[lhs_variables, "name"]
        data.loc[lhs_variables, "sequence"] = data.loc[lhs_variables, "number"]

        # Sort out RHS variables
        data.loc[~lhs_variables, "rhs_vector"] = data.loc[~lhs_variables, "name"]
        data.loc[~lhs_variables, "rhs_sequence"] = data.loc[~lhs_variables, "number"]

        # Get the mapping from LHS vector and sequence to variable name
        variable_names = self.sym_data.variable_summary.loc[
            :, ["vector", "sequence", "name"]
        ]

        # Get the LHS variable names
        data["vector"] = data["vector"].ffill()
        data["sequence"] = data["sequence"].ffill()
        data = data.loc[~lhs_variables, :]
        data.drop(columns=["name", "number"], inplace=True)

        # Get the RHS variable names by determining variable
        # summary vector name that matches each RHS vector.
        data = data.merge(variable_names, on=["vector", "sequence"], how="left")
        data.columns = [
            "lhs_vector",
            "lhs_sequence",
            "rhs_vector",
            "sequence",
            "lhs_name",
        ]
        data["vector"] = data["rhs_vector"]
        for rhs_vector in self.sym_data.rhs_vector_names:
            data.loc[data.vector == rhs_vector, "vector"] = (
                self.sym_data.varmap_variable_type(vector_name=rhs_vector)
            )
        data = data.merge(variable_names, on=["vector", "sequence"], how="left")
        data.drop(columns=["vector"], inplace=True)

        # Rename the columns
        data.columns = [
            "lhs_vector",
            "lhs_sequence",
            "rhs_vector",
            "rhs_sequence",
            "lhs_name",
            "rhs_name",
        ]

        # Add the variable name prefix columns
        data["lhs_prefix"] = data["lhs_name"].str.split("(").str[0]
        data["rhs_prefix"] = data["rhs_name"].str.split("(").str[0]

        # Reorder the dataframe columns
        data: pd.DataFrame = data.loc[
            :,
            [
                "lhs_name",
                "lhs_prefix",
                "lhs_vector",
                "lhs_sequence",
                "rhs_name",
                "rhs_prefix",
                "rhs_vector",
                "rhs_sequence",
            ],
        ]

        # Eliminate any duplicate rows from the dataframe
        data.drop_duplicates(inplace=True)

        # Set the datatype of the sequence columns to be integer.
        data["lhs_sequence"] = data["lhs_sequence"].astype(int)

        data["rhs_sequence"] = data["rhs_sequence"].astype(int)

        self._data = data

        return

    @property
    def data(self) -> pd.DataFrame:
        """
        ### Returns

        The equation map data.

        The dataframe has the columns:

        - `lhs_name`: The name of the LHS variable
        - `lhs_prefix`: The prefix of the LHS variable name
        - `lhs_vector`: The vector name of the LHS variable
        - `lhs_sequence`: The sequence of the LHS variable
        - `rhs_name`: The name of the RHS variable
        - `rhs_prefix`: The prefix of the RHS variable name
        - `rhs_vector`: The vector name of the RHS variable
        - `rhs_sequence`: The sequence of the RHS variable

        There is a row for each RHS variable in each equation.

        All rows are unique.

        """
        return self._data

    def rhs_variables(self, lhs_variable_name: str) -> pd.DataFrame:
        """
        ### Arguments

        - `lhs_variable_name`: The LHS variable

        ### Returns

        A dataframe containing the details of the RHS variables
        in the equation for the given LHS variable.

        The dataframe has the columns:

        - `rhs_name`: The name of the RHS variable
        - `rhs_prefix`: The prefix of the RHS variable name
        - `rhs_vector`: The vector name of the RHS variable
        - `rhs_sequence`: The sequence of the RHS variable

        """
        return self.data.loc[
            self.data.lhs_name == lhs_variable_name,
            ["rhs_name", "rhs_prefix", "rhs_vector", "rhs_sequence"],
        ]

    def lhs_variables(self, rhs_variable_name: str) -> pd.DataFrame:
        """

        ### Arguments

        - `rhs_variable_name`: The RHS variable name

        ### Returns

        A dataframe containing the details of the RHS variables
        in the equation for the given LHS variable.

        The dataframe has the columns:

        - `lhs_name`: The name of the LHS variable
        - `lhs_prefix`: The prefix of the LHS variable name
        - `lhs_vector`: The vector name of the LHS variable
        - `lhs_sequence`: The sequence of the LHS variable

        """
        return self.data.loc[
            self.data.rhs_name == rhs_variable_name,
            ["lhs_name", "lhs_prefix", "lhs_vector", "lhs_sequence"],
        ]

    def lhs_variable(self, lhs_variable_name: str) -> pd.Series:
        """

        ### Overview

        Return the full set of details about the LHS variable with the given name.

        ### Arguments

        - `lhs_variable_name`: The name of the variable

        ### Returns

        The details of the LHS variable including:

        - `lhs_name`: The name of the LHS variable
        - `lhs_prefix`: The prefix of the LHS variable name
        - `lhs_vector`: The vector name of the LHS variable
        - `lhs_sequence`: The sequence of the LHS variable

        """
        return self.data.loc[
            self.data.lhs_name == lhs_variable_name,
            ["lhs_name", "lhs_prefix", "lhs_vector", "lhs_sequence"],
        ].iloc[0, :]

    def is_lhs_variable(self, lhs_variable_name: str) -> bool:
        """
        ### Arguments

        - `lhs_variable_name`: The variable to check

        ### Returns

        `True` if the variable is a LHS variable and `False` otherwise.
        """
        return lhs_variable_name in self.data.lhs_name.values

    def is_rhs_variable(self, rhs_variable_name: str) -> bool:
        """
        ### Arguments

        - `rhs_variable_name`: The variable to check

        ### Returns

        `True` if the variable is a RHS variable and `False` otherwise.
        """
        return rhs_variable_name in self.data.rhs_name.values
