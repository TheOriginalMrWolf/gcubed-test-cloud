"""
Baseline projection adjustments to exogenous 
variable.

Adjustments are build in for population and 
productivity and energy efficiency and they draw
on information provided in the model's data directory.
"""
