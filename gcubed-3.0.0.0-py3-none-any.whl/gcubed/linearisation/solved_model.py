"""
Module that contains the solved model class.
"""
import logging
from gcubed.base import Base
from gcubed.model import Model
from gcubed.linearisation.linear_model import LinearModel
from gcubed.linearisation.state_space_form import StateSpaceForm
from gcubed.linearisation.stable_manifold import StableManifold
from gcubed.model_parameters.parameters import Parameters
from gcubed.sym_data import SymData
from gcubed.data.database import Database
from gcubed.model_configuration import ModelConfiguration


class SolvedModel(Base):
    def __init__(
        self, model: Model, linearise_around_the_neutral_real_interest_rate: bool = True
    ) -> None:
        """
        ###Overview

        Solves the model.

        This object takes some time to construct, as it solves the model. Therefore it can be useful
        to create this object and then to re-use it for multiple projections.

        ###Arguments

        `model` : The model to be solved

        `linearise_around_the_neutral_real_interest_rate` :
        If `True`, the model is linearised around the neutral real interest rate.
        If `False`, the model is linearised around the interest rates in the linearisation year.
        Defaults to `True`.

        """

        super().__init__()

        self._model = None

        assert model is not None, "The model must be provided."

        assert (
            linearise_around_the_neutral_real_interest_rate is not None
        ), "linearise_around_the_neutral_real_interest_rate must be True or False."

        self._linearise_around_the_neutral_real_interest_rate = (
            linearise_around_the_neutral_real_interest_rate
        )

        linear_model: LinearModel = LinearModel(
            model=model,
            use_neutral_real_interest_rate=self.linearise_around_the_neutral_real_interest_rate,
        )
        state_space_form: StateSpaceForm = StateSpaceForm(linear_model=linear_model)
        self._stable_manifold: StableManifold = StableManifold(
            state_space_form=state_space_form
        )

    @property
    def linearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if interest rates are linearised around the neutral real interest
        rate for the start of the baseline projections and `False` otherwise.

        Defaults to `True`.
        """
        return self._linearise_around_the_neutral_real_interest_rate

    @property
    def stable_manifold(self) -> StableManifold:
        """
        The stable manifold.
        """
        return self._stable_manifold

    @property
    def state_space_form(self) -> StateSpaceForm:
        """
        The state space form.
        """
        return self.stable_manifold.ssf

    @property
    def linear_model(self) -> LinearModel:
        """
        The linear model.
        """
        return self.state_space_form.linear_model

    @property
    def model(self) -> Model:
        """
        The model.
        """
        return self.linear_model.model

    @property
    def parameters(self) -> Parameters:
        """
        The parameters.
        """
        return self.model.parameters

    @property
    def sym_data(self) -> SymData:
        """
        The SYM data.
        """
        return self.model.sym_data

    @property
    def database(self) -> Database:
        """
        The database model.
        """
        return self.model.database

    @property
    def model_configuration(self) -> ModelConfiguration:
        """
        The model configuration.
        """
        return self.model.model_configuration
