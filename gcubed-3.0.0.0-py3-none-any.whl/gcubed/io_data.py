"""
This module contains the `IOData` class for input/output table access.
"""

from ast import Mult
import logging
import os
import pandas as pd
import gcubed
from gcubed.base import Base
from gcubed.sym_data import SymData


tax_input: str = "TAX"
"""
The tax row label.
"""

labor_input: str = "L"
"""
The labor row label.
"""

capital_input: str = "K"
"""
The capital row label.
"""

consumption_use: str = "C"
"""
The consumption column label.
"""

investment_use: str = "I"
"""
The investment column label.
"""

government_use: str = "G"
"""
The government spending column label.
"""

exports_use: str = "X"
"""
The exports column label.
"""

imports_use: str = "M"
"""
The imports column label.
"""

non_sector_uses: list[str] = [
    consumption_use,
    investment_use,
    government_use,
    exports_use,
    imports_use,
]
"""
The list of non-sector uses in the IO tables.
"""

non_sector_inputs: list[str] = [
    labor_input,
    capital_input,
    tax_input,
]
"""
The list of non-sector inputs in the IO tables.
"""


class IOData(Base):
    """
    ### Overview

    This class manages loading and provision of IO table information.

    It encapsulates all of the information about the input/output tables
    for each region.
    """

    def __init__(self, sym_data: SymData) -> None:
        """
        ### Arguments

        `sym_data`: The information about the SYM model definition.

        This argument also provides access to the model configuration
        so that the location of the CSV file containing the IO tables
        data is known.

        ### CSV file format

        The <IOTABLES>.csv contains the Input/Output tables for all regions.

        Review [the teaching model Input/Output tables file](/model/data/IOTABLESvR2011.csv)
        to get insight into how the data is organised.

        Each region has an Input/Output table.

        The Input/Output tables are stacked vertically in the Input/Output tables file.

        The first column of the IO table, with the
        `<REGION_CODE>` in the first cell, must be in the first column of the CSV file.

        Each Input/Output table has the following structure, repeated down the file
        for each region:

        | `<REGION_CODE>` | a01 | … | a0N | C | I | G | X | M |
        |-----------------|-----|---|-----|---|---|---|---|---|
        | g01             |     |   |     |   |   |   |   |   |
        | :               |     |   |     |   |   |   |   |   |
        | g0N             |     |   |     |   |   |   |   |   |
        | L               |     |   |     |   |   |   |   |   |
        | K               |     |   |     |   |   |   |   |   |
        | TAX             |     |   |     |   |   |   |   |   |

        The region code <REGION_CODE> in the left corner is mandatory. It must
        be exactly the same as the region code used for the region in the SYM set
        of regions in the model definition. It is used to locate the Input/Output table
        for the region when the table is loaded.

        The first row and the first column of the table are labels for the rows
        and columns respectively.

        Columns of the table describe 'uses' by a particular sector or for one of
        the following:

        - Consumption - `C`
        - Investment - `I`
        - Government spending - `G`
        - Exports - `X`
        - Imports - `M`

        The sector labels must be the sector identifiers in the set of sectors in the
        SYM model definition. Typically these are `a01` for sector 1 etc.

        Rows of the table describe 'inputs' by type of sectoral good (service) produced or:

        - Labour - `L`
        - Capital - `K`
        - Tax - `TAX`

        The goods labels must be the good identifiers in the set of goods in the
        SYM model definition. Typically these are `g01` for sector 1 etc.

        """
        assert sym_data is not None
        assert isinstance(sym_data, SymData)
        self._sym_data = sym_data
        self.__load_io_tables()
        self.__validate()

    @property
    def sym_data(self) -> SymData:
        """
        The SYM details of the model.
        """
        return self._sym_data

    def __load_io_tables(self):
        """

        ### Overview

        **This function is intended for gcubed module internal use. It is exposed only for documentation purposes.**

        This function loads the IO tables into a dictionary of dataframes.

        The dictionary keys are the region identifiers.

        Each dataframe contains the IO table for the associated region.

        The dataframes have row and column names that correspond to the
        sectors.

        """
        filename: str = self.sym_data.configuration.io_table_file
        if not os.path.isfile(filename):
            raise Exception(
                "Could not load IO tables from "
                + filename
                + " because the file does not exist."
            )

        # Load the raw IO tables data into a single dataframe ready to parse into
        # separate tables for the various regions.
        data: pd.DataFrame = pd.read_csv(filename, header=None)

        # Label the columns of the raw IO table dataframe
        columns = self.io_table_uses
        columns.insert(0, "row_labels")
        data.columns = columns

        # Get the table names - one for each region
        regions: list[str] = self.sym_data.regions_members
        table_rows = len(self.io_table_inputs)
        table_columns = len(self.io_table_uses)

        # Load the table for each region into the dictionary of IO tables.
        self._io_tables = dict()
        for region in regions:
            # Make sure the data source has an IO table for the region
            if not region in data.row_labels.values:
                raise Exception(
                    f"Region {region} does not have IO table data in {filename}"
                )

            # Get the data for the table
            io_table_heading_row: int = int(
                data.index[data.row_labels == region].to_list()[0]
            )
            io_table: pd.DataFrame = data.iloc[
                (io_table_heading_row + 1) : (io_table_heading_row + 1 + table_rows),
                1 : (table_columns + 1),
            ].copy()
            io_table = io_table.astype(float)

            io_table.index = self.io_table_inputs
            io_table.columns = self.io_table_uses

            # Store the table in the dictionary of IO tables, one for each region
            self._io_tables[region] = io_table.astype(float)

    def io_table(self, region: str) -> pd.DataFrame:
        """

        ### Overview

        Use this function to retrieve the IO table content for a single region.
        That IO table can then be analysed using the input (row) index and the output
        (column) label for the rows and columns of the dataframe that is the
        IO table.

        ### Arguments

        `region`: the identifier for the region of interest.

        ### Returns

        The dataframe containing the input/output table for the specified region.

        """
        if region in self._io_tables:
            return self._io_tables[region]
        raise Exception("There is no IO table defined for " + region)

    def has_io_table(self, region: str) -> bool:
        """

        ### Overview

        Checks if there is an IO table for the given region.

        ### Arguments

        `region`: The region of interest.

        ### Returns

         `True` if there is an IO table for the specified region and `False` otherwise.

        """
        return region in self._io_tables

    @property
    def io_table_inputs(self):
        """
        The row names (one per input) in the IO tables. All regions have the same rows in
        their IO tables.
        """
        input_names = self.sym_data.goods_members.copy()
        input_names.extend(non_sector_inputs)
        return input_names

    @property
    def io_table_tax(self) -> str:
        """
        Returns the tax row label.
        """
        return "TAX"

    @property
    def io_table_labour(self) -> str:
        """
        The labour row label.
        """
        return "L"

    @property
    def io_table_capital(self) -> str:
        """
        The capital row label.
        """
        return "K"

    @property
    def io_table_consumption(self) -> str:
        """
        The consumption column label.
        """
        return "C"

    @property
    def io_table_investment(self) -> str:
        """
        The investment column label.
        """
        return "I"

    @property
    def io_table_government(self) -> str:
        """
        The government spending column label.
        """
        return "G"

    @property
    def io_table_exports(self) -> str:
        """
        The exports column label.
        """
        return "X"

    @property
    def io_table_imports(self) -> str:
        """
        The imports column label.
        """
        return "M"

    @property
    def io_table_uses(self):
        """
        The column names, one column for each output in the IO tables. The IO table
        has the same columns for each region.
        """
        use_names = self.sym_data.sectors_members.copy()
        use_names.extend(non_sector_uses)
        return use_names

    def __validate(self):
        """
        Raise an exception if the IO data is invalid.


        """

        for region in self.sym_data.regions_members:
            io_table: pd.DataFrame = self.io_table(region=region)
            assert (
                io_table[investment_use] >= 0
            ).all(), f"There must not be negative values in the investment column of the IO table for {region}."
        logging.info(
            f"Loaded input/output tables for each region from {gcubed.file_summary(file_path=self.sym_data.configuration.io_table_file)}"
        )

    @property
    def dataframe(self) -> pd.DataFrame:
        """
        ### Returns

        The IO tables as a a single dataframe.

        The dataframe has a single column index that is the IO table uses.

        The dataframe has a row multi-index with:
        - level 0 being the region
        - level 1 being the IO table inputs
        """
        result: pd.DataFrame = None
        for region in self.sym_data.regions_members:
            region_io_table = self.io_table(region=region).copy()
            region_io_table.columns.name = "use"
            region_io_table.index = pd.MultiIndex.from_product(
                [[region], region_io_table.index], names=["region", "input"]
            )
            if result is None:
                result = region_io_table
            else:
                result = pd.concat([result, region_io_table], axis=0)

        return result
