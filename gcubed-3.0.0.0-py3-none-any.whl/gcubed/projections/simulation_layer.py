"""
This module contains the `SimulationLayer` class, for doing 
projections for a single simulation layer.
"""
import logging
import os
import pandas as pd
import numpy as np
from gcubed.constants import Constants
from gcubed.data.database import Database
from gcubed.projections.projections import Projections
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.projections.simulation_layer_definition import SimulationLayerDefinition


class SimulationLayer(Projections):
    """
    TODO: Complete the simulations implementation
    Compute model simulations over the projection horizon.
    """

    def __init__(
        self,
        simulation_layer_definition: SimulationLayerDefinition,
        previous_projections: Projections,
    ) -> None:
        """

        ### Constructor

        Use this constructor for any simulation that is the first simulation layer applied to baseline projections.

        ### Arguments

        simulation_layer_definition: The definition of this simulation layer

        previous_projections: The projections that this simulation layer builds upon, baseline or another type.

        """
        assert (
            previous_projections is not None
        ), "The previous projections must be specified."

        super().__init__(
            stable_manifold=previous_projections.stable_manifold,
            previous_projections=previous_projections,
        )

        assert (
            simulation_layer_definition is not None
        ), "The simulation layer definition must be specified."
        self._simulation_layer_definition = simulation_layer_definition

        logging.info(
            f"Generating the {self.definition.name} simulation layer projections."
        )

        if self.definition.event_year < self.previous_projections.first_projection_year:
            raise Exception(
                f"The simulation layer event year year, {self.definition.event_year}, must be greater than or equal to the first projection year of the previous projections, {self.previous_projections.first_projection_year}"
            )
        self._first_projection_year = self.definition.event_year

        # Define the name of these projections
        self._name = (
            f"{self.definition.name } projections from {self.first_projection_year}"
        )

        assert os.path.isfile(self.definition.data_filename)
        self.__load_simulation_data()

        self._generate_projections()

        # Store long rate adjustment constants to use in creating the database projections
        self._long_rate_constants = self.first_projections._long_rate_constants
        self._generate_database_projections()

        self._generate_publishable_projections()

        self.__validate()

    def __validate(self):
        """
        Validate the simulation layer.
        """
        logging.info(
            f"The {self.definition.name} simulation layer projections have been generated."
        )

    @property
    def first_projections(self) -> BaselineProjections:
        """
        The first projections created (these have no previous projections).
        """
        return self._first_projections

    @property
    def definition(self) -> SimulationLayerDefinition:
        """
        The definition for this simulation layer, giving access to the information
        about the simulation being done in this layer.
        """
        return self._simulation_layer_definition

    @property
    def database(self) -> Database:
        """
        Returns the database associated with the baseline projections.
        """
        return self.first_projections.database

    def __load_simulation_data(self):
        """

        ### Overview

        Loads and apply the simulation data that affect exogenous variables.

        Loads and apply the simulation data that affect state variables initial values.

        When a variable has data in the simulation file, load that into the appropriate
        SYM-specified row of the exogenous variable projections, from the start projection year onwards.

        When a variable has data in the simulation file (control.csv by default), load that into the appropriate
        SYM-specified row of the state variable projection start year vector and ignore
        data in the control file for all years after that projection start year.

        Adjust the simulation data as follows, depending on the units of the variable:
            gdp - multiply by (projection base year YRATR / 100).
            mmgdp - same as gdp
            btugdp - same as gdp
            gwhgdp - same as gdp
            usgdp - divide the value in the control file by 100.
            All other units - divide the value in the control file by 100.

        ### Exceptions

        Raises an exception if the simulation data does not start in the event year.

        Raises an exception if the simulation data does not have data through to the last projection year.

        """

        # Load the simulation data.
        filename: str = self.definition.data_filename
        assert os.path.isfile(filename)
        (simulation_variables, simulation_data) = self.load_data(
            filename=filename, name_column=0
        )
        if len(simulation_variables.index) == 0:
            logging.warn(
                f"The '{self.definition.name}' simulation layer has no data. This will run but is not doing anything useful."
            )
        simulation_data = simulation_data.astype(float)
        simulation_data.index = simulation_variables.iloc[:, 0]

        assert (
            int(simulation_data.columns[0])
            == self._simulation_layer_definition.event_year
        ), f"The first column of the data {int(simulation_data.columns[0])} in {filename} should be the simulation layer event year, {self._simulation_layer_definition.event_year}."

        # Multiply by the YRATR column to rescale all gdp unit variables to US GDP rather than local GDP.
        # Divide the simulation layer values by 100 to scale to match data used in the model.
        try:
            simulation_data = (
                simulation_data.loc[:, self.projection_years_column_labels]
                * self.database.yratr_scaling_factor(
                    year=self.original_first_projection_year
                )
                .loc[simulation_data.index, :]
                .to_numpy()
                / 100
            )
        except:
            raise Exception(
                f"The simulation data in {os.path.basename(self.definition.data_file)} should include data values from {self.first_projection_year} to {self.last_projection_year}"
            )

        exo_data: pd.DataFrame = simulation_data.loc[
            self.sym_data.variable_summary.loc[simulation_data.index, "vector"]
            == "exo",
            :,
        ]

        x1l_data: pd.DataFrame = simulation_data.loc[
            self.sym_data.variable_summary.loc[simulation_data.index, "vector"]
            == "x1l",
            [str(self.first_projection_year)],
        ]

        self._exo_projections = self.previous_projections.exo_projections.copy()
        if len(exo_data.index) > 0:
            self._exo_projections.loc[
                simulation_data.index, self.projection_years_column_labels
            ] += exo_data

        assert (
            not self._exo_projections.isna().any().any()
        ), "The exogenous variable projections contain NaNs."

        self._yxr_initial_values: pd.DataFrame = (
            self.previous_projections.yxr_projections_as_dataframe.loc[
                :, [str(self.first_projection_year)]
            ].copy()
        )
        if len(x1l_data.index) > 0:
            self._yxr_initial_values += x1l_data

        assert (
            not self._yxr_initial_values.isna().any().any()
        ), "The state variable initial values contain NaNs."

    @property
    def h3t(self) -> np.ndarray:
        """
        A matrix with one column per projection year, with each column being
        the function of current and future exogenous variables affecting J1.

        Note that this matrix is equivalent to h3t in the Ox implementation.
        """
        return self._h3t

    @property
    def c4t(self) -> np.ndarray:
        """
        A matrix with one column per projection year, with each column being
        functions of current and future exogenous variables affecting ZE.

        Note that this matrix is equivalent to c4t in the Ox implementation.
        """
        return self._c4t

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.previous_projections.x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.previous_projections.j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values
        in the original base projection year.
        """
        return self.previous_projections.ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values
        in the original base projection year.
        """
        return self.previous_projections.z1_constants
