"""
This module contains the `BaselineProjections` class, 
used for doing baseline projections.
"""

import logging
import os
from typing import Optional  # DO NOT DELETE THIS IMPORT it manages circular references.
import pandas as pd
import numpy as np
import gcubed
from gcubed.linearisation.solved_model import SolvedModel
from gcubed.data.linearisation_database import LinearisationDatabase
from gcubed.projections.projections import Projections
from gcubed.projections.simulation_layer_definitions import SimulationLayerDefinitions


class BaselineProjections(Projections):
    """
    ### Overview

    Compute the baseline model projections over the projection horizon
    from the first projection year (a year with available data to be
    matched by the projections) through to the last projection year.

    """

    def __init__(
        self,
        solved_model: SolvedModel,
        previous_projections: Optional["Projections"] = None,
        start_from_neutral_real_interest_rate: bool = True,
    ) -> None:
        """
        ### Arguments

        `solved_model`: The solved model that provides access to all
        of the information required to produce projections.

        `previous_projections`: The projections that this baseline builds upon. The first baseline
        has previous projections equal to `None`. Defaults to `None`.

        `start_from_neutral_real_interest_rate`: `True` if the baseline projections start from
        the neutral real interest rate and `False` if they start from the observed real interest rates.
        Defaults to `True`.

        """

        assert solved_model is not None, "The solved model must be provided."
        assert isinstance(
            solved_model, SolvedModel
        ), f"The solved model must be an instance of SolvedModel. It is a {type(solved_model)}."
        self._solved_model = solved_model

        logging.info(
            f"Creating baseline projections from {self.solved_model.model.configuration.first_projection_year} using database with base year {solved_model.database.base_year}"
        )

        super().__init__(
            stable_manifold=solved_model.stable_manifold,
            previous_projections=previous_projections,
        )

        # Override the default value of `False`.
        assert (
            start_from_neutral_real_interest_rate is not None
        ), "start_from_neutral_real_interest_rate must be a boolean value."
        self._start_from_neutral_real_interest_rate = (
            start_from_neutral_real_interest_rate
        )
        logging.info(
            f"Starting baseline projections from the neutral real interest rate? {self.start_from_neutral_real_interest_rate}"
        )

        # Define the name of these projections
        self._name = f"baseline projections from {self.first_projection_year}"

        # Set this baseline projections to be its own baseline projections.
        self._baseline_projections = self

        self._database = LinearisationDatabase(
            database=self.solved_model.database,
            base_year=self.configuration.original_first_projection_year,
        )

        self.database.data.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "linearisation database for projections.csv",
            )
        )

        self.__set_first_projection_year_observed_values()

        self.__store_observed_yxr_values_in_first_projection_year()

        # Set up the exogenous variable projections
        self.__create_exogenous_variable_projections()

        self.__store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year()
        self.__compute_first_projection_year_ssf_deviations_from_observed_values()

        # Set up the intertemporal constant variables
        self.__calculate_intertemporal_constants()

        # Generate the baseline projections
        self._generate_projections()

        # Generate the database projections
        self._generate_database_projections()

        # Generate publishable version of the projections
        self._generate_publishable_projections()

        self.__validate()

    def __validate(self):
        """
        Validations.
        """

        logging.info("The baseline projections have been generated.")

    @property
    def solved_model(self) -> SolvedModel:
        """
        The solved model that provides access to all
        of the information required to produce projections.
        """
        return self._solved_model

    @property
    def database(self) -> LinearisationDatabase:
        """
        The database used as the starting point for the projections.
        """
        return self._database

    def __update_perturbed_variable(self, variable_details: pd.Series):
        """
        ### Overview

        For each variable that has an intertemporal constant, we need to compute
        numerical approximations to the partial derivatives of the model with respect
        to that constant. Those  partial derivatives are approximated by evaluating the
        relevant equations in the model using the data in the first projection year and then
        again evaluating those equations after perturbing the variable of interest by
        `Constants.DELTA`. The difference between the two evaluations is used
        to compute the partial derivatives for that constant.

        This function does the work of perturbing the intertemporal constant
        associated with the variable, preparing for calculation of the partial
        derivatives for that constant.

        The adjustment to the constant (the perturbation) is made by adjusting the
        constants associated with variables' observed differences from their state
        space form equation evaluations in the baseline's first projection year.

        The original value of that constant is tracked using the private property,
        `_original_value`, so that it can be restored after the partial derivatives
        have been computed.

        This function is called once for each variable in the SYM table of intertemporal
        constant variables, as part of computing the intertemporal constants.

        """

        if hasattr(self, "_perturbed_variable_details"):
            sequence = self._perturbed_variable_details["sequence"]
            match self._perturbed_variable_details["vector"]:
                case "x1l":
                    self.x1r_difference_from_ssf[sequence] = self._original_value
                case "j1l":
                    self.j1r_difference_from_ssf[sequence] = self._original_value
                case "zel":
                    self.zer_difference_from_ssf[sequence] = self._original_value
                case "z1l":
                    self.z1r_difference_from_ssf[sequence] = self._original_value
            delattr(self, "_original_value")

        if variable_details is None:
            delattr(self, "_perturbed_variable_details")
        else:
            sequence = variable_details["sequence"]
            match variable_details["vector"]:
                case "x1l":
                    self._original_value = float(self.x1r_difference_from_ssf[sequence])
                    self.x1r_difference_from_ssf[sequence] = (
                        self._original_value + gcubed.CONSTANTS.DELTA
                    )
                case "j1l":
                    self._original_value = float(self.j1r_difference_from_ssf[sequence])
                    self.j1r_difference_from_ssf[sequence] = (
                        self._original_value + gcubed.CONSTANTS.DELTA
                    )
                case "zel":
                    self._original_value = float(self.zer_difference_from_ssf[sequence])
                    self.zer_difference_from_ssf[sequence] = (
                        self._original_value + gcubed.CONSTANTS.DELTA
                    )
                case "z1l":
                    self._original_value = float(self.z1r_difference_from_ssf[sequence])
                    self.z1r_difference_from_ssf[sequence] = (
                        self._original_value + gcubed.CONSTANTS.DELTA
                    )
            self._perturbed_variable_details = variable_details

    @property
    def perturbed_variable_details(self) -> pd.Series:
        """
        If computing intertemporal constants,
        the var_map details (the row of the SYM var_map dataframe)
        for the variable being perturbed as part of computing
        derivatives needed to set intertemporal constants. Otherwise, this returns
        `None` if just producing the baseline projections.
        """
        if hasattr(self, "_perturbed_variable_details"):
            return self._perturbed_variable_details
        return None

    @property
    def first_year_projections_of_variables_adjusted_by_intertemporal_constants(
        self,
    ) -> np.ndarray:
        """
        An column vector of first year projection values for those variables that are adjusted
        by intertemporal constants.

        The vector is populated from the vectors of first year projections for
        each of `x1l`, `j1l`, `zel`,  and `z1l`.
        """
        result = np.zeros(
            shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1)
        )
        i = 0
        for (
            index,
            adjusted_variable_details,
        ) in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details["sequence"]
            match adjusted_variable_details["vector"]:
                case "x1l":
                    result[i, 0] = self.yxr_first_year_projections[[sequence]]
                case "j1l":
                    result[i, 0] = self.yjr_first_year_projections[[sequence]]
                case "zel":
                    result[i, 0] = self.exz_first_year_projections[[sequence]]
                case "z1l":
                    result[i, 0] = self.z1l_first_year_projections[[sequence]]
            i += 1
        return result

    def __set_first_projection_year_observed_values(self):
        """
        ### Overview

        Populates the model vectors using the database values associated with
        the first projection year.

        Note that some variables are populated iwth
        data from adjacent years. Review the `Database.rhs_vector_value` method
        for details.

        Note also that there is the option to override real and
        nominal interest rates with values associated with inflation neutrality.
        """
        # RHS (identical to LHS) vector values to be compared to SSF calculated values
        self._first_projection_year_x1r: np.ndarray = self.database.rhs_vector_value(
            vector_name="x1r",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t+1
        self._first_projection_year_j1r: np.ndarray = self.database.rhs_vector_value(
            vector_name="j1r",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t+1
        self._first_projection_year_zer: np.ndarray = self.database.rhs_vector_value(
            vector_name="zer",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t
        self._first_projection_year_z1r: np.ndarray = self.database.rhs_vector_value(
            vector_name="z1r",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t

        # SSF RHS vector values
        self._first_projection_year_yxr: np.ndarray = self.database.rhs_vector_value(
            vector_name="yxr",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t
        self._first_projection_year_yjr: np.ndarray = self.database.rhs_vector_value(
            vector_name="yjr",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t
        self._first_projection_year_exz: np.ndarray = self.database.rhs_vector_value(
            vector_name="exz",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t+1
        self._first_projection_year_exo: np.ndarray = self.database.rhs_vector_value(
            vector_name="exo",
            year=self.first_projection_year,
            use_neutral_real_interest_rate=self.start_from_neutral_real_interest_rate,
        )  # t

    def __store_observed_yxr_values_in_first_projection_year(self):
        """
        ### Overview

        Save the values of the state vector (X1) in the first projection year to use in
        initiating the projection process.
        """
        yxr_initial_values = pd.DataFrame(self.first_projection_year_yxr.copy())
        yxr_initial_values.index = self.sym_data.vector_variable_names(
            vector_name="yxr"
        )
        yxr_initial_values.columns = [str(self.first_projection_year)]
        self._yxr_initial_values: pd.DataFrame = yxr_initial_values

    def __store_observed_values_of_variables_adjusted_by_intertemporal_constants_in_first_projection_year(
        self,
    ):
        """
        ### Overview

        Save the database values of the variables
        that are adjusted by intertemporal constants so that we can use
        those as the values we adjust the variables to using the intertemporal
        constants.
        """
        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants: (
            np.ndarray
        ) = np.zeros(
            shape=(len(self.sym_data.variables_adjusted_by_intertemporal_constants), 1)
        )
        i = 0
        for (
            index,
            adjusted_variable_details,
        ) in self.sym_data.variables_adjusted_by_intertemporal_constants.iterrows():
            sequence = adjusted_variable_details["sequence"]
            match adjusted_variable_details["vector"]:
                case "x1l":
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[
                        i, 0
                    ] = self.first_projection_year_yxr[
                        [sequence]
                    ]  # t = base year
                case "j1l":
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[
                        i, 0
                    ] = self.first_projection_year_yjr[
                        [sequence]
                    ]  # t = base year
                case "zel":
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[
                        i, 0
                    ] = self.first_projection_year_exz[
                        [sequence]
                    ]  # t+1 = year after base year
                case "z1l":
                    self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants[
                        i, 0
                    ] = self.first_projection_year_z1r[
                        [sequence]
                    ]  # t = base year
            i += 1

    def __compute_first_projection_year_ssf_deviations_from_observed_values(self):
        """
        ### Overview

        Step 1.
        Compute the state-space-form values for the LHS vectors  in  thefirst projection year
        using the values from the database for the RHS vectors in the state space form.

        and

        Step 2.
        Calculate the differences between the database values for the RHS vectors
        `x1r`, `j1r`, `zer`, and `z1r` and the values computed in Step 1. Store these
        as properties of the class instance. They become constant adjustments that are
        used in the projection process to ensure that the database values in
        the first projection year match the baseline projections of those values.

        The differences are preserved as the database values minus projections.
        """

        # Step 1.
        self.x1l_ssf_calculations_using_first_projection_year_data = (
            self.state_space_form.delta("x1l", "yxr") @ self.first_projection_year_yxr
            + self.state_space_form.delta("x1l", "yjr") @ self.first_projection_year_yjr
            + self.state_space_form.delta("x1l", "exz") @ self.first_projection_year_exz
            + self.state_space_form.delta("x1l", "exo") @ self.first_projection_year_exo
        )

        self.j1l_ssf_calculations_using_first_projection_year_data = (
            self.state_space_form.delta("j1l", "yxr") @ self.first_projection_year_yxr
            + self.state_space_form.delta("j1l", "yjr") @ self.first_projection_year_yjr
            + self.state_space_form.delta("j1l", "exz") @ self.first_projection_year_exz
            + self.state_space_form.delta("j1l", "exo") @ self.first_projection_year_exo
        )

        self.zel_ssf_calculations_using_first_projection_year_data = (
            self.state_space_form.delta("zel", "yxr") @ self.first_projection_year_yxr
            + self.state_space_form.delta("zel", "yjr") @ self.first_projection_year_yjr
            + self.state_space_form.delta("zel", "exz") @ self.first_projection_year_exz
            + self.state_space_form.delta("zel", "exo") @ self.first_projection_year_exo
        )

        self.z1l_ssf_calculations_using_first_projection_year_data = (
            self.state_space_form.delta("z1l", "yxr") @ self.first_projection_year_yxr
            + self.state_space_form.delta("z1l", "yjr") @ self.first_projection_year_yjr
            + self.state_space_form.delta("z1l", "exz") @ self.first_projection_year_exz
            + self.state_space_form.delta("z1l", "exo") @ self.first_projection_year_exo
        )

        # Step 2.
        self._x1r_difference_from_ssf = (
            self.first_projection_year_x1r
            - self.x1l_ssf_calculations_using_first_projection_year_data
        )  # t+1 = year after base year
        self._j1r_difference_from_ssf = (
            self.first_projection_year_j1r
            - self.j1l_ssf_calculations_using_first_projection_year_data
        )  # t+1 = year after base year
        self._zer_difference_from_ssf = (
            self.first_projection_year_zer
            - self.zel_ssf_calculations_using_first_projection_year_data
        )  # t = base year
        self._z1r_difference_from_ssf = (
            self.first_projection_year_z1r
            - self.z1l_ssf_calculations_using_first_projection_year_data
        )  # t = base year

        x1r_constants: pd.DataFrame = pd.DataFrame(self.x1r_difference_from_ssf)
        x1r_constants.index = self.sym_data.vector_variable_names(vector_name="x1r")
        j1r_constants: pd.DataFrame = pd.DataFrame(self.j1r_difference_from_ssf)
        j1r_constants.index = self.sym_data.vector_variable_names(vector_name="j1r")
        zer_constants: pd.DataFrame = pd.DataFrame(self.zer_difference_from_ssf)
        zer_constants.index = self.sym_data.vector_variable_names(vector_name="zer")
        z1r_constants: pd.DataFrame = pd.DataFrame(self.z1r_difference_from_ssf)
        z1r_constants.index = self.sym_data.vector_variable_names(vector_name="z1r")

        x1r_constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "ssf differences from database first projection year values - x1r.csv",
            )
        )
        j1r_constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "ssf differences from database first projection year values - j1r.csv",
            )
        )
        zer_constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "ssf differences from database first projection year values - zer.csv",
            )
        )
        z1r_constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "ssf differences from database first projection year values - z1r.csv",
            )
        )

    @property
    def first_projection_year_x1r(self) -> np.ndarray:
        """
        The `x1r` vector populated with database values
        from the year after the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_x1r

    @property
    def first_projection_year_j1r(self) -> np.ndarray:
        """
        The `j1r` vector populated with database values
        from the year after the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_j1r

    @property
    def first_projection_year_zer(self) -> np.ndarray:
        """
        The `zer` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_zer

    @property
    def first_projection_year_z1r(self) -> np.ndarray:
        """
        The `z1r` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_z1r

    @property
    def first_projection_year_yxr(self) -> np.ndarray:
        """
        The `yxr` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_yxr

    @property
    def first_projection_year_yjr(self) -> np.ndarray:
        """
        The `yjr` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_yjr

    @property
    def first_projection_year_exz(self) -> np.ndarray:
        """
        The `exz` vector populated with database values
        from the year after the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_exz

    @property
    def first_projection_year_exo(self) -> np.ndarray:
        """
        The `exo` vector populated with database values
        from the first projection year.

        These values are not adjusted by any constants and are never
        altered after they are set.
        """
        return self._first_projection_year_exo

    @property
    def x1r_difference_from_ssf(self):
        """
        The difference between the database values of `x1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._x1r_difference_from_ssf

    @property
    def j1r_difference_from_ssf(self):
        """
        The difference between the database values of `j1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.

        """
        return self._j1r_difference_from_ssf

    @property
    def zer_difference_from_ssf(self):
        """
        The difference between the database values of `zer`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._zer_difference_from_ssf

    @property
    def z1r_difference_from_ssf(self):
        """
        The difference between the database values of `z1r`
        and the raw baseline projections of those values,
        without making any constant adjustments at all.

        These differences are added to the constants that
        are used in the baseline projections to ensure that
        the projections in the first projection year match
        the database values in that year.
        """
        return self._z1r_difference_from_ssf

    @property
    def reference_h3t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to h3t in the Ox implementation
        Functions of current and future exogenous variables affecting J1.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_h3t_used_to_compute_intertemporal_constants

    @property
    def reference_c4t_used_to_compute_intertemporal_constants(self) -> np.ndarray:
        """
        Equivalent to c4t in the Ox implementation
        Functions of current and future exogenous variables affecting ZE.
        This is the reference version of h3t, computed to calculation the projections
        for the base year that will be used as a reference projection when determining
        the numeric derivatives for calculation of the intertemporal constants.

        Its only role is to preserve the appropriate information for benchmarking against Ox.
        """
        return self._reference_c4t_used_to_compute_intertemporal_constants

    @property
    def x1_constants(self) -> np.ndarray:
        """
        The constant adjustments to X1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation
        results with zero constants to get the combined set of constants.
        """

        if hasattr(self, "_x1_constants"):
            return self._x1_constants

        result: np.ndarray = self.x1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for (
            index,
            variable_details,
        ) in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details["vector"] == "x1l":
                result[
                    variable_details["sequence"], 0
                ] += self.intertemporal_constants.loc[
                    variable_details["name"], "constant_value"
                ]
            i = i + 1

        constants: pd.DataFrame = pd.DataFrame(result)
        constants.index = self.sym_data.vector_variable_names(vector_name="x1r")
        constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "constants for baseline projections - x1.csv",
            )
        )

        self._x1_constants: np.ndarray = result
        return self._x1_constants

    @property
    def j1_constants(self) -> np.ndarray:
        """
        The constant adjustments to J1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        # logging.debug(f"Called j1_constants and it has already been defined? {hasattr(self, "_j1_constants")}")

        if hasattr(self, "_j1_constants"):
            return self._j1_constants

        if not hasattr(self, "intertemporal_constants"):
            # logging.debug(f"Getting j1 constants and there are no intertemporal constants so returning the ssf_differences.")
            return self.j1r_difference_from_ssf.copy()

        result: np.ndarray = (
            self.j1r_difference_from_ssf.copy()
        )  # GCS: multiply by 0.0 if Warwick is right about j1 constants being just the intertemporal constants.
        i = 0
        for (
            index,
            variable_details,
        ) in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details["vector"] == "j1l":
                result[
                    variable_details["sequence"], 0
                ] += self.intertemporal_constants.loc[
                    variable_details["name"], "constant_value"
                ]
            i = i + 1

        constants: pd.DataFrame = pd.DataFrame(result)
        constants.index = self.sym_data.vector_variable_names(vector_name="j1r")
        constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "constants for baseline projections - j1.csv",
            )
        )

        self._j1_constants: np.ndarray = result
        return self._j1_constants

    @property
    def ze_constants(self) -> np.ndarray:
        """
        The constant adjustments to ZE to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_ze_constants"):
            return self._ze_constants

        result: np.ndarray = self.zer_difference_from_ssf.copy()

        if not hasattr(self, "intertemporal_constants"):
            return result

        i = 0
        for (
            index,
            variable_details,
        ) in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details["vector"] == "zel":
                result[
                    variable_details["sequence"], 0
                ] += self.intertemporal_constants.loc[
                    variable_details["name"], "constant_value"
                ]
            i = i + 1

        constants: pd.DataFrame = pd.DataFrame(result)
        constants.index = self.sym_data.vector_variable_names(vector_name="zer")
        constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "constants for baseline projections - ze.csv",
            )
        )

        self._ze_constants: np.ndarray = result
        return self._ze_constants

    @property
    def z1_constants(self) -> np.ndarray:
        """
        The constant adjustments to Z1 to ensure projections equal observed values.
        Add any intertemporal constant values to the X1R difference to SSF equation results with zero constants
        to get the combined set of constants.
        """

        if hasattr(self, "_z1_constants"):
            return self._z1_constants

        result: np.ndarray = self.z1r_difference_from_ssf.copy()
        if not hasattr(self, "intertemporal_constants"):
            return result
        i = 0
        for (
            index,
            variable_details,
        ) in self.sym_data.intertemporal_constant_variables.iterrows():
            if variable_details["vector"] == "z1l":
                result[
                    variable_details["sequence"], 0
                ] += self.intertemporal_constants.loc[
                    variable_details["name"], "constant_value"
                ]
            i = i + 1

        constants: pd.DataFrame = pd.DataFrame(result)
        constants.index = self.sym_data.vector_variable_names(vector_name="z1r")
        constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory,
                "constants for baseline projections - z1.csv",
            )
        )

        self._z1_constants: np.ndarray = result
        return self._z1_constants

    def __create_exogenous_variable_projections(self):
        """

        ### Overview

        Populates the exogenous variable values through the projection years.

        ### Exceptions

        Raises an exception if any of the exogenous variables are not populated.

        """

        # See if we are doing a relinearisation. That just uses
        # the exogenous variable projections from the database.
        if (
            self.first_projection_year
            != self.configuration.original_first_projection_year
        ):
            self._exo_projections: pd.DataFrame = self.database.data.loc[
                self.sym_data.var_map[self.sym_data.var_map.var_type == "exo"].index,
                self.projection_years_column_labels,
            ].copy()
            assert (
                not self.exo_projections.isna().any().any()
            ), "Exogenous variables must be populated with valid numbers for all projection years. However, some exogenous projections contain NaN (missing) values."
            return

        # We got here so we are setting up the original
        # baseline so the baseline exogenous variable
        # value adjustments must be loaded.

        # Get the starting values for the exogenous variables,
        # assuming their values in the first projection year
        # continue on through to the last projection year.

        # Double check the first event year is the original one.
        assert (
            self.first_projection_year
            == self.configuration.original_first_projection_year
        ), f"While loading the baseline exogenous variable adjustments, the first projection year should be {self.configuration.original_first_projection_year} but is {self.first_projection_year}."

        exogenous_starting_values: pd.DataFrame = self.database.rhs_vector_value(
            vector_name="exo", year=self.configuration.first_projection_year
        )
        assert not np.isnan(
            exogenous_starting_values
        ).any(), f"First projection year exogenous variable values include NaNs."
        projections: pd.DataFrame = pd.DataFrame(
            np.tile(
                exogenous_starting_values,
                (1, self.configuration.projection_years_count),
            )
        )
        projections.columns = self.configuration.projection_years_column_labels
        projections.index = self.sym_data.vector_variable_names(vector_name="exo")

        source_files: list[str] = self.__get_exogenous_adjustment_files()

        if len(source_files) == 0:
            logging.warning(
                "There are no exogenous adjustments being made to the baseline for growth or energy efficiency. Is that intended?"
            )
            self._exo_projections = projections
            return

        # Iterate the layers of the baseline design, adding them into the
        # exogenous variable projections.
        for source_file in source_files:
            (simulation_variables, simulation_data) = self.load_data(
                filename=source_file, name_column=0
            )

            if len(simulation_variables.index) == 0:
                logging.warning(
                    f"The {os.path.basename(source_file)} simulation layer has no data. Was that intended?"
                )
                continue

            logging.info(
                f"The {os.path.basename(source_file)} simulation layer has adjustments for {len(simulation_data.index)} variables."
            )

            simulation_variables.columns = ["name"]
            simulation_variables.index = simulation_variables.name
            simulation_data.index = simulation_variables.name
            simulation_data = simulation_data.astype(float)

            # Multiply by the YRATR column to rescale all gdp unit variables to US GDP rather than local GDP.
            # Divide the simulation layer values by 100 to scale to match data used in the model.
            try:
                simulation_data = (
                    simulation_data.loc[
                        :, self.configuration.projection_years_column_labels
                    ]
                    * self.database.yratr_scaling_factor(
                        year=self.original_first_projection_year
                    )
                    .loc[simulation_data.index, :]
                    .to_numpy()
                    / 100
                )
            except:
                raise Exception(
                    f"The simulation data in {os.path.basename(source_file)} should include data values from {self.configuration.first_projection_year} to {self.configuration.last_projection_year}"
                )

            # Add the simulation layer adjustments to the exogenous projections.
            projections.loc[
                simulation_data.index, self.projection_years_column_labels
            ] += simulation_data

            assert (
                not projections.isna().any().any()
            ), "After making all baseline adjustments, the exogenous variable projections contain NaNs."

        self._exo_projections: pd.DataFrame = projections

    def __get_exogenous_adjustment_files(self) -> list[str]:
        """
        ### Overview

        Used to set up the list of files that are sources for the adjustments
        to exogenous variable projections in the original baseline projections.

        ### Returns

        List of files containing exogenous adjustments to the baseline.
        """

        if self.configuration.baseline_design_file is None:
            if os.path.exists(
                self.configuration.exogenous_growth_and_efficiency_adjustments_file,
            ):
                return [
                    self.configuration.exogenous_growth_and_efficiency_adjustments_file,
                ]
            return []

        result: list[str] = []

        # Instead, get the simulation layer files from the baseline design file.
        simulation_layer_definitions: SimulationLayerDefinitions = (
            SimulationLayerDefinitions(sym_data=self.sym_data)
        )
        simulation_layer_definitions.load_from_csv_file(
            design_file=self.configuration.baseline_design_file
        )

        # Check that the baseline design only includes
        # layers that have an event year equal to the
        # original first projection year.
        event_years: list[int] = (
            simulation_layer_definitions.all_event_years_in_ascending_order
        )
        assert (
            len(event_years) <= 1
        ), f"The baseline design the same event year for all layers."
        assert (
            len(event_years) == 0
            or event_years[0] == self.configuration.original_first_projection_year
        ), f"The baseline design should have just one event year for all layers and that year should be {self.configuration.original_first_projection_year}."

        for (
            simulation_layer_definition
        ) in simulation_layer_definitions.get_simulation_layer_definitions(
            event_year=self.configuration.original_first_projection_year
        ):
            assert os.path.isfile(simulation_layer_definition.data_filename)
            result.append(simulation_layer_definition.data_filename)
            logging.info(
                f"Including baseline exogenous variable adjustments from {simulation_layer_definition.name}"
            )

        # Issue a warning if the default exogenous adjustments file is not included in the baseline design.
        if (
            not self.configuration.exogenous_growth_and_efficiency_adjustments_file
            in result
        ):
            logging.warning(
                f"The model configuration implies that exogenous adjustments for growth and efficiency are in {gcubed.file_summary(file_path=self.configuration.exogenous_growth_and_efficiency_adjustments_file)} but that file is not being used for baseline projections."
            )

        return result

    def __evaluate_first_projection_year_vector_projections(self):
        """
        Computes the values of the model equation vectors in the first projection year,
        using the functions of future exogenous variables, the stable manifold, etc
        """

        self._exo_first_year_projections = self.exo_projections.loc[
            :, [str(self.first_projection_year)]
        ].to_numpy()

        self._yxr_first_year_projections = self.yxr_initial_values.to_numpy().copy()

        # er = h1t*x[][1] + h2t*exog[][1] + h3t[][1];
        self._yjr_first_year_projections = (
            self.stable_manifold.H1 @ self.yxr_first_year_projections
            + self.stable_manifold.H2 @ self.exo_first_year_projections
            + self._h3t[:, [0]]
        )

        # tzl = mu1t*x[][1] + mu4t*exog[][1] + c4t[][1];
        self._exz_first_year_projections = (
            self.stable_manifold.mu1 @ self.yxr_first_year_projections
            + self.stable_manifold.mu2 @ self.exo_first_year_projections
            + self._c4t[:, [0]]
        )

        # z1l projections = d5n*x[][1]+d7n*exog[][1]+d6n*er+d4n*tzl+cz6[][1]
        self._z1l_first_year_projections = (
            self.state_space_form.delta("z1l", "yxr") @ self.yxr_first_year_projections
            + self.state_space_form.delta("z1l", "exo")
            @ self.exo_first_year_projections
            + self.state_space_form.delta("z1l", "yjr")
            @ self.yjr_first_year_projections
            + self.state_space_form.delta("z1l", "exz")
            @ self.exz_first_year_projections
            + self.z1r_difference_from_ssf
        )

    @property
    def yxr_first_year_projections(self) -> np.ndarray:
        """
        Projections of X1_t (yxr) in the first projection year
        """
        return self._yxr_first_year_projections

    @property
    def yjr_first_year_projections(self) -> np.ndarray:
        """
        Projections of J1_t (yjr) in the first projection year
        """
        return self._yjr_first_year_projections

    @property
    def exz_first_year_projections(self) -> np.ndarray:
        """
        Projections of ZE_t (exz) in the first projection year
        """
        return self._exz_first_year_projections

    @property
    def z1l_first_year_projections(self) -> np.ndarray:
        """
        Projections of Z1_t (z1l=z1r) in the first projection year
        """
        return self._z1l_first_year_projections

    @property
    def exo_first_year_projections(self) -> np.ndarray:
        """
        Projections of EXO_t in the first projection year
        """
        return self._exo_first_year_projections

    @property
    def first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(
        self,
    ) -> np.ndarray:
        """
        The first year projected values for the variables that are being
        adjusted by the intertemporal constants.

        The values are those for the projection that is not adjusted by intertemporal constants.

        It is used in the calculation of the intertemporal constants but it is only preserved
        as a property to facilitate benchmarking against Ox.
        """
        return (
            self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants
        )

    @property
    def first_year_original_projections_of_yxr(self) -> np.ndarray:
        """
        The first year projected values for the state variables.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yxr

    @property
    def first_year_original_projections_of_yjr(self) -> np.ndarray:
        """
        The first year projected values for the costate variables.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_yjr

    @property
    def first_year_original_projections_of_exz(self) -> np.ndarray:
        """
        The first year projected values for the expected endogenous variables exz.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_exz

    @property
    def first_year_original_projections_of_z1l(self) -> np.ndarray:
        """
        The first year projected values for the endogenous variables.

        This is only required for benchmarking against Ox.
        """
        return self._first_year_original_projections_of_z1l

    @property
    def first_year_observed_values_of_variables_adjusted_by_intertemporal_constants(
        self,
    ) -> np.ndarray:
        """
        Returns the observed values, in the first projection year, of the
        variables that are adjusted by intertemporal constants.

        The values are not adjusted after they are initially set so they
        can be relied up and reused by the constant calculation process in this
        baseline projections and in any later relinearisation projections.
        """
        return (
            self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants
        )

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        """
        The data frame of intertemporal constants information
        obtained from SYM but augmented with the values of the
        intertemporal constants.

        The dataframe is indexed by the variable names.

        The constant values are stored in a column called `constant_value`.
        """
        return self._intertemporal_constants

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> np.ndarray:
        """
        The matrix of partial derivatives used in Newton's method to
        compute the intertemporal constants.

        This is a property of the class just to support benchmarking against Ox.
        """
        return self._partial_derivatives

    def __calculate_intertemporal_constants(self):
        """
        ### Overview

        Computes the intertemporal constant adjustments to jump and other variables to align starting data
        values with model projections in the first year.

        Step 1.
        Compute functions of future exogenous variables through all years of the projection.

        Step 2.
        For the variables that are to be adjusted by the intertemporal
        constants, compute their projected values in the base projection year
        and store these values for comparison to perturbed base year projections so we can calculate
        the derivatives matrix needed to set the intertemporal constants.
        Also store the values of each of the 4 vectors in the model in the base year for benchmarking.

        Step 3.
        Initialise the partial derivatives matrix. This is the matrix of derivatives of each of the
        variables that is adjusted by intertemporal constants, with respect to each of the intertemporal
        constants, in the SSF equations (each of which is linear).

        Iterate over the intertemporal constants, perturbing each and recalculating the base year projections
        of the variables that are adjusted by intertemporal constants so that we can
        estimate the relevant numeric derivatives.

        At the end of this step, update the perturbed variable details to `None` so that
        all constants associated with the difference between observed values and SSF calculated values
        are at their unpurturbed values when doing actual baseline projections.

        Step 4.
        Apply Newton's method to solve for the intertemporal constants.
        Multiply the difference between the observed values of the variables that are adjusted by
        the intertemporal constants and their original projected values, in the first projection year,
        by the inverse of the partial derivatives matrix.

        This only needs to be done once because the SSF of the model is linear so Newton's method
        gets to the solution in one iteration.

        ### Exceptions

        Raises an exception if the intertemporal constants contain NaN values.

        """

        logging.info(f"Computing intertemporal constants for the {self.name} ...")

        # Step 1.
        self._compute_functions_of_future_exogenous_variables(
            exogenous_projections=self.exo_projections
        )
        self._reference_c4t_used_to_compute_intertemporal_constants = self.c4t.copy()
        self._reference_h3t_used_to_compute_intertemporal_constants = self.h3t.copy()

        # Step 2.

        # Compute the first year projections - noting that no intertemporal
        # constant adjustments have been made yet.
        self.__evaluate_first_projection_year_vector_projections()

        # Capture the first year projections of the intertemporal variables.
        # These are used in this function for Newton's method below
        # and they are also deep-copied and stored as a property of the
        # class for benchmarking purposes.
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants = (
            self.first_year_projections_of_variables_adjusted_by_intertemporal_constants.copy()
        )

        # For benchmarking purposes only, preserve the original first year projections
        self._first_year_original_projections_of_yxr = (
            self.yxr_first_year_projections.copy()
        )
        self._first_year_original_projections_of_yjr = (
            self.yjr_first_year_projections.copy()
        )
        self._first_year_original_projections_of_exz = (
            self.exz_first_year_projections.copy()
        )
        self._first_year_original_projections_of_z1l = (
            self.z1l_first_year_projections.copy()
        )

        # Step 3.
        # Compute the partial derivatives matrix
        self._partial_derivatives = np.zeros(
            shape=(
                len(self.sym_data.intertemporal_constant_variables),
                len(self.sym_data.variables_adjusted_by_intertemporal_constants),
            )
        )
        i = 0
        for (
            index,
            variable_details,
        ) in self.sym_data.intertemporal_constant_variables.iterrows():
            self.__update_perturbed_variable(variable_details=variable_details)
            self._compute_functions_of_future_exogenous_variables(
                exogenous_projections=self.exo_projections
            )
            self.__evaluate_first_projection_year_vector_projections()
            self._partial_derivatives[:, [i]] = (
                self.first_year_projections_of_variables_adjusted_by_intertemporal_constants
                - self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants
            ) / gcubed.CONSTANTS.DELTA
            i += 1

        # Generate the baseline projection to use in computing partial derivatives
        # and to generate matrix values that are used later in projection processes.
        self.__update_perturbed_variable(variable_details=None)

        # Step 4.
        # Use Newtons method adjustment to compute intertemporal constant values
        self._intertemporal_constants = (
            self.sym_data.intertemporal_constant_variables.copy()
        )
        values: np.ndarray = np.linalg.inv(self._partial_derivatives) @ (
            self.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants
            - self.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants
        )
        values = values.reshape((len(self.intertemporal_constants.index), 1))
        self._intertemporal_constants["constant_value"] = values

        if self._intertemporal_constants["constant_value"].isna().any():
            raise Exception("The intertemporal constants contain NaN values.")

        logging.info("The intertemporal constants have been calibrated.")
        self.intertemporal_constants.to_csv(
            os.path.join(
                self.configuration.diagnostics_directory, "intertemporal constants.csv"
            )
        )
