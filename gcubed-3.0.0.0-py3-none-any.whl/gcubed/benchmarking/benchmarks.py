"""
This module contains the `Benchmarks` class, used to create
a set of benchmarking information about a G-Cubed model.

This enables comparisons of models across models and across
versions of the `gcubed` package used to run them.

"""
import logging
import platform
import os
import pandas as pd
from gcubed.base import Base
from gcubed.constants import Constants as CONSTANTS
from gcubed.exogenous_adjustments.energy_usage_efficiency import EnergyUsageEfficiency
from gcubed.projections.baseline_projections import BaselineProjections
from gcubed.exogenous_adjustments.effective_labour_productivity import (
    EffectiveLabourProductivity,
)
from gcubed.runners.advanced_runner import AdvancedRunner


class Benchmarks(Base):
    """
    ### Overview

    Create a set of benchmark results associated with a model
    and a version of Ox.
    """

    def __init__(
        self,
        working_directory: str,
        configuration_file: str,
        relinearisation_years: list[int] = [],
        experiment_design_file: str = None,
    ):
        """
        ### Overview

        Generates all of the benchmarks that can be used to determine
        the outcome of running the given experiment.

        ### Arguments

        `working_directory`: The directory where the results
        and logs are to be stored.

        `configuration_file`: The location of the configuration
        file, as an absolute path or relative to the
        specified working directory.

        `relinearisation_years`: The list of years where a
        relinearisation is required. This list can be empty
        in which case the model is not relinearised. To generate a
        list of years, from 2018 to say, 2030, you can supply the
        following as as this parameter value:
        `list(range(2018, 2031))`. (Note that the upper bound is not
        included in the range.) Defaults to the empty list.

        `experiment_design_file`: The optional location of the
        experiment design CSV file, as a relative path directory
        to the experiment design file from the simulations directory
        within the model directory (the model directory contains
        the configuration file).
        """

        self._gcubed_version: str = CONSTANTS().VERSION

        self._gcubed_build: str = CONSTANTS().BUILD

        self._python_version: str = platform.python_version()

        assert os.path.isdir(
            working_directory
        ), f"{working_directory} is not a directory."

        self._working_directory: str = working_directory

        # Get the absolute path to the model configuration file.
        if os.path.isabs(configuration_file):
            self.filename: str = configuration_file
        else:
            self.filename: str = os.path.join(working_directory, configuration_file)
        assert os.path.isfile(
            self.filename
        ), f"There is no model configuration file at {self.filename}."

        logging.info(f"The model configuration will be loaded from {self.filename}.")

        self._configuration_file: str = configuration_file

        # Validate and save the list of relinearisation years.
        assert isinstance(
            relinearisation_years, list
        ), "You must specify a list of years in which the model is to be relinearised."

        for year in relinearisation_years:
            assert isinstance(
                year, int
            ), f"The list of relinearisation years must contain YYYY formatted integers, but it contains {year}."

        assert len(relinearisation_years) == len(
            set(relinearisation_years)
        ), "There must not be duplicate relinearisation years."

        assert relinearisation_years == sorted(
            relinearisation_years
        ), "The list of relinearisation years must be in ascending order."

        self._relinearisation_years: list[int] = relinearisation_years

        # Save the experiment design file for later use.
        self._experiment_design_file: str = experiment_design_file

        self.start_projections_from_the_neutral_real_interest_rate = True
        self.linearise_around_the_neutral_real_interest_rate = True
        self.relinearise_around_the_neutral_real_interest_rate = False
        self.relinearise_in_event_years = False

    @property
    def python_version(self) -> str:
        """
        The version of Python used to run the model.
        """
        return self._python_version

    @property
    def gcubed_version(self) -> str:
        """
        The version of G-Cubed used to run the model.
        """
        return self._gcubed_version

    @property
    def gcubed_build(self) -> str:
        """
        The build of G-Cubed used to run the model.
        """
        return self._gcubed_build

    @property
    def working_directory(self) -> str:
        """
        The working directory for Python.
        """
        return self._working_directory

    @property
    def configuration_file(self) -> str:
        """
        The configuration file name and location relative to the working directory.
        """
        if not hasattr(self, "_configuration_file"):
            return None
        return self._configuration_file

    @property
    def experiment_design_file(self) -> str:
        """
        The experiment design file name or `None` if no experiment is to be
        run.
        """
        if not hasattr(self, "_experiment_design_file"):
            return None
        return self._experiment_design_file

    @property
    def relinearisation_years(self) -> list[int]:
        """
        The (possibly empty) list of relinearisation years (all in YYYY format).
        """
        return self._relinearisation_years

    @relinearisation_years.setter
    def relinearisation_years(self, value: list[int]) -> bool:
        """
        ### Overview

        Set the value of the relinearisation years list to a list of integers in YYYY format.

        Note that the list of integers can be supplied using the `range()` function. For example,
        `list(range(2020,2025+1))` produces a list of integers from 2020 to 2025 inclusive.
        """
        assert value is not None, "The relinearisation years must be specified."
        assert isinstance(
            value, list
        ), f"The relinearisation years must be a list of year integers in YYYY format, not {value}"
        for year in value:
            assert isinstance(
                year, int
            ), f"The relinearisation years must be YYYY format integers, not {year}"
            assert (
                year >= 1000 and year < 10000
            ), f"The relinearisation years must be in YYYY format, not {year}"
        self._relinearisation_years = value

    @property
    def linearise_around_strict_model_solution(self) -> bool:
        """
        True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection. Set this to False for standard linearisation
        as has been done for G-Cubed for decades. Set this to True if the
        actual data values are to be adjusted to find similar values that exactly
        solve all of the equations in the model before then linearising around
        those similar values.

        This property defaults to `False`.
        """
        if not hasattr(self, "_linearise_around_strict_model_solution"):
            self._linearise_around_strict_model_solution = False
        return self._linearise_around_strict_model_solution

    @linearise_around_strict_model_solution.setter
    def linearise_around_strict_model_solution(self, value):
        """
        ### Overview

        Set the value to True if the model linearisation is done around a strict model
        solution and False if the model linearisation is to instead be done
        around actual data values sourced from the model database or from a
        previous model projection.

        This property defaults to to the value specified in the supplied
        model configuration file but it can be overridden.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_strict_model_solution = value

    @property
    def linearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        return self._linearise_around_the_neutral_real_interest_rate

    @linearise_around_the_neutral_real_interest_rate.setter
    def linearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline linearisation is around the neutral real interest rate
        and `False` if it is around database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._linearise_around_the_neutral_real_interest_rate = value

    @property
    def relinearise_around_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if  relinearisations are around the neutral real interest rate
        and `False` if they are around previous projection values
        in the relinearisation year.
        """
        return self._relinearise_around_the_neutral_real_interest_rate

    @relinearise_around_the_neutral_real_interest_rate.setter
    def relinearise_around_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the relinearisations are around the neutral real interest rate
        and `False`  if they are around previous projection values
        in the relinearisation year.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_around_the_neutral_real_interest_rate = value

    @property
    def start_projections_from_the_neutral_real_interest_rate(self) -> bool:
        """
        `True` if the baseline linearisation is around neutral real interest rates
        and `False` if they are around database values.

        Defaults to `True`.
        """
        if not hasattr(self, "_start_projections_from_the_neutral_real_interest_rate"):
            self.start_projections_from_the_neutral_real_interest_rate = True
        return self._start_projections_from_the_neutral_real_interest_rate

    @start_projections_from_the_neutral_real_interest_rate.setter
    def start_projections_from_the_neutral_real_interest_rate(self, value: bool):
        """
        Set to `True` if the baseline projections start with neutral real interest rate
        and `False` if they start with database values.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_projections_from_the_neutral_real_interest_rate = value

    @property
    def start_relinearisation_projections_from_the_neutral_real_interest_rate(
        self,
    ) -> bool:
        """
        `True` if the relinearisation starts with neutral real interest rates
        and `False` otherwise.

        Defaults to `False`.
        """
        if not hasattr(
            self,
            "_start_relinearisation_projections_from_the_neutral_real_interest_rate",
        ):
            self.start_relinearisation_projections_from_the_neutral_real_interest_rate = (
                False
            )
        return (
            self._start_relinearisation_projections_from_the_neutral_real_interest_rate
        )

    @start_relinearisation_projections_from_the_neutral_real_interest_rate.setter
    def start_relinearisation_projections_from_the_neutral_real_interest_rate(
        self, value: bool
    ):
        """
        Set to `True` if the relinearisation starts with neutral real interest rates
        and `False` otherwise.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._start_relinearisation_projections_from_the_neutral_real_interest_rate = (
            value
        )

    @property
    def relinearise_in_event_years(self) -> bool:
        """
        `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.

        Defaults to `False`.

        If necessary, modify this setting once the running is instantiated but
        before the experiment is run.
        """
        return self._relinearise_in_event_years

    @relinearise_in_event_years.setter
    def relinearise_in_event_years(self, value: bool) -> bool:
        """
        ### Overview

        Set the value to `True` if the runner is to relinearise the model in all event years
        as well as the years specified and `False` if the runner is to relinearise the model only
        in the years specified.
        """
        assert value is not None
        assert isinstance(value, bool)
        self._relinearise_in_event_years = value

    ####################################################################################################################
    # Generation of properties to access for benchmarking
    ####################################################################################################################

    def produce_benchmarks(self):
        """
        Generate the benchmarks data by running the experiment.
        """

        # Run the experiment

        runner: AdvancedRunner = AdvancedRunner(
            working_directory=self.working_directory,
            configuration_file=self.configuration_file,
            relinearisation_years=self.relinearisation_years,
            experiment_design_file=self.experiment_design_file,
        )
        runner.save_results = False
        runner.model.configuration.linearise_around_strict_model_solution = (
            self.linearise_around_strict_model_solution
        )
        runner.start_projections_from_the_neutral_real_interest_rate = (
            self.start_projections_from_the_neutral_real_interest_rate
        )
        runner.linearise_around_the_neutral_real_interest_rate = (
            self.linearise_around_the_neutral_real_interest_rate
        )
        runner.relinearise_around_the_neutral_real_interest_rate = (
            self.linearise_around_the_neutral_real_interest_rate
        )
        runner.relinearise_in_event_years = self.relinearise_in_event_years
        runner.run()

        # Model information

        self._model_version = runner.model.configuration.version
        self._model_build = runner.model.configuration.build
        self._model_build_number = runner.model.configuration.build_number
        self._first_projection_year = runner.model.configuration.first_projection_year
        self._last_projection_year = runner.model.configuration.last_projection_year

        # Sym information

        self._lhs_vector_names = runner.model.sym_data.lhs_vector_names
        self._rhs_vector_names = runner.model.sym_data.rhs_vector_names
        self._ssf_rhs_vector_names = runner.model.sym_data.ssf_rhs_vector_names

        self._regions = runner.model.sym_data.regions_members
        self._sectors = runner.model.sym_data.sectors_members
        self._goods = runner.model.sym_data.goods_members

        self._sym_summary = runner.model.sym_data.variable_summary

        # Parameter information
        self._parameter_values = runner.model.parameters.parameter_values
        self._all_parameters = runner.model.parameters.all_parameters

        self._model_version = runner.model.configuration.version
        self._model_build = runner.model.configuration.build
        self._model_build_number = runner.model.configuration.build_number

        # Linearisation information

        self._initial_rhs_vector_values: dict[str, pd.DataFrame] = dict()
        for rhs_vector_name in self.rhs_vector_names:
            vector: pd.DataFrame = pd.DataFrame(
                runner.baseline_projections.linear_model.get_vector_by_name(
                    rhs_vector_name
                )
            )
            vector.columns = [rhs_vector_name]
            vector.index = runner.model.sym_data.vector_variable_names(
                vector_name=rhs_vector_name
            )
            self._initial_rhs_vector_values[rhs_vector_name] = vector

        self._nonlinear_equation_vector_values: dict[str, pd.DataFrame] = dict()
        self._linearisation_partial_derivatives: dict[
            tuple[str, str], pd.DataFrame
        ] = dict()
        for vector_name in self.lhs_vector_names:
            vector: pd.DataFrame = pd.DataFrame(
                runner.baseline_projections.linear_model.get_original_lhs_vector_by_name(
                    lhs_vector_name=vector_name
                )
            )
            vector.columns = [vector_name]
            vector.index = runner.model.sym_data.vector_variable_names(
                vector_name=vector_name
            )
            self._nonlinear_equation_vector_values[vector_name] = vector
            for rhs_vector_name in self.rhs_vector_names:
                self._linearisation_partial_derivatives[
                    (vector_name, rhs_vector_name)
                ] = runner.baseline_projections.linear_model.get_partials(
                    lhs_vector_name=vector_name, rhs_vector_name=rhs_vector_name
                )

        # State-Space-Form information
        self._ssf_matrix: dict[tuple[str, str], pd.DataFrame] = dict()
        for vector_name in self.lhs_vector_names:
            for rhs_vector_name in self.ssf_rhs_vector_names:
                self._ssf_matrix[
                    (vector_name, rhs_vector_name)
                ] = runner.baseline_projections.state_space_form.delta_as_dataframe(
                    lhs_vector_name=vector_name, rhs_vector_name=rhs_vector_name
                )

        # Stable manifold information

        self._eigenvalues = pd.DataFrame(
            runner.baseline_projections.stable_manifold.eigenvalues
        )
        self._eigenvalues.columns = ["eigenvalue"]

        self._H1: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.H1_as_dataframe
        )
        self._H2: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.H2_as_dataframe
        )

        self._M1: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.M1_as_dataframe
        )
        self._M2: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.M2_as_dataframe
        )

        self._mu1: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.mu1_as_dataframe
        )
        self._mu2: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.mu2_as_dataframe
        )

        self._Anew: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.Anew_as_dataframe
        )
        self._Znew: pd.DataFrame = (
            runner.baseline_projections.stable_manifold.Znew_as_dataframe
        )

        self._Gamma_st: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.Gamma_st
        )
        self._Gamma_st.columns = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )
        self._Gamma_st.index = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )

        self._Gamma_st: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.Gamma_st
        )
        self._Gamma_st.columns = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )
        self._Gamma_st.index = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )

        self._Gamma_jt: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.Gamma_jt
        )
        self._Gamma_jt.columns = runner.model.sym_data.vector_variable_names(
            vector_name="j1l"
        )
        self._Gamma_jt.index = runner.model.sym_data.vector_variable_names(
            vector_name="j1l"
        )

        self._Gamma_rT: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.Gamma_rT
        )
        self._Gamma_rT.columns = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )
        self._Gamma_rT.index = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )

        self._psi_rj: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.psi_rj
        )
        self._psi_rj.columns = runner.model.sym_data.vector_variable_names(
            vector_name="j1l"
        )
        self._psi_rj.index = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )

        self._psi_rs: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.psi_rs
        )
        self._psi_rs.columns = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )
        self._psi_rs.index = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )

        self._psi_rx: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.psi_rx
        )
        self._psi_rx.columns = runner.model.sym_data.vector_variable_names(
            vector_name="exo"
        )
        self._psi_rx.index = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )

        self._tau_sjt: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.tau_sjt
        )
        self._tau_sjt.columns = runner.model.sym_data.vector_variable_names(
            vector_name="yjr"
        )
        self._tau_sjt.index = runner.model.sym_data.vector_variable_names(
            vector_name="x1l"
        )

        self._common_factor: pd.DataFrame = pd.DataFrame(
            runner.baseline_projections.stable_manifold.common_factor
        )
        self._common_factor.columns = runner.model.sym_data.vector_variable_names(
            vector_name="yxr"
        )
        self._common_factor.index = runner.model.sym_data.vector_variable_names(
            vector_name="j1l"
        )

        # Exogenous adjustments
        effective_labour_productivity: EffectiveLabourProductivity = (
            runner.model.effective_labour_productivity
        )
        self._population: pd.DataFrame = (
            effective_labour_productivity.population.population_growth_rates
        )
        self._potential_output_growth: pd.DataFrame = (
            effective_labour_productivity.potential_output_growth_rates
        )
        self._productivity_by_region: dict[str, pd.DataFrame] = dict()
        self._effective_labour_productivity_by_region: dict[str, pd.DataFrame] = dict()
        energy_usage_efficiency: EnergyUsageEfficiency = (
            runner.model.energy_usage_efficiency
        )
        self._energy_usage_efficiency_gains_by_region: dict[str, pd.DataFrame] = dict()
        self._consumption_energy_usage_efficiency_gains: pd.DataFrame = (
            energy_usage_efficiency.consumption_cumulative_energy_usage_efficiency_gains
        )
        for region in self.regions:
            self._productivity_by_region[
                region
            ] = effective_labour_productivity.productivity.productivity_growth_rates(
                region=region
            )
            self._effective_labour_productivity_by_region[
                region
            ] = effective_labour_productivity.effective_labour_productivity_deviations(
                region=region
            )
            self._energy_usage_efficiency_gains_by_region[
                region
            ] = energy_usage_efficiency.sector_cumulative_energy_usage_efficiency_gains(
                region=region
            )

        # First baseline projections and related constants.
        baseline_projections: BaselineProjections = runner.baseline_projections

        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants: pd.DataFrame = pd.DataFrame(
            baseline_projections.first_year_observed_values_of_variables_adjusted_by_intertemporal_constants
        )
        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants.index = (
            runner.model.sym_data.variables_adjusted_by_intertemporal_constants.index
        )
        self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants.columns = [
            "values"
        ]

        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants: pd.DataFrame = pd.DataFrame(
            baseline_projections.first_year_original_projections_of_variables_adjusted_by_intertemporal_constants
        )
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants.index = (
            self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants.index
        )
        self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants.columns = [
            "values"
        ]

        self._first_projection_year_ssf_lhs_vector_values: dict[
            str, pd.DataFrame
        ] = dict()
        self._first_projection_year_data_difference_from_ssf: dict[
            str, pd.DataFrame
        ] = dict()
        for vector_name in self.lhs_vector_names:
            vector: pd.DataFrame = pd.DataFrame(
                getattr(
                    baseline_projections,
                    f"{vector_name}_ssf_calculations_using_first_projection_year_data",
                )
            )
            vector.index = runner.model.sym_data.vector_variable_names(
                vector_name=vector_name
            )
            vector.columns = ["values"]
            self._first_projection_year_ssf_lhs_vector_values[vector_name] = vector

        for vector_name in self.rhs_versions_of_lhs_vector_names:
            vector: pd.DataFrame = pd.DataFrame(
                getattr(baseline_projections, f"_{vector_name}_difference_from_ssf")
            )
            vector.index = runner.model.sym_data.vector_variable_names(
                vector_name=vector_name
            )
            vector.columns = ["values"]
            self._first_projection_year_data_difference_from_ssf[vector_name] = vector

        self._partial_derivatives_wrt_intertemporal_constants = pd.DataFrame(
            baseline_projections.partial_derivatives_wrt_intertemporal_constants
        )
        self._partial_derivatives_wrt_intertemporal_constants.index = (
            runner.model.sym_data.variables_adjusted_by_intertemporal_constants.index
        )
        self._partial_derivatives_wrt_intertemporal_constants.columns = (
            runner.model.sym_data.intertemporal_constant_variables.index
        )

        self._first_projection_year_original_projections: dict[
            str, pd.DataFrame
        ] = dict()
        for vector_name in ["yxr", "yjr", "exz", "z1l"]:
            vector: pd.DataFrame = pd.DataFrame(
                getattr(
                    baseline_projections,
                    f"first_year_original_projections_of_{vector_name}",
                )
            )
            vector.index = runner.model.sym_data.vector_variable_names(
                vector_name=vector_name
            )
            vector.columns = ["projection"]
            self._first_projection_year_original_projections[vector_name] = vector

        self._baseline_c4t: pd.DataFrame = pd.DataFrame(
            baseline_projections.reference_c4t_used_to_compute_intertemporal_constants
        )
        self._baseline_c4t.index = runner.model.sym_data.vector_variable_names(
            vector_name="zel"
        )
        self._baseline_c4t.columns = self.projection_year_labels

        self._baseline_h3t: pd.DataFrame = pd.DataFrame(
            baseline_projections.reference_h3t_used_to_compute_intertemporal_constants
        )
        self._baseline_h3t.index = runner.model.sym_data.vector_variable_names(
            vector_name="j1l"
        )
        self._baseline_h3t.columns = self.projection_year_labels

        self._intertemporal_constants: pd.DataFrame = (
            baseline_projections.intertemporal_constants.loc[:, ["constant_value"]]
        )

        self._baseline_exogenous_variable_projections: pd.DataFrame = (
            baseline_projections.exo_projections.loc[:, self.projection_year_labels]
        )

        self._baseline_initial_state_vector: pd.DataFrame = (
            baseline_projections.yxr_initial_values
        )

        self._baseline_constantBL: pd.DataFrame = baseline_projections.constantBL

        self._all_projections: list = list()
        for projections in runner.all_projections:
            projection_details: tuple = (
                projections.first_projection_year,
                projections.last_projection_year,
                projections.name,
                projections.projections,
                projections.database_projections,
                projections.publishable_projections,
                projections.annotated_publishable_projections,
            )
            self._all_projections.append(projection_details)

    ### Baseline projections properties

    @property
    def first_year_observed_values_of_variables_adjusted_by_intertemporal_constants(
        self,
    ) -> pd.DataFrame:
        """
        The first projection year observed (database) values of
        variables adjusted by intertemporal constants.

        """
        return (
            self._first_year_observed_values_of_variables_adjusted_by_intertemporal_constants
        )

    @property
    def first_year_original_projections_of_variables_adjusted_by_intertemporal_constants(
        self,
    ) -> pd.DataFrame:
        """
        The first projection year original (not adjusted by intertemporal constants) projections of
        variables adjusted by intertemporal constants
        """
        return (
            self._first_year_original_projections_of_variables_adjusted_by_intertemporal_constants
        )

    def first_projection_year_ssf_lhs_vector_values(
        self, lhs_vector_name: str
    ) -> pd.DataFrame:
        """

        ### Arguments

        lhs_vector_name: The name of the LHS vector.

        ### Returns

        The first projection year State Space Form evaluation for the given LHS vector.
        """
        return self._first_projection_year_ssf_lhs_vector_values[lhs_vector_name]

    def first_projection_year_data_difference_from_ssf(
        self, vector_name: str
    ) -> pd.DataFrame:
        """

        ### Arguments

        vector_name: The name of the RHS version of the LHS vector (e.g. `x1r` for vector `x1l`)

        ### Returns

        The first projection year data difference from State Space Form evaluation for the given vector.
        """
        return self._first_projection_year_data_difference_from_ssf[vector_name]

    def first_projection_year_original_projections(
        self, vector_name: str
    ) -> pd.DataFrame:
        """

        ### Arguments

        lhs_vector_name: The name of the vector - one of:

        * yxr
        * yjr
        * exz
        * z1l

        ### Returns

        The first projection year original (not adjusted by constants)
        projection for the named vector.
        """
        return self._first_projection_year_original_projections[vector_name]

    @property
    def partial_derivatives_wrt_intertemporal_constants(self) -> pd.DataFrame:
        """
        The partial_derivatives wrt intertemporal constants used in Newton's
        method to compute the intertemporal constants.
        """
        return self._partial_derivatives_wrt_intertemporal_constants

    @property
    def intertemporal_constants(self) -> pd.DataFrame:
        """
        The intertemporal constants used to match costate variable projections to
        their observed values in the first projection year.
        """
        return self._intertemporal_constants

    ### Exogenous adjustment properties

    @property
    def population(self) -> pd.DataFrame:
        """
        The population growth projections for all regions
        """
        return self._population

    def productivity(self, region: str) -> pd.DataFrame:
        """
        ### Arguments

        region: The region code

        ### Returns

        The productivity growth projections for the region

        """
        return self._productivity_by_region[region]

    def effective_labour_productivity(self, region: str) -> pd.DataFrame:
        """
        ### Arguments

        region: The region code

        ### Returns

        The effective labour productivity growth projections for the region

        """
        return self._effective_labour_productivity_by_region[region]

    @property
    def potential_output_growth(self) -> pd.DataFrame:
        """
        Potential output growth, for all regions, with rows indexed by region.
        """
        return self._potential_output_growth

    def energy_usage_efficiency_gain(self, region: str) -> pd.DataFrame:
        """
        ### Arguments

        region: the region to get the energy usage efficiency gain for.

        ### Returns

        The energy usage efficiency gain projections for all sectors in the region.

        """
        return self._energy_usage_efficiency_gains_by_region[region]

    @property
    def consumption_energy_usage_efficiency_gains(self) -> pd.DataFrame:
        """
        Consumption energy usage efficiency gains for all regions, with rows
        indexed by region.
        """
        return self._consumption_energy_usage_efficiency_gains

    @property
    def baseline_exogenous_variable_projections(self) -> pd.DataFrame:
        """
        The baseline exogenous variable projections.
        """
        return self._baseline_exogenous_variable_projections

    @property
    def baseline_c4t(self) -> pd.DataFrame:
        """
        The baseline c4t matrix.
        """
        return self._baseline_c4t

    @property
    def baseline_h3t(self) -> pd.DataFrame:
        """
        The baseline h3t matrix.
        """
        return self._baseline_h3t

    @property
    def baseline_initial_state_vector(self) -> pd.DataFrame:
        """
        The baseline yxr (state) vector in the first projection year.
        """
        return self._baseline_initial_state_vector

    @property
    def baseline_constantBL(self) -> pd.DataFrame:
        """
        The baseline constantBL matrix.
        """
        return self._baseline_constantBL

    ### Full set of projection details
    @property
    def all_projections(self) -> list[tuple]:
        """
        A list of tuples where each tuple contains the
        details about a projection. The projections can be baseline
        projections or simulation layers.

        The projection details are listed in the order that they were generated.

        The details for each projection are:

        1. The first projection year
        2. The last projection year
        3. The projection name
        4. The raw projections dataframe
        5. The database projections dataframe
        6. The publishable projections dataframe
        7. The annotated publisable projections dataframe

        """
        return self._all_projections

    ### Model properties

    @property
    def model_version(self) -> str:
        """
        The G-Cubed model version.
        """
        return self._model_version

    @property
    def model_build(self) -> str:
        """
        The G-Cubed model build.
        """
        return self._model_build

    @property
    def model_build_number(self) -> str:
        """
        The G-Cubed model build number.
        """
        return self._model_build_number

    @property
    def name(self) -> str:
        """
        The name of the benchmarks - used for reporting mismatches.
        """
        return f"GCubed-{self.gcubed_version}-{self.gcubed_build} Model-{self.model_version}-{self.model_build}"

    @property
    def first_projection_year(self) -> str:
        """
        The first projection year.
        """
        return self._first_projection_year

    @property
    def last_projection_year(self) -> str:
        """
        The last projection year.
        """
        return self._last_projection_year

    @property
    def projection_years(self) -> list[int]:
        """
        The list of projection years, as integers.
        """
        return list(range(self.first_projection_year, self.last_projection_year + 1))

    @property
    def projection_year_labels(self) -> list[str]:
        """
        The list of projection years, as column labels for data frames.
        """
        return [
            str(x)
            for x in list(
                range(self.first_projection_year, self.last_projection_year + 1)
            )
        ]

    @property
    def lhs_vector_names(self) -> list[str]:
        """
        The list of LHS vector names.
        """
        return self._lhs_vector_names

    @property
    def rhs_vector_names(self) -> list[str]:
        """
        The list of RHS vector names.
        """
        return self._rhs_vector_names

    @property
    def ssf_rhs_vector_names(self) -> list[str]:
        """
        The list of RHS vector names for the state space form of the model.
        """
        return self._ssf_rhs_vector_names

    @property
    def rhs_versions_of_lhs_vector_names(self) -> list[str]:
        """
        The list of RHS vector names, for vectors that are also LHS vectors
        in the model.
        """
        return [f"{x[:-1]}r" for x in self.lhs_vector_names]

    @property
    def sym_summary(self) -> pd.DataFrame:
        """
        The summary of the model variables.
        """
        return self._sym_summary

    @property
    def regions(self) -> list[str]:
        """
        The list of region codes.
        """
        return self._regions

    @property
    def sectors(self) -> list[str]:
        """
        The list of sector codes.
        """
        return self._sectors

    @property
    def goods(self) -> list[str]:
        """
        The list of good codes.
        """
        return self._goods

    ### Parameter properties

    @property
    def parameter_values(self) -> pd.DataFrame:
        """
        The dataframe of calibrated model parameter values,
        indexed by parameter names.
        """
        return self._parameter_values

    @property
    def all_parameters(self) -> dict[str, pd.DataFrame]:
        """
        A dictionary of all parameters, keyed by parameter name.
        This makes it easier to relate parameter values to specific
        set members.
        """
        return self._all_parameters

    ### Linear model properties

    def initial_rhs_vector_values(self, rhs_vector_name: str) -> str:
        """

        ### Arguments

        rhs_vector_name: The RHS vector name

        ### Returns

        Initial (first projection year) RHS vector values, used in linearisation.

        ** Linearisation information. **
        """
        return self._initial_rhs_vector_values[rhs_vector_name]

    def nonlinear_equation_vector_values(self, lhs_vector_name) -> str:
        """
        ### Arguments

        lhs_vector_name: The LHS vector name

        ### Returns

        The values for the LHS vectors computed using the nonlinear
        equations in the model for the first projection year.

        ** Linearisation information. **
        """
        return self._nonlinear_equation_vector_values[lhs_vector_name]

    def linearisation_partial_derivatives(
        self, lhs_vector_name: str, rhs_vector_name: str
    ) -> str:
        """
        ### Arguments

        lhs_vector_name: The LHS vector name

        rhs_vector_name: The RHS vector name

        ### Returns

        The partial derivatives matrix relating the LHS vector to the RHS vector in the linearised model.

        ** Linearisation information. **
        """
        return self._linearisation_partial_derivatives[
            (lhs_vector_name, rhs_vector_name)
        ]

    ### State space form properties

    def ssf_matrix(self, lhs_vector_name: str, rhs_vector_name: str) -> str:
        """
        ### Arguments

        lhs_vector_name: The LHS vector name

        rhs_vector_name: The RHS vector name

        ### Returns

        The  delta matrix relating the LHS vector
        to the RHS vector in the state space form of the model.

        ** Linearisation information. **
        """
        return self._ssf_matrix[(lhs_vector_name, rhs_vector_name)]

    ### Stable manifold properties

    @property
    def eigenvalues(self) -> pd.DataFrame:
        """
        The eigenvalues of the transition matrix of the stable manifold.
        """
        return self._eigenvalues

    @property
    def H1(self) -> pd.DataFrame:
        """
        The H1 matrix of the stable manifold.
        """
        return self._H1

    @property
    def H2(self) -> pd.DataFrame:
        """
        The H2 matrix of the stable manifold.
        """
        return self._H2

    @property
    def M1(self) -> pd.DataFrame:
        """
        The M1 matrix of the stable manifold.
        """
        return self._M1

    @property
    def M2(self) -> pd.DataFrame:
        """
        The M2 matrix of the stable manifold.
        """
        return self._M2

    @property
    def mu1(self) -> pd.DataFrame:
        """
        The mu1 matrix of the stable manifold.
        """
        return self._mu1

    @property
    def mu2(self) -> pd.DataFrame:
        """
        The mu2 matrix of the stable manifold.
        """
        return self._mu2

    @property
    def Anew(self) -> pd.DataFrame:
        """
        The Anew transition matrix of the stable manifold.
        """
        return self._Anew

    @property
    def Znew(self) -> pd.DataFrame:
        """
        The Znew matrix of the stable manifold.
        """
        return self._Znew

    @property
    def Gamma_st(self) -> pd.DataFrame:
        """
        The Gamma_st matrix of the stable manifold.
        """
        return self._Gamma_st

    @property
    def Gamma_jt(self) -> pd.DataFrame:
        """
        The Gamma_jt matrix of the stable manifold.
        """
        return self._Gamma_jt

    @property
    def Gamma_rT(self) -> pd.DataFrame:
        """
        The Gamma_rT matrix of the stable manifold.
        """
        return self._Gamma_rT

    @property
    def psi_rj(self) -> pd.DataFrame:
        """
        The psi_rj matrix of the stable manifold.
        """
        return self._psi_rj

    @property
    def psi_rs(self) -> pd.DataFrame:
        """
        The psi_rs matrix of the stable manifold.
        """
        return self._psi_rs

    @property
    def psi_rx(self) -> pd.DataFrame:
        """
        The psi_rx matrix of the stable manifold.
        """
        return self._psi_rx

    @property
    def tau_sjt(self) -> pd.DataFrame:
        """
        The tau_sjt matrix of the stable manifold.
        """
        return self._tau_sjt

    @property
    def common_factor(self) -> pd.DataFrame:
        """
        The common_factor matrix of the stable manifold.
        """
        return self._common_factor
