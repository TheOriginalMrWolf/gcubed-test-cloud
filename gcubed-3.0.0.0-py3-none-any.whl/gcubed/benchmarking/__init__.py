"""
`gcubed.benchmarking` contains the functionality required to 
generate and store all the information required to 
determine if the results from running one G-Cubed model match the
results from running another G-Cubed model.

The benchmarking system is designed to enable a set of benchmarks to be
instantiated, for comparison purposes, using any version of the G-Cubed
Python package. Thus, benchmarking can be used, and indeed is intended to
be used to compare the results from running different versions of
the G-Cubed Python implementation on the same G-Cubed model.

Another use case is to compare the benchmark results from running 
two different models using the same G-Cubed Python implementation.
This will enable deeper analysis of the causes of differences in 
simulation results across the two different models.
"""
